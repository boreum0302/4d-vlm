#!/usr/bin/env python3
"""Conservative metadata/integrity gate. Never drops individual labels or changes intervals."""
import collections,json
from pathlib import Path
from sam2_contract import ROOT,read_jsonl,qwen_objects,verify_frames,file_hash,write_json

AGENTS=set('person car truck van bus bicycle motorcycle dog cat suv pedestrian airplane giraffe lion dinosaur starfish boat jeep minivan scooter'.split())|{'pickup truck','utility truck'}
ALLOWED_AGENTS=set('person car truck van bus bicycle motorcycle dog cat suv pedestrian airplane boat jeep minivan scooter'.split())|{'pickup truck','utility truck'}
EXCLUDE=set('sky floor ground road grass wall water sidewalk driveway stair stairs staircase doorway handrail railing wheel drawer faucet pipe beam cardboard paper food fruit vegetable toy tool object cylinder cube dome peel pod clothing clothes trash light'.split())|{'bottle cap','shower head','grab bar','bush','fence','building','house','storefront','garage'}


def reasons_for(obj,frame_count):
    reasons=[];items=obj['agents']+obj['non_agents']
    if obj['truncated']:reasons.append('model_reports_omitted_categories')
    if not 1<=len(items)<=8:reasons.append('require_1_to_8_categories')
    if any(o['label'] in AGENTS for o in obj['non_agents']):reasons.append('agent_label_in_non_agents')
    if any(o['label'] not in ALLOWED_AGENTS for o in obj['agents']):reasons.append('unreviewed_agent_label')
    if any(o['label'] in EXCLUDE for o in items):reasons.append('ambiguous_layout_or_part_label')
    if any(0 not in o['evidence_frames'] or frame_count-1 not in o['evidence_frames'] for o in items):
        reasons.append('insufficient_first_and_last_frame_evidence')
    return reasons


def main():
    jobs=read_jsonl(ROOT/'manifests/pi3_all_s260920_k1_f8-32.jsonl');ready=[];excluded=[]
    for j in jobs:
        reasons=[]
        try:
            source=qwen_objects(j);obj=json.loads(Path(source['source']).read_text())
            reasons=reasons_for(obj,len(j['frames']))
            if not reasons:
                verify_frames(j)
                from PIL import Image
                for frame in j['frames']:
                    with Image.open(frame['path']) as im:
                        if list(im.size)!=j['original_image_size_wh']:raise ValueError('Frame resolution changed')
                        im.verify()
                geom=Path(j['output_directory']);mark=json.loads((geom/'complete.json').read_text())
                for name,h in mark['artifact_sha256'].items():
                    if file_hash(geom/name)!=h:raise ValueError('Pi3 artifact hash mismatch')
                fm=json.loads((geom/'frame_map.json').read_text())
                if fm['frames']!=j['frames']:raise ValueError('Pi3 frame mapping mismatch')
                ready.append(dict(j,object_input=source))
        except (OSError,ValueError,KeyError) as e:reasons=['missing_or_invalid_upstream: '+str(e)]
        if reasons:excluded.append({'job_id':j['job_id'],'video_id':j['video_id'],'source':j['source'],'reasons':reasons})
    for name,rows in [('sam2_candidates.jsonl',ready),('sam2_excluded_metadata.jsonl',excluded)]:
        p=ROOT/'manifests'/name;p.write_text(''.join(json.dumps(x)+'\n' for x in rows))
    report={'input':len(jobs),'candidates':len(ready),'excluded':len(excluded),
            'candidate_sources':dict(collections.Counter(j['source'] for j in ready)),
            'reasons':dict(collections.Counter(x for e in excluded for x in e['reasons'])),
            'criteria':{'max_categories':8,'endpoint_evidence_required':True,'disallowed_labels':sorted(EXCLUDE),
                        'agent_labels':sorted(AGENTS),'allowed_agents':sorted(ALLOWED_AGENTS)},
            'gpu_executed':False,'visual_correctness_guaranteed':False}
    write_json(ROOT/'reports/sam2_candidate_selection.json',report)
    print(json.dumps({k:v for k,v in report.items() if k not in ['reasons','criteria']}))


if __name__=='__main__':main()
