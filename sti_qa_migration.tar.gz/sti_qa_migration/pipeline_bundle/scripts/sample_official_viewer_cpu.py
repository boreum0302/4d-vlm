"""Seeded QA sampling per official template, without replacement or quality filtering."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import random,hashlib,collections,time
from orient_contract import ROOT,read_jsonl,write_json,file_hash
from prepare_cpu import write_jsonl
SEED=260921

def sample(rows):
    groups=collections.defaultdict(list)
    for row in rows:groups[row['official_qa']['Type']].append(row)
    result=[];counts={}
    for kind,group in sorted(groups.items()):
        group=sorted(group,key=lambda q:q['qa_id']);rng=random.Random(f'{SEED}:{kind}')
        chosen=rng.sample(group,min(10,len(group)));result.extend(chosen);counts[kind]={'available':len(group),'sampled':len(chosen)}
    return result,counts

def main():
    start=time.perf_counter();src=ROOT/'outputs/dsr_official_review/qa_kept.jsonl';out=ROOT/'outputs/dsr_official_viewer';out.mkdir(exist_ok=True)
    rows=read_jsonl(src);chosen,counts=sample(rows);assert len({q['qa_id'] for q in chosen})==len(chosen)
    write_jsonl(out/'qa_sample.jsonl',chosen)
    write_json(out/'sampling.json',{'source':str(src),'source_sha256':file_hash(src),'seed':SEED,'policy':'uniform QA sampling without replacement independently per template; min(10,available); no quality selection','input_count':len(rows),'sample_count':len(chosen),'video_count':len({q['video_id'] for q in chosen}),'types':counts,'seconds':time.perf_counter()-start,'gpu_executed':False})
    print(len(chosen),counts)
if __name__=='__main__':main()
