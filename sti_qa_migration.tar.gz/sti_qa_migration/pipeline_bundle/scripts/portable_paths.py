"""User-configured dependency paths; relative paths are based on pipeline_bundle."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT/'paths.json').read_text())
def configured(name):
    value=CONFIG.get(name, '')
    if not isinstance(value,str) or not value.strip():
        raise ValueError(f'Fill {name!r} in paths.json before running this stage')
    path=Path(value)
    return path
class DependencyPath:
    # Defer resolution so unrelated CPU stages need no model files.
    def __init__(self,key,parts=()): self.key=key;self.parts=parts
    def path(self): return configured(self.key).joinpath(*self.parts)
    def __fspath__(self): return str(self.path())
    def __str__(self): return str(self.path())
    def __truediv__(self,part): return DependencyPath(self.key,self.parts+(part,))
    def __getattr__(self,name): return getattr(self.path(),name)
