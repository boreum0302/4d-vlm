#!/usr/bin/env python3
"""Read-only CPU rendering of prepared contact sheets for visual review."""
import argparse
import base64
import io
from PIL import Image, ImageDraw
from prepare_cpu import ROOT, read_jsonl

p = argparse.ArgumentParser()
p.add_argument('--offset', type=int, default=0)
p.add_argument('--count', type=int, default=6)
a = p.parse_args()
rows = [r for r in read_jsonl(ROOT/'manifests/sampled_videos.jsonl') if r['subset'] != 'smoke'][a.offset:a.offset+a.count]
im = Image.new('RGB', (1280, ((len(rows)+1)//2)*432), 'white')
d = ImageDraw.Draw(im)
for i, row in enumerate(rows):
    vid = row['video_id']
    with Image.open(ROOT/'review'/f'{vid}.jpg') as thumb:
        thumb.thumbnail((640,412))
        x,y=i%2*640,i//2*432
        im.paste(thumb,(x,y+20))
        d.text((x,y),vid,fill='black')
b=io.BytesIO()
im.save(b,format='JPEG',quality=30)
print(base64.b64encode(b.getvalue()).decode())
