"""CPU-only Orient Anything inputs and DSR 722-logit angle convention."""
from pathlib import Path
import numpy as np
from PIL import Image
from sam2_contract import ROOT,read_jsonl,write_json,file_hash,digest,completed
from portable_paths import DependencyPath
CACHE=DependencyPath('orient_cache')
CHECKPOINT=DependencyPath('orient_checkpoint')
BACKBONE=DependencyPath('orient_backbone')
MODEL_CODE=DependencyPath('orient_model_code')


def crop_object(rgb,mask,padding=10):
    rgb=np.asarray(rgb,dtype=np.uint8)
    if mask.dtype!=np.bool_ or mask.shape!=rgb.shape[:2]:raise ValueError('Mask/image mismatch')
    ys,xs=np.nonzero(mask)
    if not len(xs):return None
    h,w=mask.shape;box=[max(0,int(xs.min())-padding),max(0,int(ys.min())-padding),min(w,int(xs.max())+1+padding),min(h,int(ys.max())+1+padding)]
    image=rgb.copy();image[~mask]=255
    return Image.fromarray(image).crop(box),box


def decode_logits(logits):
    x=np.asarray(logits,dtype=np.float64)
    if x.shape!=(722,) or not np.isfinite(x).all():raise ValueError('Expected 722 finite logits')
    score=np.exp(x[-2:]-x[-2:].max());score/=score.sum()
    return {'azimuth_deg':int(x[:360].argmax()),'polar_deg':int(x[360:540].argmax())-90,
            'rotation_deg':int(x[540:720].argmax())-90,'confidence':float(score[0])}


def dsr_camera_to_agent(azimuth,polar,rotation):
    def rx(deg):
        c,s=np.cos(np.deg2rad(deg)),np.sin(np.deg2rad(deg));return np.array([[1,0,0],[0,c,s],[0,-s,c]])
    def ry(deg):
        c,s=np.cos(np.deg2rad(deg)),np.sin(np.deg2rad(deg));return np.array([[c,0,-s],[0,1,0],[s,0,c]])
    def rz(deg):
        c,s=np.cos(np.deg2rad(deg)),np.sin(np.deg2rad(deg));return np.array([[c,s,0],[-s,c,0],[0,0,1]])
    return rz(270)@rx(90)@ry(azimuth)@rx(polar)@rz(rotation)


def model_inventory():
    files=[CHECKPOINT,BACKBONE/'config.json',BACKBONE/'preprocessor_config.json',BACKBONE/'model.safetensors',MODEL_CODE]
    return {str(p):file_hash(p) for p in files}


def load_model(device):
    # Called only by explicit CPU preflight or the user-only GPU runner.
    import importlib.util
    import torch
    from transformers import AutoImageProcessor
    import sys
    sys.path.insert(0,str(MODEL_CODE.parent))
    spec=importlib.util.spec_from_file_location('sti_orient_vision',MODEL_CODE);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    mod.DINO_LARGE=str(BACKBONE)
    model=mod.DINOv2_MLP('large',1024,722,True,False,False,cache_dir=str(CACHE))
    model.load_state_dict(torch.load(CHECKPOINT,map_location='cpu',weights_only=True),strict=True)
    model=model.eval().to(device)
    processor=AutoImageProcessor.from_pretrained(str(BACKBONE),local_files_only=True)
    return model,processor


def verify_upstream(folder):
    import json
    marker=json.loads((folder/'complete.json').read_text())
    for name,h in marker['artifact_sha256'].items():
        if file_hash(folder/name)!=h:raise ValueError('Upstream artifact hash mismatch: '+str(folder/name))
    return file_hash(folder/'complete.json')
