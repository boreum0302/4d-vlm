import shutil,json
from portable_paths import CONFIG,configured
def main():
    errors=[]
    for key in CONFIG:
        if key=='dsr_code':continue  # historic helper only; official QA functions are bundled.
        try:
            path=configured(key)
            if not path.exists():errors.append(f'{key}: missing {path}')
        except ValueError as e:errors.append(str(e))
    for name in ['ffmpeg','ffprobe']:
        if not shutil.which(name):errors.append(f'{name}: missing executable')
    required={
        'sti_bench':['qa.parquet','data/test-00000-of-00001.parquet','video'],
        'pi3_code':['pi3/models/pi3.py','pi3/utils/basic.py','pi3/utils/geometry.py'],
        'pi3_model':['config.json','model.safetensors'],
        'qwen_model':['config.json','model.safetensors.index.json'],
        'dino_model':['config.json','preprocessor_config.json','model.safetensors'],
        'sam_code':['sam2/build_sam.py','sam2/configs/sam2.1/sam2.1_hiera_l.yaml'],
        'orient_backbone':['config.json','preprocessor_config.json','model.safetensors'],
    }
    for key,names in required.items():
        if not CONFIG.get(key):continue
        for name in names:
            path=configured(key)/name
            if not path.exists():errors.append(f'{key}: missing required {name}')
    for key in ['sam_checkpoint','orient_checkpoint','orient_model_code']:
        if CONFIG.get(key) and not configured(key).is_file():errors.append(f'{key}: must be a file')
    if CONFIG.get('orient_model_code'):
        sibling=configured('orient_model_code').parent/'paths.py'
        if not sibling.is_file():errors.append('orient_model_code: same directory must contain paths.py')
    if CONFIG.get('qwen_model'):
        index=configured('qwen_model')/'model.safetensors.index.json'
        if index.is_file():
            try:
                shards=set(json.loads(index.read_text())['weight_map'].values())
                if not shards:errors.append('qwen_model: empty weight_map')
                for shard in shards:
                    if not (index.parent/shard).is_file():errors.append(f'qwen_model: missing weight shard {shard}')
            except (ValueError,KeyError,TypeError):errors.append('qwen_model: invalid safetensors index')
    if errors:raise SystemExit('\n'.join(errors))
    print('All dependency paths and required files exist (CPU filesystem checks only; models not loaded).')
if __name__=='__main__':main()
