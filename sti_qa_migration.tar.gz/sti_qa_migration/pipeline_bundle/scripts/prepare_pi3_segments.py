#!/usr/bin/env python3
"""CPU: 1 FPS grid -> deterministic random QA intervals -> interval frame inputs."""
import argparse
import os
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import random

import numpy as np
from PIL import Image

from prepare_cpu import ROOT, read_jsonl, run, select_indices, sha256, write_json, write_jsonl


def sample_intervals(n, video_id, seed, count, minimum, maximum):
    if minimum < 4 or maximum < minimum or count < 1:
        raise ValueError('Require 4 <= min_frames <= max_frames and count >= 1')
    candidates = [(a, b) for a in range(n) for b in range(a+minimum-1, min(n, a+maximum))]
    if len(candidates) < count:
        raise ValueError(f'{video_id}: {len(candidates)} possible intervals, {count} requested')
    return random.Random(f'{seed}:{video_id}').sample(candidates, count)


def prepare_grid(row):
    video = Path(row['source_video_path'])
    if sha256(video) != row['sha256']:
        raise ValueError(f'{video}: source content changed since inventory')
    dest = ROOT/'cache'/row['video_id']/'1fps'
    dest.mkdir(parents=True, exist_ok=True)
    manifest = dest/'frames.json'
    if manifest.exists():
        old = json.loads(manifest.read_text())
        if old['source_sha256'] != row['sha256']:
            raise ValueError(f'{manifest}: cached source hash mismatch')
        if old['policy'] != '1fps':
            raise ValueError(f'{manifest}: wrong sampling policy')
        if old['frames'] and all(Path(f['path']).is_file() for f in old['frames']):
            validate_frames(old, row)
            return old
    info = json.loads(run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_frames',
                          '-show_entries', 'frame=best_effort_timestamp_time', '-of', 'json', str(video)]))
    pts = np.array([float(f['best_effort_timestamp_time']) for f in info['frames']])
    times = pts - pts[0]
    indices = select_indices(times, '1fps')
    expression = '+'.join(f'eq(n\\,{i})' for i in indices)
    run(['ffmpeg', '-v', 'error', '-xerror', '-nostdin', '-y', '-threads', '1', '-i', str(video),
         '-vf', f'select={expression}', '-vsync', '0', '-q:v', '2', '-threads', '1',
         '-start_number', '0', str(dest/'%03d.jpg')])
    frames = [dict(sample_index=j, source_frame_index=i, timestamp_s=float(times[i]),
                   source_pts_s=float(pts[i]), path=str(dest/f'{j:03d}.jpg')) for j, i in enumerate(indices)]
    result = dict(video_id=row['video_id'], policy='1fps', source_sha256=row['sha256'],
                  image_size_wh=[row['width'], row['height']], frames=frames)
    validate_frames(result, row)
    write_json(manifest, result)
    write_json(dest/'complete.json', dict(source_sha256=row['sha256'], policy='1fps', frame_indices=indices))
    return result


def validate_frames(data, row):
    fs = data['frames']
    if not fs or any(b['timestamp_s'] <= a['timestamp_s'] or b['source_frame_index'] <= a['source_frame_index'] for a,b in zip(fs,fs[1:])):
        raise ValueError('Empty grid or duplicate/unordered timestamps/frame indices')
    # Grid uses nearest native frame to each integer second, not rounded frame times.
    for i, f in enumerate(fs):
        if f['sample_index'] != i or not np.isfinite(f['timestamp_s']) or abs(f['timestamp_s']-i) > max(0.1, 1/row['fps']):
            raise ValueError('Frame does not match 1 FPS grid')
        with Image.open(f['path']) as image:
            if list(image.size) != data['image_size_wh']:
                raise ValueError('Frame size mismatch')
            image.verify()


def prepare_video(row, args, tag):
    grid = prepare_grid(row)
    intervals = sample_intervals(len(grid['frames']), row['video_id'], args.seed,
                                args.segments_per_video, args.min_frames, args.max_frames)
    jobs = []
    for k, (start,end) in enumerate(intervals):
        selected = grid['frames'][start:end+1]
        segment = f'{tag}_{k:02d}_{start:04d}_{end:04d}'
        directory = ROOT/'inputs/pi3'/row['video_id']/segment
        frame_dir = directory/'frames'
        frame_dir.mkdir(parents=True,exist_ok=True)
        frames = []
        for j, f in enumerate(selected):
            src = Path(f['path']).resolve()
            link = frame_dir/f'{j:03d}.jpg'
            if link.is_symlink() or link.exists():
                if link.resolve() != src:
                    raise ValueError(f'Conflicting segment frame: {link}')
            else:
                link.symlink_to(os.path.relpath(src, link.parent.resolve()))
            frames.append({**f, 'segment_frame_index': j, 'path': str(link), 'sha256': sha256(src)})
        if len(list(frame_dir.glob('*.jpg'))) != len(frames):
            raise ValueError(f'Unexpected extra frames in {frame_dir}')
        payload = dict(video_id=row['video_id'], source_video_sha256=row['sha256'],
                       interval=[start,end], frame_hashes=[f['sha256'] for f in frames])
        signature = hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
        job = dict(job_id=f'{row["video_id"]}/{segment}', video_id=row['video_id'], source=row['source'],
                   segment_id=segment, source_video_path=row['source_video_path'],
                   source_video_sha256=row['sha256'], input_signature=signature,
                   sampling_policy='1fps_random_interval', seed=args.seed,
                   selection_policy=dict(min_frames=args.min_frames,max_frames=args.max_frames,
                                         segments_per_video=args.segments_per_video,
                                         distribution='uniform_over_valid_endpoint_pairs_without_replacement'),
                   query_start_s=frames[0]['timestamp_s'],query_end_s=frames[-1]['timestamp_s'],
                   reference_scope='within_selected_interval_only',
                   original_image_size_wh=grid['image_size_wh'], frames=frames,
                   frame_directory=str(frame_dir),
                   output_directory=str(ROOT/'artifacts/pi3'/row['video_id']/segment))
        write_json(directory/'input.json',job)
        jobs.append(job)
    return jobs


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--subset',choices=['smoke','all'],default='smoke')
    p.add_argument('--seed',type=int,default=260920)
    p.add_argument('--segments-per-video',type=int,default=1)
    p.add_argument('--min-frames',type=int,default=8)
    p.add_argument('--max-frames',type=int,default=32)
    p.add_argument('--workers',type=int,default=4)
    a=p.parse_args()
    if not 1 <= a.workers <= 8 or not 4 <= a.min_frames <= a.max_frames or a.segments_per_video < 1:
        p.error('Require workers 1..8, 4 <= min_frames <= max_frames, segments_per_video >= 1')
    file='dynamic_smoke_videos.jsonl' if a.subset=='smoke' else 'dynamic_videos.jsonl'
    rows=read_jsonl(ROOT/'manifests'/file)
    tag=f's{a.seed}_k{a.segments_per_video}_f{a.min_frames}-{a.max_frames}'
    target=ROOT/'manifests'/f'pi3_{a.subset}_{tag}.jsonl'
    jobs=[]
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        for i, result in enumerate(pool.map(lambda r: prepare_video(r,a,tag),rows),1):
            jobs.extend(result)
            print(f'CPU input preparation {i}/{len(rows)}',flush=True)
    write_jsonl(target,jobs)
    write_json(ROOT/'reports'/f'pi3_inputs_{a.subset}_{tag}.json',dict(
        videos=len(rows),segments=len(jobs),selected_frames=sum(len(j['frames']) for j in jobs),
        manifest=str(target),gpu_execution=False,seed=a.seed))
    print(f'Manifest: {target}',flush=True)


if __name__=='__main__':main()
