"""CPU helpers shared with the user-launched Pi3 runner. No model imports."""
import hashlib
import json
from pathlib import Path
import numpy as np


def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def source_hash(root):
    h=hashlib.sha256()
    for p in sorted(Path(root).rglob('*.py')):
        h.update(str(p.relative_to(root)).encode());h.update(p.read_bytes())
    return h.hexdigest()


def validate_output(local, poses, logits, valid):
    if local.ndim!=4 or local.shape[-1]!=3:
        raise ValueError('local_points must be N,H,W,3')
    n,h,w,_=local.shape
    if poses.shape!=(n,4,4) or logits.shape!=(n,h,w) or valid.shape!=(n,h,w):
        raise ValueError('Pi3 output shape mismatch')
    if not all(np.isfinite(x).all() for x in [local,poses,logits]):
        raise ValueError('Nonfinite Pi3 output')
    if not np.allclose(poses[:,3,:],[0,0,0,1],atol=1e-4):
        raise ValueError('Invalid pose homogeneous row')
    r=poses[:,:3,:3]
    if not np.allclose(r.transpose(0,2,1)@r,np.eye(3),atol=2e-3) or not np.allclose(np.linalg.det(r),1,atol=2e-3):
        raise ValueError('Nonrigid camera pose')
    if (local[...,2]<=0).any() or (valid.reshape(n,-1).sum(axis=1)==0).any():
        raise ValueError('Invalid depth or frame with no valid pixels')
    return {'frames':n,'image_size_wh':[w,h],
            'valid_pixel_fraction_per_frame':valid.reshape(n,-1).mean(axis=1).tolist(),
            'camera_step_length':np.linalg.norm(np.diff(poses[:,:3,3],axis=0),axis=1).tolist()}


def verify_job(job):
    frames=job['frames']
    if len(frames)<4:raise ValueError('Too few interval frames')
    if job['query_start_s']!=frames[0]['timestamp_s'] or job['query_end_s']!=frames[-1]['timestamp_s']:
        raise ValueError('Interval endpoints mismatch')
    for i,f in enumerate(frames):
        if f['segment_frame_index']!=i or file_hash(f['path'])!=f['sha256']:
            raise ValueError('Frame mapping or hash changed')
    if any(b['timestamp_s']<=a['timestamp_s'] for a,b in zip(frames,frames[1:])):
        raise ValueError('Nonincreasing timestamps')
    paths={Path(f['path']).absolute() for f in frames}
    actual={p.absolute() for p in Path(job['frame_directory']).glob('*.jpg')}
    if paths!=actual:raise ValueError('Unexpected/missing segment images')


def completion_matches(out, signature):
    marker=Path(out)/'complete.json'
    if not marker.exists():return False
    data=json.loads(marker.read_text())
    if data['run_signature']!=signature:
        raise ValueError(f'Existing result has different input/model/config: {out}; use a new output root')
    for name,expected in data['artifact_sha256'].items():
        p=Path(out)/name
        if not p.is_file() or file_hash(p)!=expected:
            raise ValueError(f'Completed artifact changed or missing: {p}')
    return True
