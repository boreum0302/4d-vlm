#!/usr/bin/env python3
"""Verify all interval JPEG hashes and write Qwen job manifests; CPU only."""
import argparse
from qwen35_contract import ROOT, MODEL, PROMPT, digest, file_hash, model_inventory, read_jsonl, verify_frames, write_json


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--subset', choices=['smoke', 'all'], default='all')
    a = p.parse_args()
    source = ROOT / f'manifests/pi3_{a.subset}_s260920_k1_f8-32.jsonl'
    jobs = read_jsonl(source)
    for job in jobs:
        verify_frames(job)
        job['object_input_signature'] = digest({'pi3_input_signature': job['input_signature'],
                                                'frames': job['frames'], 'prompt_sha256': file_hash(PROMPT)})
    target = ROOT / f'manifests/qwen35_objects_{a.subset}.jsonl'
    target.write_text(''.join(__import__('json').dumps(j) + '\n' for j in jobs))
    report = {'subset': a.subset, 'jobs': len(jobs), 'frames': sum(len(j['frames']) for j in jobs),
              'manifest': str(target), 'prompt': str(PROMPT), 'model': model_inventory(MODEL),
              'gpu_executed': False, 'api_calls': 0, 'frame_hashes_verified': True}
    write_json(ROOT/f'reports/qwen35_preparation_{a.subset}.json', report)
    print(f'CPU verified {len(jobs)} jobs / {report["frames"]} frames: {target}')


if __name__ == '__main__':
    main()
