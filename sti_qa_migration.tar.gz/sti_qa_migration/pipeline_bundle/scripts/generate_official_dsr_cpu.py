"""Run unchanged upstream generate_one_video with cached perception callbacks, CPU only."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import ast,argparse,collections,hashlib,json,random,sys,time,warnings,inspect
from pathlib import Path
import numpy as np
from orient_contract import ROOT,read_jsonl,write_json,file_hash
from prepare_cpu import write_jsonl
UP=ROOT/'vendor/official_sources'
UTILS=['cal_dis','camera_mutual_coordinate_transform','camera_self_coord_trans','rotation_matrix_x','rotation_matrix_y','rotation_matrix_z','rotate_point_cloud','camera_agent_coord_trans','agent_camera_coord_trans','extract_obj_center']

def load_functions(path,names,ns):
    tree=ast.parse(path.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes}==set(names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns)

class Cache:
    def __init__(self,job):
        self.job=job;self.n=len(job['frames']);sub=Path(job['video_id'])/job['segment_id']
        self.sam=json.loads((ROOT/'artifacts/grounded_sam2'/sub/'tracks.json').read_text())
        ori=json.loads((ROOT/'artifacts/orient_anything'/sub/'orientations.json').read_text())
        self.ori={str(t['track_id']):t for t in ori['tracks']};self.frames={};self.calls=[]
    def frame(self,i):
        if i not in self.frames:
            with np.load(self.sam['frames'][i]['mask_path'],allow_pickle=False) as z:self.frames[i]={str(t):m for t,m in zip(z['track_ids'],z['masks'])}
        return self.frames[i]
    def idx(self,path):
        i=int(Path(path).stem)
        f=inspect.currentframe().f_back
        while f and f.f_code.co_name!='generate_one_video':f=f.f_back
        if f and 'pred' in f.f_locals.get('qa_type','') and i in (29,31):return self.n-3 if i==29 else self.n-1
        if i>=self.n:raise ValueError('cached_frame_out_of_range')
        return i
    def choose(self,prompt,num,i):
        labels={s.strip() for s in prompt.split('.') if s.strip()}
        candidates=[t for t in self.sam['tracks'] if t['label'] in labels and self.frame(i)[str(t['track_id'])].any()]
        return random.sample(candidates,num)
    def box(self,t,i):return next(o['bbox_xyxy'] for o in self.sam['frames'][i]['objects'] if str(o['track_id'])==str(t['track_id']))
    def image(self,_a,_b,image,prompt,device,**kwargs):
        i=self.idx(image);t=self.choose(prompt,1,i)[0];tid=str(t['track_id']);self.calls.append({'kind':'image','frames':[i],'track_ids':[tid]})
        return t['label'],np.asarray(self.box(t,i),dtype=np.uint32),self.frame(i)[tid]
    def video(self,_a,_b,video,prompt,num,device,**kwargs):
        ii=[self.idx(p) for p in video];ts=self.choose(prompt,num,ii[0]);ids=[str(t['track_id']) for t in ts];self.calls.append({'kind':'video','frames':ii,'track_ids':ids})
        return [t['label'] for t in ts],np.asarray([self.box(t,ii[0]) for t in ts],dtype=np.uint32),np.stack([np.stack([self.frame(i)[tid] for i in ii]) for tid in ids])
    def orient(self,_a,_b,image,mask,device):
        i=self.idx(image)
        ids=[tid for tid,m in self.frame(i).items() if np.array_equal(m,mask)]
        if len(ids)!=1:raise ValueError('cached_orientation_mask_identity_ambiguous')
        t=self.ori.get(ids[0]);s=t['samples'][i] if t else None
        if not s or s['status']!='predicted':raise ValueError('cached_orientation_unavailable')
        a=s['angles'];return a['azimuth_deg'],a['polar_deg'],a['rotation_deg'],a['confidence']
    def geometry(self):
        with np.load(Path(self.job['output_directory'])/'scene_geometry.npz',allow_pickle=False) as z:
            pts=z['local_points'];valid=z['valid_mask'];poses=z['camera_to_world']
        w,h=self.sam['image_size_wh'];ih,iw=pts.shape[1:3]
        # torch interpolate(mode=nearest) uses floor(dst * input/output).
        yy=np.floor(np.arange(h)*ih/h).astype(int);xx=np.floor(np.arange(w)*iw/w).astype(int)
        points=pts[:,yy[:,None],xx[None,:],:].transpose(0,3,1,2)
        masks=valid[:,yy[:,None],xx[None,:]]
        return points,masks,poses

def run(job,attempts):
    cache=Cache(job);ns={'np':np,'random':random}
    exec(compile((UP/'template.py').read_text(),str(UP/'template.py'),'exec'),ns)
    load_functions(UP/'qa_utils.py',UTILS,ns);load_functions(UP/'qa_temp.py',['prob_cal','generate_one_video'],ns)
    ns.update(extract_obj_image_mask=cache.image,extract_obj_video_mask=cache.video,extract_orient=cache.orient)
    categories=json.loads((ROOT/'artifacts/qwen35_validated'/job['video_id']/job['segment_id']/'objects.json').read_text())
    # Cached track groups already encode validated Qwen categories; retain categories without orientation too.
    agents=list(dict.fromkeys(t['label'] for t in categories['agents']))
    objs=list(dict.fromkeys(t['label'] for t in categories['non_agents']))
    points,masks,poses=cache.geometry();records=[];exceptions=[];last_attempt=None
    def trace(frame,event,arg):
        nonlocal last_attempt
        if frame.f_code.co_name!='generate_one_video':return None
        loc=frame.f_locals
        if loc.get('qa_idx')!=last_attempt:last_attempt=loc.get('qa_idx');cache.calls=[]
        if event=='exception':
            typ,val,_=arg;exceptions.append({'attempt':last_attempt,'type':loc.get('qa_type'),'error':typ.__name__+': '+str(val)})
        pairs=loc.get('qa_pairs',[])
        if len(pairs)>len(records):
            records.append({'qa_index':len(records),'attempt':last_attempt,'perception_calls':list(cache.calls),'official_locals':{k:loc[k] for k in ['time_1','time_2','time_3','time_end','idx_1','idx_2','idx_3'] if k in loc}})
        return trace
    seed=int(hashlib.sha256(job['job_id'].encode()).hexdigest()[:8],16)^260920;random.seed(seed);np.random.seed(seed)
    sys.settrace(trace)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error',RuntimeWarning)
            qs=ns['generate_one_video']('cached',[f['timestamp_s'] for f in job['frames']],agents,objs,attempts,points,masks,poses,None,None,None,None,None,'cpu')
    finally:sys.settrace(None)
    assert len(qs)==len(records)
    return qs,records,exceptions,seed

def main():
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);p.add_argument('--attempts',type=int,default=10);p.add_argument('--output',default='outputs/dsr_official');a=p.parse_args()
    out=ROOT/a.output;out.mkdir(parents=True,exist_ok=True);start=time.perf_counter();jobs=read_jsonl(ROOT/'manifests/sam2_all.jsonl');jobs=jobs[:a.limit] if a.limit else jobs
    allqa=[];logs=[];failed=[];raw={}
    for i,job in enumerate(jobs,1):
        try:
            qs,records,exceptions,seed=run(job,a.attempts);raw[job['job_id']]=qs
            for k,(q,r) in enumerate(zip(qs,records)):
                assert all(key in q for key in ['Type','Question','A','B','C','D','Correct'])
                allqa.append({'qa_id':f"official_{job['video_id']}_{k:03d}",'video_id':job['video_id'],'segment_id':job['segment_id'],'source':job['source'],'source_video_path':job['source_video_path'],'review_status':'unreviewed','seed':seed,'official_qa':q,'provenance':r})
            logs.append({'job_id':job['job_id'],'qa_count':len(qs),'attempts':a.attempts,'caught_exceptions':exceptions})
        except Exception as e:failed.append({'job_id':job['job_id'],'error':repr(e)});print(f'FAIL {job["job_id"]}: {e}',flush=True)
        if i%10==0 or i==len(jobs):print(f'{i}/{len(jobs)} QA={len(allqa)} failures={len(failed)} seconds={time.perf_counter()-start:.1f}',flush=True)
    write_json(out/'qa_pairs.json',raw);write_jsonl(out/'qa_all.jsonl',allqa);write_jsonl(out/'generation_log.jsonl',logs)
    report={'jobs':len(jobs),'processed':len(logs),'failed':failed,'qa_count':len(allqa),'videos_with_qa':sum(x['qa_count']>0 for x in logs),'attempts_per_video':a.attempts,'type_counts':dict(collections.Counter(q['official_qa']['Type'] for q in allqa)),'seconds':time.perf_counter()-start,'gpu_executed':False,'review':'not_run','official_sources':{str(UP/n):file_hash(UP/n) for n in ['qa_temp.py','qa_utils.py','template.py']},'adapter_sha256':file_hash(__file__),'adapter_policy':'unchanged AST of generate_one_video/prob_cal and CPU coordinate utilities; cached SAM2 and OA callbacks; prediction virtual 029/031 map to N-3/N-1; nearest upsample Pi3 to native mask grid'}
    write_json(out/'generation_summary.json',report);print(json.dumps(report),flush=True)
    assert 'torch' not in sys.modules
if __name__=='__main__':main()
