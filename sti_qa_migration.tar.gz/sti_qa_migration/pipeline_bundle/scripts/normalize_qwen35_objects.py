#!/usr/bin/env python3
"""CPU normalization with original responses preserved and explicit unresolved jobs."""
import copy,json,re,collections
from pathlib import Path
from qwen35_contract import ROOT,read_jsonl,parse_objects,file_hash,digest,write_json


def normalize(text,frame_count):
    text=text.strip();m=re.fullmatch(r'```(?:json)?\s*\n(.*?)\n```',text,re.S|re.I)
    data=json.loads(m[1] if m else text)
    if not isinstance(data,dict) or set(data)!={'agents','non_agents','truncated'} or type(data['truncated']) is not bool:
        raise ValueError('Invalid root schema')
    result={'agents':[],'non_agents':[],'truncated':data['truncated']};changes=[];seen={}
    for group in ['agents','non_agents']:
        if not isinstance(data[group],list):raise ValueError('Invalid object list')
        for original in data[group]:
            item=copy.deepcopy(original)
            if not isinstance(item,dict) or not isinstance(item.get('label'),str):raise ValueError('Invalid item')
            label=' '.join(item['label'].replace('_',' ').lower().split())
            if label!=item['label']:changes.append({'action':'normalize_label','before':item['label'],'after':label})
            item['label']=label
            # Validate each original entry before merging; do not hide bad evidence or semantic conflicts.
            probe={'agents':[],'non_agents':[],'truncated':False};probe[group]=[item]
            parse_objects(json.dumps(probe),frame_count)
            if label in seen and seen[label]!=group:raise ValueError('Agent/non-agent conflict: '+label)
            seen[label]=group
            previous=next((x for x in result[group] if x['label']==label),None)
            if previous is None:result[group].append(item);continue
            changes.append({'action':'merge_same_category','group':group,'label':label})
            if previous['motion']!=item['motion']:previous['motion']='unknown'
            previous['orientation_candidate']=previous['orientation_candidate'] or item['orientation_candidate']
            previous['evidence_frames']=sorted(set(previous['evidence_frames'])|set(item['evidence_frames']))
    labels=[x['label'] for g in ['agents','non_agents'] for x in result[g]]
    if len(labels)>64:raise ValueError('More than 64 categories; manual review required')
    if len(labels)>12:changes.append({'action':'preserve_all_categories','count':len(labels)})
    result.update(grounding_prompt='. '.join(labels)+('.' if labels else ''),review_status='needs_visual_review',
                  category_count=len(labels))
    return result,changes


def main():
    jobs=read_jsonl(ROOT/'manifests/qwen35_objects_all.jsonl');dest=ROOT/'artifacts/qwen35_validated'
    dest.mkdir(exist_ok=True);accepted=[];pending=[];stats=collections.Counter()
    retry_root=ROOT/'artifacts/qwen35_retry'
    for job in jobs:
        folder=ROOT/'artifacts/qwen35_objects'/job['video_id']/job['segment_id']
        retry=retry_root/job['video_id']/job['segment_id']
        if (retry/'complete.json').exists():folder=retry
        try:
            marker=folder/'complete.json'
            if marker.exists():
                for name,h in json.loads(marker.read_text())['artifact_sha256'].items():
                    if file_hash(folder/name)!=h:raise ValueError('Original artifact hash mismatch')
            raw_path=folder/'raw_response.json';raw=json.loads(raw_path.read_text())
            # Truncated JSON fails parsing; no fabricated closing braces or inferred categories.
            parsed,changes=normalize(raw['text'],len(job['frames']))
            if folder==retry and raw['generated_tokens']>=4096:raise ValueError('Retry output hit token cap')
            if folder!=retry and raw['generated_tokens']>=1536:raise ValueError('Original output hit token cap')
            result=dict(parsed,job_id=job['job_id'],video_id=job['video_id'],segment_id=job['segment_id'],
                        query_start_s=job['query_start_s'],query_end_s=job['query_end_s'],frames=job['frames'],
                        source_video_path=job['source_video_path'])
            out=dest/job['video_id']/job['segment_id']
            write_json(out/'objects.json',result)
            write_json(out/'normalization.json',{'source_raw':str(raw_path),'source_raw_sha256':file_hash(raw_path),
                       'original_complete_marker':marker.exists(),'changes':changes,
                       'input_signature':job['input_signature'],'normalizer_sha256':file_hash(__file__),
                       'inference_provenance': 'original completed artifacts' if marker.exists() else 'original run job path/log association; per-job GPU provenance and quality were not saved'})
            write_json(out/'validated.json',{'validation':'CPU schema and normalization; visual review pending',
                       'artifact_sha256':{n:file_hash(out/n) for n in ['objects.json','normalization.json']}})
            accepted.append(result)
            stats['original_passed' if marker.exists() else 'cpu_recovered']+=1
        except (OSError,ValueError,KeyError,TypeError) as exc:
            pending.append(dict(job,retry_reason=str(exc)))
    for name,rows in [('artifacts/qwen35_validated/objects_all.jsonl',accepted),('manifests/qwen35_objects_retry.jsonl',pending)]:
        p=ROOT/name;temp=p.with_suffix('.jsonl.tmp');temp.write_text(''.join(json.dumps(x)+'\n' for x in rows));temp.replace(p)
    report={'requested':len(jobs),'validated':len(accepted),'pending':len(pending),**stats,
            'pending_jobs':[{'job_id':j['job_id'],'reason':j['retry_reason']} for j in pending],
            'gpu_executed':False,'visual_review_pending':True}
    write_json(ROOT/'reports/qwen35_validation.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='pending_jobs'}))


if __name__=='__main__':main()
