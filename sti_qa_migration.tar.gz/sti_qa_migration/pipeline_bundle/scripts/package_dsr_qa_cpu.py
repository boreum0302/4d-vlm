#!/usr/bin/env python3
"""CPU media packaging, independent answer validation and dataset export."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import argparse,collections,concurrent.futures,hashlib,json,subprocess,time
from pathlib import Path
from functools import lru_cache
import qa_cpu
qa_cpu.load_rules=lru_cache(maxsize=1)(qa_cpu.load_rules)
from orient_contract import ROOT,read_jsonl,write_json,file_hash,digest
from prepare_cpu import write_jsonl
from dsr_qa_contract import validate_qa
OUT=ROOT/'outputs/dsr_qa'


def media(job,kind):
    n=len(job['frames'])-(2 if kind=='observed' else 0);dest=OUT/'media'/job['video_id']/job['segment_id']/f'{kind}.mp4'
    dest.parent.mkdir(parents=True,exist_ok=True);marker=dest.with_suffix('.json')
    settings={'frames':job['frames'][:n],'spatial_policy':'native resolution; pad right/bottom to even dimensions','fps':1,'codec':'libx264','crf':20,'kind':kind}
    signature=digest(settings)
    if marker.exists() and dest.exists():
        old=json.loads(marker.read_text())
        if old['signature']==signature and file_hash(dest)==old['sha256']:return old
    for frame in job['frames'][:n]:
        if file_hash(frame['path'])!=frame['sha256']:raise ValueError('Frame hash mismatch')
    temp=dest.with_name(dest.stem+'.tmp.mp4')
    cmd=['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-threads','1','-filter_threads','1','-framerate','1','-start_number','0',
      '-i',str(Path(job['frame_directory'])/'%03d.jpg'),'-frames:v',str(n),'-vf','pad=ceil(iw/2)*2:ceil(ih/2)*2',
      '-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-threads','1','-movflags','+faststart',str(temp)]
    subprocess.run(cmd,check=True,capture_output=True)
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames,width,height','-of','json',str(temp)]))['streams'][0]
    if int(probe['nb_read_frames'])!=n:raise ValueError('Encoded frame count mismatch')
    temp.replace(dest)
    result={'path':str(dest),'signature':signature,'sha256':file_hash(dest),'frame_count':n,'width':probe['width'],'height':probe['height'],
            'timestamps_s':[f['timestamp_s'] for f in job['frames'][:n]],'source_frame_indices':[f['source_frame_index'] for f in job['frames'][:n]],
            'fps':1,'input_kind':'1fps sampled frame sequence, not original-rate video','job_id':job['job_id'],'kind':kind}
    write_json(marker,result);return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--media-only',action='store_true');a=p.parse_args();start=time.perf_counter()
    jobs=read_jsonl(ROOT/'manifests/sam2_all.jsonl');pairs=[(j,k) for j in jobs for k in ['full','observed']]
    result=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(media,*pair) for pair in pairs]
        for i,future in enumerate(concurrent.futures.as_completed(futures),1):
            result.append(future.result())
            if i%100==0:print(f'Media {i}/{len(pairs)} elapsed={time.perf_counter()-start:.1f}s',flush=True)
    write_json(ROOT/'reports/qa_media.json',{'clips':len(result),'wall_seconds':time.perf_counter()-start,'gpu_executed':False,'all_frame_counts_verified':True})
    if a.media_only:return
    qas=read_jsonl(OUT/'qa_all.jsonl');model_inputs=[];answers=[];seen=set();geometry={}
    media_lookup={(x['job_id'],x['kind']):x for x in result}
    for q in qas:
        assert q['qa_id'] not in seen;seen.add(q['qa_id'])
        path=q['geometry_artifact']
        if path not in geometry:
            g=json.loads(Path(path).read_text());g['geometry_sha256']=file_hash(path);g['geometry_artifact']=path;geometry[path]=g
        g=geometry[path];validate_qa(q,g)
        m=media_lookup[(g['job_id'],'observed' if q['type'].endswith('_pred') else 'full')]
        assert m['timestamps_s']==q['input_timestamps_s']
        if q['type'].endswith('_pred'):assert max(m['timestamps_s'])<q['prediction_target_time_s']
        q.update(input_video_path=m['path'],input_video_sha256=m['sha256'],input_video_fps=1,
                 input_video_time_origin_s=m['timestamps_s'][0],input_video_size_wh=[m['width'],m['height']],bbox_coordinate_space='original_image_pixels')
        row={k:q[k] for k in ['qa_id','video_id','segment_id','source','type','question','options','query_start_s','query_end_s','observed_until_s','prediction_target_time_s','viewpoint','targets','input_video_path','input_video_sha256','input_video_fps','input_video_time_origin_s','input_video_size_wh','input_timestamps_s','bbox_coordinate_space']}
        model_inputs.append(row);answers.append({k:q[k] for k in ['qa_id','answer','answer_states','answer_evidence','geometry_artifact','review_status']})
    write_jsonl(OUT/'qa_all.jsonl',qas);write_jsonl(OUT/'model_inputs.jsonl',model_inputs);write_jsonl(OUT/'answers.jsonl',answers)
    # DSR-compatible flat fields, preserving IDs and presentation metadata.
    write_jsonl(OUT/'qa_dsr.jsonl',[dict(qa_id=q['qa_id'],videoID=q['video_id'],Type=q['type'],Question=q['question'],**q['options'],Correct=q['answer'],input_video_path=q['input_video_path'],review_status=q['review_status']) for q in qas])
    report={'qa_validated':len(qas),'unique_ids':len(seen),'answer_recomputed':len(qas),'media_clips':len(result),
            'prediction_qa':sum(q['type'].endswith('_pred') for q in qas),'future_frames_in_prediction_inputs':0,
            'wall_seconds':time.perf_counter()-start,'gpu_executed':False,'visual_review':'pending'}
    write_json(ROOT/'reports/qa_validation.json',report)
    print(json.dumps(report),flush=True)


if __name__=='__main__':main()
