#!/usr/bin/env python3
"""Select videos by STI Dynamic Understanding task labels; no motion model."""
import json
from pathlib import Path
import pandas as pd
from prepare_cpu import DATA, ROOT, read_jsonl, write_json, write_jsonl, sha256

TASKS = ['Displacement & Path Length', 'Speed & Acceleration',
         'Ego-Centric Orientation', 'Trajectory Description', 'Pose Estimation']

def main():
    df = pd.read_parquet(DATA / 'qa.parquet')
    dynamic = df[df.Task.isin(TASKS)]
    inventory = {r['video']: r for r in read_jsonl(ROOT / 'manifests/inventory.jsonl')}
    selected = []
    for video, group in dynamic.groupby('Video', sort=True):
        r = inventory[video]
        if not Path(r['source_video_path']).is_file():
            raise RuntimeError(f'Missing video: {video}')
        selected.append({**r, 'selection_rule': 'has_any_STI_dynamic_understanding_QA',
                         'dynamic_tasks': sorted(group.Task.unique().tolist()),
                         'dynamic_qa_count': len(group),
                         'dynamic_qa_ids': [int(x) for x in group.ID],
                         'independent_object_motion_verified': False})
    ids = {r['video_id'] for r in selected}
    selected_by_id = {r['video_id']: r for r in selected}
    excluded = [{**r, 'reason': 'no_dynamic_understanding_task_annotation'}
                for r in inventory.values() if r['video_id'] not in ids]
    ranked = read_jsonl(ROOT / 'manifests/ranked_candidates.jsonl')
    smoke = []
    for source in sorted({r['source'] for r in selected}):
        candidates = sorted([r for r in ranked if r['source'] == source and r['video_id'] in ids and r['eligible']], key=lambda r: r['source_rank'])
        for r in candidates[:2]:
            smoke.append({**selected_by_id[r['video_id']], 'source_rank': r['source_rank'],
                          'subset': 'dynamic_smoke', 'seed': 260920})
    write_jsonl(ROOT / 'manifests/dynamic_videos.jsonl', selected)
    write_jsonl(ROOT / 'manifests/dynamic_excluded.jsonl', excluded)
    write_jsonl(ROOT / 'manifests/dynamic_smoke_videos.jsonl', smoke)
    summary = dict(selection_basis='STI paper section 3.1 task taxonomy',
                   paper='https://arxiv.org/html/2503.23765v1#S3.SS1',
                   tasks=TASKS, input_qa_sha256=sha256(DATA / 'qa.parquet'),
                   input_video_count=len(inventory), dynamic_video_count=len(selected),
                   dynamic_qa_count=len(dynamic), excluded_video_count=len(excluded),
                   source_video_counts={str(k): int(v) for k,v in dynamic.drop_duplicates('Video').Source.value_counts().items()},
                   task_counts={t: {'qa': int((dynamic.Task==t).sum()),
                                    'videos': int(dynamic[dynamic.Task==t].Video.nunique())} for t in TASKS},
                   smoke_ids=[r['video_id'] for r in smoke],
                   stage1_model_curation='skipped_by_user',gpu_execution=False)
    write_json(ROOT / 'reports/dynamic_selection.json', summary)
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
