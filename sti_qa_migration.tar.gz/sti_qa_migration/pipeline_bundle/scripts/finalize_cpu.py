#!/usr/bin/env python3
"""Validate prepared CPU artifacts and build metadata, window jobs and reports."""
import csv
import json
from pathlib import Path
import sys
import unittest
from PIL import Image
from prepare_cpu import ROOT, read_jsonl, sha256, write_json, write_jsonl


def main():
    rows = read_jsonl(ROOT/'manifests/sampled_videos.jsonl')
    config = json.loads((ROOT/'configs/cpu.json').read_text())
    notes = json.loads((ROOT/'metadata/visual_notes.json').read_text())
    if set(notes) != {r['video_id'] for r in rows}:
        raise ValueError('Visual notes/sample IDs differ')
    objects, captions, windows = [], [], []
    total = 0
    for r in rows:
        vid=r['video_id'];note=notes[vid]
        evidence=dict(method='assistant_contact_sheet_inspection',
                      evidence_path=str(ROOT/'review'/f'{vid}.jpg'),
                      review_scope='16 sampled frames; not a full-video or human QA review',
                      review_status='provisional',source_answers_used=False)
        captions.append(dict(video_id=vid,caption=note['caption'],risk=note['risk'],**evidence))
        objects.append(dict(video_id=vid,agents=note['agents'],objects=note['objects'],
                            orientation_approved=False,grounding_verified=False,**evidence))
        for policy in config['frame_policies']:
            manifest=ROOT/'cache'/vid/policy/'frames.json'
            m=json.loads(manifest.read_text());frames=m['frames']
            if m['source_sha256'] != r['sha256']:
                raise ValueError('Source hash mismatch')
            previous=-1
            for f in frames:
                if f['timestamp_s'] <= previous or f['timestamp_s'] >= r['duration_s']+.1:
                    raise ValueError('Bad frame time')
                previous=f['timestamp_s']
                with Image.open(f['path']) as image:
                    if list(image.size) != m['image_size_wh']:
                        raise ValueError('Frame dimensions differ from source')
                    image.verify()
                total+=1
            starts=[0] if policy=='uniform32' else range(0,len(frames),config['window_stride_frames'])
            for start in starts:
                selected=frames[start:start+config['max_window_frames']]
                if len(selected)<config['minimum_window_frames']:continue
                windows.append(dict(job_id=f'{vid}__{policy}__{start:04d}',video_id=vid,source=r['source'],
                                    subset=r['subset'],sampling_policy=policy,frame_manifest=str(manifest),
                                    sample_indices=[f['sample_index'] for f in selected],
                                    source_frame_indices=[f['source_frame_index'] for f in selected],
                                    timestamps_s=[f['timestamp_s'] for f in selected],
                                    source_video_sha256=r['sha256'],
                                    status='awaiting_verified_3d_geometry',execution_enabled=False))
    write_jsonl(ROOT/'metadata/captions.jsonl',captions)
    write_jsonl(ROOT/'metadata/agent_objects.jsonl',objects)
    write_jsonl(ROOT/'manifests/window_jobs.jsonl',windows)
    with (ROOT/'metadata/agent_object_candidates.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['videoID','agent','obj','status']);w.writeheader()
        for r in objects:w.writerow(dict(videoID=r['video_id'],agent='. '.join(r['agents']),obj='. '.join(r['objects']),status='provisional_not_grounding_verified'))
    # Do not create dynamic_videos.json: ego/object motion and suitability are unverified.
    sys.path.insert(0,str(ROOT/'tests'))
    from test_cpu import fixture
    write_json(ROOT/'tests/fixtures/synthetic_geometry.json',fixture())
    from qa_cpu import generate, validate_qa
    generated, failures=generate(fixture())
    for q in generated:validate_qa(q,fixture())
    write_jsonl(ROOT/'tests/fixtures/synthetic_qa.jsonl',generated)
    write_jsonl(ROOT/'tests/fixtures/synthetic_failures.jsonl',failures)
    with (ROOT/'reports/cpu_tests.txt').open('w') as output:
        result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT/'tests')))
    if not result.wasSuccessful():raise RuntimeError('CPU test failure; see reports/cpu_tests.txt')
    summary=dict(device='cpu',gpu_execution=False,model_loading=False,api_calls=0,
                 pilot_videos=len(rows),smoke_videos=sum(r['subset']=='smoke' for r in rows),
                 verified_jpeg_frames=total,window_jobs=len(windows),
                 provisional_caption_records=len(captions),provisional_object_records=len(objects),
                 tests_run=result.testsRun,tests_passed=True,real_qa_generated=0,
                 synthetic_test_qa=len(generated),config_sha256=sha256(ROOT/'configs/cpu.json'))
    write_json(ROOT/'reports/cpu_summary.json',summary)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
