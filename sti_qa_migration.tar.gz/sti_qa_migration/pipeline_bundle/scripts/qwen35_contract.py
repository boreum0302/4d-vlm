"""CPU-only contracts for direct Qwen object extraction."""
import hashlib
import json
import os
import re
from pathlib import Path

ROOT = Path('.')
from portable_paths import DependencyPath
MODEL = DependencyPath('qwen_model')
PROMPT = ROOT / 'prompts/qwen35_objects.txt'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    temp.replace(path)


def model_inventory(model):
    model = Path(model)
    index = json.loads((model / 'model.safetensors.index.json').read_text())
    shards = sorted(set(index['weight_map'].values()))
    # Record sizes/mtime without reading 18 GiB of weights. This is not a weight checksum.
    return {'path': str(model.resolve()), 'config_sha256': file_hash(model/'config.json'),
            'index_sha256': file_hash(model/'model.safetensors.index.json'),
            'shards': [{'name': s, 'bytes': (model/s).stat().st_size,
                        'mtime_ns': (model/s).stat().st_mtime_ns} for s in shards]}


def parse_objects(text, frame_count):
    text = text.strip()
    # Accept only a complete JSON code fence; never extract arbitrary braces from prose.
    fenced = re.fullmatch(r"```(?:json)?\s*\n(.*?)\n```", text, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        text = fenced.group(1).strip()
    data = json.loads(text)
    if not isinstance(data, dict) or set(data) != {'agents', 'non_agents', 'truncated'}:
        raise ValueError('Expected agents, non_agents, truncated')
    if type(data['truncated']) is not bool:
        raise ValueError('truncated must be boolean')
    seen = set()
    for group in ['agents', 'non_agents']:
        if not isinstance(data[group], list):
            raise ValueError('Object groups must be lists')
        for item in data[group]:
            if not isinstance(item, dict) or set(item) != {'label', 'motion', 'orientation_candidate', 'evidence_frames'}:
                raise ValueError('Invalid object schema')
            label = item['label']
            if not isinstance(label, str) or not re.fullmatch(r'[a-z]+(?:[ -][a-z]+){0,5}', label):
                raise ValueError('Expected short lowercase English noun phrase')
            if label in seen:
                raise ValueError('Duplicate or cross-group label')
            seen.add(label)
            if item['motion'] not in ['moving', 'stationary', 'unknown']:
                raise ValueError('Invalid motion value')
            if type(item['orientation_candidate']) is not bool or (group == 'non_agents' and item['orientation_candidate']):
                raise ValueError('Invalid orientation candidate')
            ids = item['evidence_frames']
            if not isinstance(ids, list) or not 1 <= len(ids) <= frame_count or any(type(i) is not int or not 0 <= i < frame_count for i in ids):
                raise ValueError('Evidence outside supplied interval')
            if len(set(ids)) != len(ids):
                raise ValueError('Duplicate evidence frame')
    if len(seen) > 12:
        raise ValueError('Too many categories')
    labels = [x['label'] for group in ['agents', 'non_agents'] for x in data[group]]
    return {**data, 'grounding_prompt': '. '.join(labels) + ('.' if labels else ''),
            'review_status': 'needs_visual_review'}


def verify_frames(job):
    frames = job['frames']
    if not frames or [f['segment_frame_index'] for f in frames] != list(range(len(frames))):
        raise ValueError('Invalid interval frame indices')
    if frames[0]['timestamp_s'] != job['query_start_s'] or frames[-1]['timestamp_s'] != job['query_end_s']:
        raise ValueError('Interval mismatch')
    for f in frames:
        if file_hash(f['path']) != f['sha256']:
            raise ValueError('Changed/missing frame: ' + f['path'])
    if any(b['timestamp_s'] <= a['timestamp_s'] for a, b in zip(frames, frames[1:])):
        raise ValueError('Nonincreasing frame time')


def build_inputs(processor, job, prompt, max_pixels):
    """CPU PIL/processor only; called by CPU preflight and user GPU runner."""
    from PIL import Image
    images, content = [], [{'type': 'text', 'text': prompt}]
    for i, frame in enumerate(job['frames']):
        with Image.open(frame['path']) as image:
            images.append(image.convert('RGB'))
        content.extend([{'type': 'text', 'text': f'Frame {i}, source time {frame["timestamp_s"]:.3f} seconds:'},
                        {'type': 'image'}])
    text = processor.apply_chat_template([{'role': 'user', 'content': content}],
                                        tokenize=False, add_generation_prompt=True, enable_thinking=False)
    return processor(text=[text], images=images, return_tensors='pt',
                     images_kwargs={'size': {'shortest_edge': 4096, 'longest_edge': max_pixels}})


def completed(path, signature):
    marker = Path(path)/'complete.json'
    if not marker.exists():
        return False
    record = json.loads(marker.read_text())
    if record['run_signature'] != signature:
        raise ValueError('Existing output settings differ; use a new --output-root')
    for name, expected in record['artifact_sha256'].items():
        if file_hash(Path(path)/name) != expected:
            raise ValueError('Completed artifact changed')
    return True
