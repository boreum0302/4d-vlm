from portable_paths import configured
import sys
print(configured(sys.argv[1]))
