#!/usr/bin/env python3
"""Strict QA-specific CPU screening. No GPU, model, viewer, or source QA mutation."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import copy,json,re,time,collections
from functools import lru_cache
from pathlib import Path
import numpy as np
from PIL import Image
import qa_cpu
qa_cpu.load_rules=lru_cache(maxsize=1)(qa_cpu.load_rules)
from orient_contract import ROOT,read_jsonl,write_json,file_hash,verify_upstream
from prepare_cpu import write_jsonl
from dsr_qa_contract import attributes,classify,validate_qa,stable_seed
from select_sam2_candidates import AGENTS,EXCLUDE
POLICY={'max_answer_states':3,'min_detection_score':.5,'min_mask_area_fraction':.002,
 'min_valid_points':64,'min_valid_point_fraction':.5,'min_mean_point_confidence':.5,
 'max_adjacent_mask_area_ratio':2,'max_cross_label_mask_iou':.5,'min_orientation_confidence':.85,
 'max_orientation_step_degrees':20,'camera_jump_floor_degrees':15,'camera_jump_floor_scene_scale':.15,'pose_jump_median_multiplier':4,
 'center_jump_floor_scene_scale':.2,'avoid_unique_answer_state_count_extreme':True,'relative_scale_checks':[.25,.5,2,4],
 'min_perturbation_agreement':.95,'prediction_min_cosine':.95,'prediction_max_observed_speed_cv':.25,
 'center_checks':['median_valid_points','mean_confidence_ge_0.5'],
 'scope':'QA referenced tracks and required frames only; no video-wide category/evidence gate',
 'status':'automatic_screening_only_not_visual_ground_truth'}


def option_key(text):
    text=re.sub(r'\(\d+\)','',text.lower()).replace('becomes','become').replace('always ','')
    text=text.replace('their speed is nearly the same','nearly the same').replace('keep nearly constant','nearly constant')
    return re.sub(r'\s+',' ',text).strip()


def angle_steps(vectors):
    v=np.asarray(vectors,float);v=v/np.linalg.norm(v,axis=1,keepdims=True)
    return np.degrees(np.arccos(np.clip(np.sum(v[1:]*v[:-1],axis=1),-1,1)))


def load_job(q):
    path=Path(q['geometry_artifact']);g=json.loads(path.read_text());g['geometry_sha256']=file_hash(path)
    paths={k:Path(v) for k,v in g['upstream'].items()}
    for key,path in paths.items():
        if verify_upstream(path)!=g['upstream_marker_sha256'][key]:raise ValueError('Upstream provenance changed: '+key)
    data={k:json.loads((paths[k]/name).read_text()) for k,name in [('sam2','tracks.json'),('trajectory','trajectories.json'),('orientation','orientations.json')]}
    data['g']=g;data['paths']=paths;data['tracks']={str(t['track_id']):t for t in data['sam2']['tracks']}
    data['centers']={str(t['track_id']):t for t in data['trajectory']['tracks']};data['orientations']={str(t['track_id']):t for t in data['orientation']['tracks']}
    data['mask_cache']={};data['alternatives']={}
    return data


def needed(q,n):
    ids=q['answer_evidence']['target_ids'];observer=q['viewpoint']['track_id'];kind=q['type'];pred=kind.endswith('_pred')
    frames=list(range(n));targetframes=frames if not pred else list(range(n-5,n))
    observerframes=targetframes if kind.startswith('rel_') else [0]
    positions={};orientations={};appearance={}
    def add(d,tid,ii):
        if tid!='camera':d.setdefault(tid,set()).update(ii)
    for tid in ids:
        add(appearance,tid,targetframes)
        add(orientations if kind.endswith('_ori') else positions,tid,targetframes)
    add(appearance,observer,observerframes);add(positions,observer,observerframes);add(orientations,observer,observerframes)
    return positions,orientations,appearance


def frame_masks(data,i):
    if i not in data['mask_cache']:
        with np.load(data['paths']['sam2']/'masks'/f'{i:03d}.npz',allow_pickle=False) as z:
            data['mask_cache'][i]={str(t):m for t,m in zip(z['track_ids'],z['masks'])}
    return data['mask_cache'][i]


def alternate_centers(data,tid):
    if tid in data['alternatives']:return data['alternatives'][tid]
    if 'local' not in data:
        with np.load(data['paths']['pi3']/'scene_geometry.npz',allow_pickle=False) as z:
            data['local']=z['local_points'];data['valid']=z['valid_mask'];data['confidence']=z['confidence'];data['poses']=z['camera_to_world']
    local=data['local'];h,w=local.shape[1:3];med=[];strong=[]
    for i in range(len(local)):
        mask=frame_masks(data,i)[tid];grid=np.asarray(Image.fromarray(mask).resize((w,h),Image.Resampling.NEAREST),bool)
        valid=grid&data['valid'][i]&np.isfinite(local[i]).all(-1)&(local[i,...,2]>0)
        confident=valid&(data['confidence'][i]>=.5)
        pose=data['poses'][i]
        for arr,chosen,method in [(med,valid,'median'),(strong,confident,'mean')]:
            points=local[i][chosen]
            p=(np.median(points,axis=0) if method=='median' else points.mean(axis=0,dtype=np.float64)) if len(points) else None
            arr.append((pose[:3,:3]@p+pose[:3,3]).tolist() if p is not None else [None]*3)
    data['alternatives'][tid]=(med,strong);return med,strong


def review(q,data):
    g=data['g'];n=len(g['timestamps_s']);reasons=[];metrics={};validate_qa(q,g)
    kind=q['type'];ids=q['answer_evidence']['target_ids'];observer=q['viewpoint']['track_id'];answer=q['answer_states']
    value=np.asarray(q['answer_evidence']['attribute_values']);pos,ori,app=needed(q,n)
    if len(re.findall(r'\(\d+\)',answer))>POLICY['max_answer_states']:reasons.append('too_many_answer_states')
    if len({option_key(x) for x in q['options'].values()})<4:reasons.append('semantically_duplicate_options')
    option_lengths=[len(re.findall(r'\(\d+\)',x)) for x in q['options'].values()]
    answer_length=len(re.findall(r'\(\d+\)',answer))
    if option_lengths.count(answer_length)==1 and answer_length in [min(option_lengths),max(option_lengths)]:reasons.append('answer_state_count_length_cue')
    for factor in POLICY['relative_scale_checks']:
        if kind.endswith(('_dis','_spd','_comp')) and classify(value*factor,kind)!=answer:
            reasons.append('answer_depends_on_arbitrary_pi3_scale');break
    rng=np.random.default_rng(stable_seed(q['qa_id']+':strict_review'))
    agree=sum(classify(value*rng.uniform(.95,1.05,value.shape),kind)==answer for _ in range(40))/40
    metrics['five_percent_perturbation_agreement']=agree
    if agree<POLICY['min_perturbation_agreement']:reasons.append('answer_near_numeric_boundary')
    poses=np.asarray(g['camera_to_world']);rot=poses[:,:3,:3];relative=np.einsum('nji,njk->nik',rot[:-1],rot[1:])
    camera_angles=np.degrees(np.arccos(np.clip((np.trace(relative,axis1=1,axis2=2)-1)/2,-1,1)))
    camera_steps=np.linalg.norm(np.diff(poses[:,:3,3],axis=0),axis=1)/g['scene_scale']
    metrics['max_camera_rotation_step_deg']=float(camera_angles.max());metrics['max_camera_translation_step_relative']=float(camera_steps.max())
    if camera_angles.max()>max(15,4*np.median(camera_angles)) or camera_steps.max()>max(.15,4*np.median(camera_steps)):reasons.append('isolated_camera_pose_jump')
    for tid,ii in app.items():
        t=data['tracks'][tid];label=t['label']
        if label in EXCLUDE:reasons.append('ambiguous_background_or_part_label:'+tid)
        if t['group']=='non_agents' and label in AGENTS:reasons.append('agent_classification_conflict:'+tid)
        if t['score']<POLICY['min_detection_score']:reasons.append('weak_object_detection:'+tid)
        areas=[]
        for i in sorted(ii):
            mask=frame_masks(data,i)[tid];area=int(mask.sum());areas.append(area)
            if area/mask.size<POLICY['min_mask_area_fraction']:reasons.append('small_or_empty_mask:'+tid);break
            ys,xs=np.nonzero(mask)
            if xs.min()==0 or ys.min()==0 or xs.max()==mask.shape[1]-1 or ys.max()==mask.shape[0]-1:
                reasons.append('object_clipped_at_image_boundary:'+tid);break
            for other,m in frame_masks(data,i).items():
                if other==tid:continue
                union=np.logical_or(mask,m).sum()
                if union and np.logical_and(mask,m).sum()/union>POLICY['max_cross_label_mask_iou']:
                    reasons.append('overlapping_track_identity:'+tid);break
        if len(areas)>1 and (np.maximum(np.asarray(areas)[1:],1)/np.maximum(np.asarray(areas)[:-1],1)).max()>2:reasons.append('mask_area_jump:'+tid)
        if len(areas)>1 and (np.maximum(np.asarray(areas)[:-1],1)/np.maximum(np.asarray(areas)[1:],1)).max()>2:reasons.append('mask_area_jump:'+tid)
    for tid,ii in pos.items():
        samples=data['centers'][tid]['samples']
        for i in ii:
            x=samples[i]
            if x['valid_point_count']<64 or x['valid_point_fraction']<.5 or (x['mean_confidence'] or 0)<.5:
                reasons.append('weak_3d_support:'+tid);break
        points=np.array([samples[i]['center_world'] or [np.nan]*3 for i in sorted(ii)])
        if len(points)>1:
            steps=np.linalg.norm(np.diff(points,axis=0),axis=1)/g['scene_scale']
            if np.isfinite(steps).any() and np.nanmax(steps)>max(.2,4*np.nanmedian(steps)):reasons.append('isolated_center_jump:'+tid)
    for tid,ii in ori.items():
        t=data['orientations'].get(tid);samples=t['samples'] if t else []
        if not samples or any(samples[i]['status']!='predicted' or samples[i]['angles']['confidence']<.85 for i in ii):
            reasons.append('weak_or_missing_orientation:'+tid);continue
        vectors=[np.asarray(samples[i]['rotation_agent_to_world_dsr'])[:,0] for i in sorted(ii)]
        if len(vectors)>1 and angle_steps(vectors).max()>20:reasons.append('orientation_jump:'+tid)
    if kind.endswith('_pred'):
        # Compare the last two observed displacements and held-out displacement in the same QA observer definition.
        if observer!='camera':reasons.append('agent_view_prediction_requires_visual_review')
        from dsr_qa_contract import entities
        es=entities(g);ii=np.array([n-5,n-4,n-3,n-1]);refs=ii if kind.startswith('rel_') else np.zeros(4,int)
        target=es[ids[0]];obs=es[observer]
        if not target['v'][ii].all() or not obs['v'][refs].all() or not obs['rv'][refs].all():reasons.append('prediction_observed_motion_missing')
        else:
            c=np.einsum('nij,nj->ni',obs['r'][refs],target['p'][ii]-obs['p'][refs]);v=np.diff(c,axis=0)/np.diff(np.asarray(g['timestamps_s'])[ii])[:,None];speed=np.linalg.norm(v,axis=1)
            if speed.min()<g['scene_scale']*.01:reasons.append('prediction_motion_too_small')
            else:
                cosine=np.sum(v[1:]*v[:-1],axis=1)/(speed[1:]*speed[:-1]);cv=float(speed[:2].std()/speed[:2].mean())
                metrics['prediction_min_direction_cosine']=float(cosine.min());metrics['prediction_observed_speed_cv']=cv
                if cosine.min()<.95 or cv>.25:reasons.append('prediction_not_supported_by_steady_observed_motion')
    # Expensive spatial estimator checks are performed only after basic screening passes.
    if not reasons and pos:
        for variant in [0,1]:
            altered=copy.deepcopy(g)
            for track in altered['tracks']:
                if track['track_id'] in pos:track['centers_world']=alternate_centers(data,track['track_id'])[variant]
            try:
                if classify(attributes(altered,kind,ids,observer),kind)!=answer:reasons.append('answer_changes_with_center_estimator')
            except ValueError:reasons.append('alternate_center_unavailable')
    return sorted(set(reasons)),metrics


def main():
    start=time.perf_counter();source=ROOT/'outputs/dsr_qa';out=ROOT/'outputs/qa_review';out.mkdir(exist_ok=True)
    qas=read_jsonl(source/'qa_all.jsonl');groups=collections.defaultdict(list)
    for q in qas:groups[q['geometry_artifact']].append(q)
    passed=[];held=[];audit=[]
    for i,qs in enumerate(groups.values(),1):
        data=load_job(qs[0])
        for q in qs:
            try:reasons,metrics=review(q,data)
            except (ValueError,AssertionError,FloatingPointError) as e:reasons=['integrity_or_numeric_error:'+str(e)];metrics={}
            record={'qa_id':q['qa_id'],'video_id':q['video_id'],'type':q['type'],'status':'strict_auto_pass' if not reasons else 'held',
                    'reasons':reasons,'metrics':metrics};audit.append(record)
            if reasons:held.append(record)
            else:
                x=copy.deepcopy(q);x['review_status']='strict_auto_pass_visual_review_pending';x['quality_review']=record;passed.append(x)
        if i%50==0 or i==len(groups):print(f'{i}/{len(groups)} videos: pass={len(passed)} held={len(held)} elapsed={time.perf_counter()-start:.1f}s',flush=True)
    write_jsonl(out/'qa_passed.jsonl',passed);write_jsonl(out/'qa_held.jsonl',held);write_jsonl(out/'audit_all.jsonl',audit)
    ids={q['qa_id'] for q in passed}
    for name in ['model_inputs','answers','qa_dsr']:
        rows=read_jsonl(source/f'{name}.jsonl');rows=[r for r in rows if r['qa_id'] in ids]
        for r in rows:
            if 'review_status' in r:r['review_status']='strict_auto_pass_visual_review_pending'
        write_jsonl(out/f'{name}_passed.jsonl',rows)
    report={'input_qa':len(qas),'passed_qa':len(passed),'held_qa':len(held),'passed_videos':len({q['video_id'] for q in passed}),
       'type_counts':dict(collections.Counter(q['type'] for q in passed)),'source_counts':dict(collections.Counter(q['source'] for q in passed)),
       'viewpoint_counts':dict(collections.Counter('camera' if q['viewpoint']['track_id']=='camera' else 'agent' for q in passed)),
       'reason_counts':dict(collections.Counter(r.split(':')[0] for x in held for r in x['reasons'])),
       'policy':POLICY,'wall_seconds':time.perf_counter()-start,'gpu_executed':False,'viewer_created':False,
       'source_qa_sha256':file_hash(source/'qa_all.jsonl'),'script_sha256':file_hash(__file__),
       'visual_review':'pending; not a guarantee of semantic object/track correctness'}
    write_json(ROOT/'reports/qa_review_summary.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
