"""CPU-only snapshot recovery of saved responses; never mark original GPU jobs complete."""
import json
from qwen35_contract import ROOT,read_jsonl,parse_objects,file_hash,write_json

def main():
    records=[];errors=[]
    for j in read_jsonl(ROOT/'manifests/qwen35_objects_all.jsonl'):
        p=ROOT/'artifacts/qwen35_objects'/j['video_id']/j['segment_id']/'raw_response.json'
        if not p.exists():continue
        try:
            content=p.read_bytes();raw=json.loads(content)
            if raw['generated_tokens']>=1536:raise ValueError('Hit original token limit')
            data=parse_objects(raw['text'],len(j['frames']))
            records.append(dict(data,job_id=j['job_id'],video_id=j['video_id'],segment_id=j['segment_id'],frames=j['frames'],query_start_s=j['query_start_s'],query_end_s=j['query_end_s'],raw_response_path=str(p),raw_response_sha256=__import__('hashlib').sha256(content).hexdigest(),recovery='CPU reparsing; original failed runner did not persist full inference provenance/quality; not an original complete marker'))
        except Exception as e:errors.append({'job_id':j['job_id'],'error':str(e)})
    out=ROOT/'artifacts/qwen35_recovered';out.mkdir(exist_ok=True)
    tmp=out/'objects_recovered.jsonl.tmp';tmp.write_text(''.join(json.dumps(x)+'\n' for x in records));tmp.replace(out/'objects_recovered.jsonl')
    report=dict(snapshot_only=True,recovered=len(records),parse_failed=len(errors),errors=errors,gpu_executed=False,output=str(out/'objects_recovered.jsonl'),note='Original outputs unchanged; candidates require visual review; source run may still be writing.')
    write_json(ROOT/'reports/qwen35_recovery.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='errors'}))

if __name__=='__main__':main()
