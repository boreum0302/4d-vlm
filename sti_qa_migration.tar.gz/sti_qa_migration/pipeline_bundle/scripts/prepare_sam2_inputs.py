#!/usr/bin/env python3
"""CPU-only stage-6 inputs: all schema-validated stage-5 jobs; quality review follows inference."""
import argparse,json,collections
from sam2_contract import ROOT,DINO,SAM,read_jsonl,qwen_objects,verify_frames,write_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--subset',choices=['smoke','all'],default='smoke')
    p.add_argument('--allow-partial',action='store_true')
    a=p.parse_args()
    source=ROOT/'artifacts/qwen35_validated/objects_all.jsonl'
    validated=read_jsonl(source)
    ids={j['job_id'] for j in validated}
    if len(ids)!=len(validated):raise ValueError('Duplicate validated job IDs')
    original=read_jsonl(ROOT/'manifests/pi3_all_s260920_k1_f8-32.jsonl')
    if ids-{j['job_id'] for j in original}:raise ValueError('Unknown validated job IDs')
    jobs=[j for j in original if j['job_id'] in ids]
    if a.subset=='smoke':
        jobs=[j for source_name in sorted({j['source'] for j in jobs})
              for j in sorted([x for x in jobs if x['source']==source_name],key=lambda x:x['job_id'])[:2]]
    ready=[];excluded=[]
    for job in jobs:
        try:
            verify_frames(job)
            obj=qwen_objects(job)
            ready.append(dict(job,object_input=obj))
        except (OSError,ValueError,KeyError) as e:
            excluded.append({'job_id':job['job_id'],'reason':str(e)})
    path=ROOT/f'manifests/sam2_{a.subset}.jsonl'
    report={'requested':len(jobs),'ready':len(ready),'excluded':excluded,'allow_partial':a.allow_partial,
            'subset':a.subset,'source':str(source),'manifest':str(path),'gpu_executed':False,
            'selection_policy':'stage5_schema_validated_only; quality_review_after_inference',
            'upstream_unvalidated':len(original)-len(ids),'frames':sum(len(j['frames']) for j in ready),
            'sources':dict(collections.Counter(j['source'] for j in ready)),
            'weights_present':(DINO/'model.safetensors').is_file() and SAM.is_file()}
    write_json(ROOT/f'reports/sam2_preparation_{a.subset}.json',report)
    if not ready or not report['weights_present'] or (excluded and not a.allow_partial):
        raise SystemExit('Inputs incomplete. Inspect preparation report; existing manifest was not replaced.')
    temp=path.with_suffix('.jsonl.tmp');temp.write_text(''.join(json.dumps(j)+'\n' for j in ready));temp.replace(path)
    print(json.dumps({k:v for k,v in report.items() if k!='excluded'}))


if __name__=='__main__':main()
