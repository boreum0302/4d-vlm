#!/usr/bin/env python3
"""CPU-only inventory, deterministic video sampling, frame cache and review UI."""
import argparse
import concurrent.futures
import hashlib
import html
import json
import os
from pathlib import Path
import random
import subprocess
import sys

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

ROOT = Path('.')
from portable_paths import configured
DATA = configured('sti_bench')
SEED = 260920


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(''.join(json.dumps(r, ensure_ascii=False, allow_nan=False) + '\n' for r in rows))
    tmp.replace(path)


def read_jsonl(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def run(args, timeout=180):
    p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(f'{args[0]} exit={p.returncode}: {p.stderr[-2000:]}')
    return p.stdout


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def probe_video(row):
    row = dict(row)
    path = row['source_video_path']
    try:
        p = json.loads(run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                            '-show_streams', '-show_format', '-of', 'json', path]))
        s = p['streams'][0]
        num, den = map(int, s['avg_frame_rate'].split('/'))
        row.update(width=s['width'], height=s['height'], fps=num / den,
                   fps_rational=s['avg_frame_rate'],
                   duration_s=float(s.get('duration', p['format']['duration'])),
                   declared_frame_count=int(s['nb_frames']) if s.get('nb_frames', '').isdigit() else None,
                   size_bytes=Path(path).stat().st_size, sha256=sha256(path), codec=s['codec_name'])
        # Software decode only, one CPU thread per process; no hardware acceleration.
        stderr = subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-nostdin',
                                 '-threads', '1', '-i', path, '-map', '0:v:0', '-an',
                                 '-f', 'null', '-'], capture_output=True, text=True, timeout=180)
        row['decode_ok'] = stderr.returncode == 0 and not stderr.stderr.strip()
        row['decode_error'] = stderr.stderr[-1500:] or None
        row['eligible'] = row['decode_ok'] and row['duration_s'] > 0 and row['fps'] > 0
        row['error'] = None
    except Exception as e:
        row.update(eligible=False, decode_ok=False, error=str(e))
    return row


def inventory(workers):
    df = pd.read_parquet(DATA / 'qa.parquet')
    other = pd.read_parquet(DATA / 'data/test-00000-of-00001.parquet')
    rows = []
    for video, g in df.groupby('Video', sort=True):
        if g.Source.nunique() != 1 or g.scene.nunique() != 1:
            raise ValueError(f'Conflicting source/scene: {video}')
        rows.append(dict(video_id=Path(video).stem, video=video, source=g.Source.iloc[0],
                         scene=g.scene.iloc[0], source_video_path=str(DATA / 'video' / video),
                         source_qa_ids=[int(x) for x in g.ID], source_qa_count=len(g)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        results = []
        for i, row in enumerate(pool.map(probe_video, rows), 1):
            results.append(row)
            if i % 25 == 0 or i == len(rows):
                print(f'inventory {i}/{len(rows)}', flush=True)
    write_jsonl(ROOT / 'manifests/inventory.jsonl', results)
    duplicates = {}
    for r in results:
        if r.get('sha256'):
            duplicates.setdefault(r['sha256'], []).append(r['video_id'])
    extras = sorted(p.name for p in (DATA / 'video').glob('*.mp4') if p.name not in set(df.Video))
    stats = dict(qa_rows=len(df), unique_videos=len(rows), metadata_files_equal=df.equals(other),
                 unreferenced_video_files=extras, eligible=sum(r['eligible'] for r in results),
                 duplicate_content_groups=[v for v in duplicates.values() if len(v) > 1],
                 source_counts={str(k): int(v) for k, v in pd.DataFrame(results).source.value_counts().items()})
    for source in sorted(df.Source.unique()):
        durations = [r['duration_s'] for r in results if r['source'] == source and r['eligible']]
        stats.setdefault('duration_summary_s', {})[source] = dict(zip(
            ['min', 'p25', 'median', 'p75', 'max'], np.percentile(durations, [0, 25, 50, 75, 100]).tolist()))
    write_json(ROOT / 'reports/inventory_summary.json', stats)
    print(json.dumps(stats, indent=2), flush=True)


def sample():
    rows = read_jsonl(ROOT / 'manifests/inventory.jsonl')
    selected, ranked, rejected, seen = [], [], [], set()
    for source in sorted({r['source'] for r in rows}):
        group = sorted([r for r in rows if r['source'] == source], key=lambda r: r['video_id'])
        random.Random(f'{SEED}:{source}').shuffle(group)
        accepted = 0
        for rank, r in enumerate(group, 1):
            r = {**r, 'seed': SEED, 'source_rank': rank}
            reason = None
            if not r['eligible']:
                reason = 'probe_or_decode_failed'
            elif r['sha256'] in seen:
                reason = 'duplicate_video_content'
            elif r.get('declared_frame_count') is not None and r['declared_frame_count'] < 32:
                reason = 'fewer_than_32_frames'
            if reason:
                rejected.append({**r, 'rejection_reason': reason})
            elif accepted < 10:
                accepted += 1
                seen.add(r['sha256'])
                r.update(subset='smoke' if accepted <= 2 else 'pilot',
                         suitability_status='pending_visual_and_geometry_review')
                selected.append(r)
            ranked.append(r)
        if accepted < 10:
            raise RuntimeError(f'Insufficient eligible videos for {source}: {accepted}')
    write_jsonl(ROOT / 'manifests/ranked_candidates.jsonl', ranked)
    write_jsonl(ROOT / 'manifests/sampled_videos.jsonl', selected)
    write_jsonl(ROOT / 'manifests/smoke_videos.jsonl', [r for r in selected if r['subset'] == 'smoke'])
    write_jsonl(ROOT / 'manifests/rejected_videos.jsonl', rejected)
    print('Selected 30 pilot videos, including 6 smoke videos.', flush=True)


def select_indices(times, policy):
    times = np.asarray(times, dtype=float)
    if len(times) < 32 or not np.isfinite(times).all() or (np.diff(times) <= 0).any():
        raise ValueError('Need >=32 frames and strictly increasing finite PTS')
    if policy == 'uniform32':
        return np.rint(np.linspace(0, len(times) - 1, 32)).astype(int).tolist()
    if policy != '1fps':
        raise ValueError(policy)
    targets = np.arange(0, times[-1] + 1e-9, 1.0)
    # Nearest native frame, never duplicated; preserves native frame PTS.
    return sorted(set(int(np.argmin(np.abs(times - t))) for t in targets))


def extract_video(row):
    vid = row['video_id']
    base = ROOT / 'cache' / vid
    base.mkdir(parents=True, exist_ok=True)
    p = json.loads(run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                       '-show_frames', '-show_entries', 'frame=best_effort_timestamp_time',
                       '-of', 'json', row['source_video_path']]))
    native = [float(f['best_effort_timestamp_time']) for f in p['frames']]
    times = np.array(native) - native[0]
    write_json(base / 'native_timestamps.json', dict(pts_origin_s=native[0], timestamps_s=times.tolist()))
    counts = {}
    for policy in ['uniform32', '1fps']:
        indices = select_indices(times, policy)
        dest = base / policy
        dest.mkdir(exist_ok=True)
        frames = [dict(sample_index=j, source_frame_index=i, timestamp_s=float(times[i]),
                       source_pts_s=native[i], path=str(dest / f'{j:03d}.jpg')) for j, i in enumerate(indices)]
        signature = dict(source_sha256=row['sha256'], policy=policy, frame_indices=indices)
        stamp = dest / 'complete.json'
        complete = stamp.exists() and json.loads(stamp.read_text()) == signature
        if not complete or not all(Path(f['path']).exists() for f in frames):
            expr = '+'.join(f'eq(n\\,{i})' for i in indices)
            run(['ffmpeg', '-v', 'error', '-xerror', '-nostdin', '-y', '-threads', '1',
                 '-i', row['source_video_path'], '-vf', f'select={expr}', '-vsync', '0',
                 '-q:v', '2', '-threads', '1', '-start_number', '0', str(dest / '%03d.jpg')])
            if len(list(dest.glob('*.jpg'))) != len(frames):
                raise ValueError(f'{vid}/{policy}: extracted count mismatch')
            write_json(stamp, signature)
        write_json(dest / 'frames.json', dict(video_id=vid, policy=policy, source_sha256=row['sha256'],
                   image_size_wh=[row['width'], row['height']], frames=frames))
        counts[policy] = len(frames)
    selected = json.loads((base / 'uniform32/frames.json').read_text())['frames']
    cell_w, cell_h = 320, 206
    sheet = Image.new('RGB', (cell_w * 4, cell_h * 4), '#111111')
    draw = ImageDraw.Draw(sheet)
    thumbs = []
    for k, i in enumerate(np.rint(np.linspace(0, 31, 16)).astype(int)):
        f = selected[i]
        with Image.open(f['path']) as image:
            image.thumbnail((320, 180))
            x, y = k % 4 * cell_w, k // 4 * cell_h
            sheet.paste(image, (x, y))
            draw.text((x + 4, y + 184), f'{vid} | frame {f["source_frame_index"]} | {f["timestamp_s"]:.3f}s', fill='white')
        with Image.open(f['path']) as image:
            thumbs.append(np.asarray(image.convert('L').resize((64, 36)), dtype=float))
    review = ROOT / 'review'
    review.mkdir(exist_ok=True)
    sheet.save(review / f'{vid}.jpg', quality=90)
    # This is a visual-change cue, not optical flow or an object-motion classification.
    change = [float(np.abs(a - b).mean() / 255) for a, b in zip(thumbs, thumbs[1:])]
    return dict(video_id=vid, frame_counts=counts, thumbnail_luminance_change=change,
                possible_cut_review=any(v > .25 for v in change), status='ok')


def frames(workers):
    rows = read_jsonl(ROOT / 'manifests/sampled_videos.jsonl')
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(extract_video, r): r for r in rows}
        for future in concurrent.futures.as_completed(futures):
            row = futures[future]
            try:
                results.append(future.result())
            except Exception as e:
                results.append(dict(video_id=row['video_id'], status='failed', error=str(e)))
            print(f'frames {len(results)}/{len(rows)}: {row["video_id"]} {results[-1]["status"]}', flush=True)
    write_jsonl(ROOT / 'reports/frame_preparation.jsonl', sorted(results, key=lambda r: r['video_id']))
    cards = []
    for row in rows:
        vid = html.escape(row['video_id'])
        cards.append(f'<article><h2>{vid} · {html.escape(row["source"])} · {row["subset"]}</h2>'
                     f'<p>{row["duration_s"]:.2f}s · {row["width"]}×{row["height"]}</p>'
                     f'<a href="{vid}.jpg"><img loading="lazy" src="{vid}.jpg"></a>'
                     f'<video controls preload="none" src="videos/{vid}.mp4"></video></article>')
        links = ROOT / 'review/videos'
        links.mkdir(exist_ok=True)
        link = links / f'{row["video_id"]}.mp4'
        if not link.exists():
            link.symlink_to(os.path.relpath(row['source_video_path'], link.parent))
    (ROOT / 'review/index.html').write_text('<!doctype html><meta charset="utf-8"><title>STI QA pilot review</title>'
        '<style>body{background:#17191d;color:#eee;font:16px sans-serif;max-width:1300px;margin:24px auto}'
        'img{width:100%}video{width:640px;max-width:100%}article{margin-bottom:48px}</style>'
        '<h1>STI pilot: 30 videos</h1><p>Contact sheets are sampling aids; watch the video to verify motion.</p>' + ''.join(cards))
    if any(r['status'] != 'ok' for r in results):
        raise RuntimeError('Frame preparation failures; see reports/frame_preparation.jsonl')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['inventory', 'sample', 'frames', 'all'])
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    if args.workers < 1 or args.workers > 8:
        parser.error('workers must be between 1 and 8')
    for stage, func in [('inventory', lambda: inventory(args.workers)), ('sample', sample),
                        ('frames', lambda: frames(args.workers))]:
        if args.stage in [stage, 'all']:
            func()


if __name__ == '__main__':
    main()
