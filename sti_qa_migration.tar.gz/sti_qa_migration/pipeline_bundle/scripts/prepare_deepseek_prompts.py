#!/usr/bin/env python3
"""Prepare caption-guided DeepSeek-R1 prompts offline; no API/model/GPU calls."""
import argparse
import hashlib
import json
from pathlib import Path
from prepare_cpu import ROOT, read_jsonl, write_json, write_jsonl

PROMPT = ('"{caption}" is the caption of a video. In one line, list all classes '
          'of agents in the video and use dot to separate them. If there is no '
          'agent, output "None" in this line. Then, in a new line, list the '
          'classes of remaining foreground objects in the video and use dot '
          'to separate them. An object should be a discrete, countable item '
          '(e.g., a bottle, a rock). The object must not be a part of other '
          'objects. If there is no object, output "None" in this line.')


def parse_categories(text):
    """Strict two-line adapter for a later DeepSeek response; never call an API."""
    lines=text.strip().splitlines()
    if len(lines)!=2:raise ValueError('Expected exactly two lines: agents, non-agents')
    groups=[]
    for line in lines:
        if line.strip().lower().rstrip('.')=='none':
            groups.append([]);continue
        values=[x.strip().lower() for x in line.split('.') if x.strip()]
        if not values or any(x=='none' or any(c in x for c in ':`\n') for x in values):
            raise ValueError('Invalid category line; keep raw response and retry/review')
        groups.append(list(dict.fromkeys(values)))
    if set(groups[0]) & set(groups[1]):raise ValueError('Category appears in both agent and non-agent lists')
    return dict(agents=groups[0],objects=groups[1],grounding_prompt='. '.join(groups[0]+groups[1])+'.' if any(groups) else '')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--subset',choices=['smoke','all'],default='smoke')
    a=p.parse_args()
    name='dynamic_smoke_videos.jsonl' if a.subset=='smoke' else 'dynamic_videos.jsonl'
    videos=read_jsonl(ROOT/'manifests'/name)
    captions={r['video_id']:r for r in read_jsonl(ROOT/'metadata/captions.jsonl')}
    requests=[];missing=[]
    for video in videos:
        vid=video['video_id'];record=captions.get(vid)
        if not record or not record.get('caption','').strip():
            missing.append(dict(video_id=vid,reason='caption_missing',source_video_path=video['source_video_path']));continue
        caption=record['caption']
        requests.append(dict(video_id=vid,requested_model='DeepSeek-R1',
            caption=caption,caption_sha256=hashlib.sha256(caption.encode()).hexdigest(),
            caption_source=record.get('method'),caption_review_status=record.get('review_status','unknown'),
            prompt=PROMPT.format(caption=caption),output_contract='two lines: dot-separated agents; dot-separated remaining foreground objects; None for empty',
            state='prompt_prepared_not_sent',api_called=False,
            note='Whole-video caption; verify object presence within each selected QA interval with Grounded SAM2.'))
    write_jsonl(ROOT/'metadata'/f'deepseek_prompts_{a.subset}.jsonl',requests)
    write_jsonl(ROOT/'metadata'/f'deepseek_missing_captions_{a.subset}.jsonl',missing)
    report=dict(subset=a.subset,videos=len(videos),prompts_prepared=len(requests),missing_captions=len(missing),
                model_inference=False,api_calls=0,
                original_prompt_source='external/DSR_Suite/data/deepseek_agent.py',
                provisional_captions=sum(r['caption_review_status']!='accepted' for r in requests))
    write_json(ROOT/'reports'/f'deepseek_prompt_preparation_{a.subset}.json',report)
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
