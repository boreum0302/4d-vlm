#!/usr/bin/env python3
"""CPU-only, geometry-grounded DSR-style QA. Never imports torch or loads models.

Supports camera viewpoints and distance/direction/speed/comparison (8 types).
Orientation/prediction are explicitly deferred; no fabricated geometry fallback.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re

import numpy as np

from prepare_cpu import ROOT, read_jsonl, sha256, write_jsonl

TEMPLATE = ROOT / 'vendor/dsr_template.py'
SUPPORTED = ['abs_dis', 'rel_dis', 'abs_dir', 'rel_dir', 'abs_spd', 'rel_spd',
             'abs_spd_comp', 'rel_spd_comp']


def load_rules():
    spec = importlib.util.spec_from_file_location('dsr_rules', TEMPLATE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_geometry(g):
    if g.get('coordinate_system') != 'opencv_camera_to_world':
        raise ValueError('coordinate_system must be opencv_camera_to_world')
    if g.get('is_metric') is not False:
        raise ValueError('Explicit relative-scale geometry required: is_metric=false')
    ts = np.asarray(g['timestamps_s'], dtype=float)
    if ts.ndim != 1 or len(ts) < 4 or not np.isfinite(ts).all() or (np.diff(ts) <= 0).any():
        raise ValueError('Need >=4 strictly increasing finite timestamps')
    poses = np.asarray(g['camera_to_world'], dtype=float)
    if poses.shape != (len(ts), 4, 4) or not np.isfinite(poses).all():
        raise ValueError('Invalid camera poses')
    if not np.allclose(poses[:, 3, :], [0, 0, 0, 1], atol=1e-5):
        raise ValueError('Invalid homogeneous transform')
    rot = poses[:, :3, :3]
    if not np.allclose(rot.transpose(0, 2, 1) @ rot, np.eye(3), atol=1e-3) or not np.allclose(np.linalg.det(rot), 1, atol=1e-3):
        raise ValueError('Pose rotations must be orthonormal with determinant +1')
    if len(g['source_frame_indices']) != len(ts) or any(b <= a for a, b in zip(g['source_frame_indices'], g['source_frame_indices'][1:])):
        raise ValueError('Invalid source frame indices')
    width, height = g['image_size_wh']
    if width <= 0 or height <= 0:
        raise ValueError('Invalid image size')
    seen = {'camera'}
    for track in g['tracks']:
        if track['track_id'] in seen:
            raise ValueError('Duplicate track id')
        seen.add(track['track_id'])
        if not track['label'].strip():
            raise ValueError('Empty object label')
        xyz = np.asarray(track['centers_world'], dtype=float)
        boxes = np.asarray(track['bboxes_xyxy'], dtype=float)
        valid = np.asarray(track['valid'], dtype=bool)
        if xyz.shape != (len(ts), 3) or boxes.shape != (len(ts), 4) or valid.shape != (len(ts),):
            raise ValueError('Track array shape mismatch')
        if not np.isfinite(xyz[valid]).all() or not np.isfinite(boxes[valid]).all():
            raise ValueError('Nonfinite values on valid track frames')
        b = boxes[valid]
        if ((b[:, 0] < 0) | (b[:, 1] < 0) | (b[:, 2] > width) | (b[:, 3] > height) |
            (b[:, 0] >= b[:, 2]) | (b[:, 1] >= b[:, 3])).any():
            raise ValueError('Bounding box outside original image or degenerate')
    return ts, poses


def transform_world(xyz, poses):
    """World -> OpenCV observer camera -> DSR axes [front, left, up]."""
    camera = np.einsum('nji,nj->ni', poses[:, :3, :3], xyz - poses[:, :3, 3])
    return camera[:, [2, 0, 1]] * [1, -1, -1]


def attributes(g, qtype, target_ids, start, end, reference):
    ts, poses = validate_geometry(g)
    if qtype not in SUPPORTED:
        raise ValueError(f'Unsupported type: {qtype}')
    if not (0 <= start < end < len(ts)) or end - start + 1 < 4 or not 0 <= reference < len(ts):
        raise ValueError('Invalid interval/reference index')
    required = 1 if qtype.endswith('_spd') else 2
    if len(target_ids) != required or len(set(target_ids)) != required:
        raise ValueError('Wrong number of distinct targets')
    world = {'camera': poses[:, :3, 3]}
    valid = {'camera': np.ones(len(ts), dtype=bool)}
    for tr in g['tracks']:
        world[tr['track_id']] = np.asarray(tr['centers_world'], dtype=float)
        valid[tr['track_id']] = np.asarray(tr['valid'], dtype=bool)
    sl = slice(start, end + 1)
    if any(t not in world or not valid[t][sl].all() for t in target_ids):
        raise ValueError('Track not continuously valid over interval')
    basis = poses[sl] if qtype.startswith('rel_') else np.repeat(poses[reference][None], end-start+1, axis=0)
    coords = [transform_world(world[t][sl], basis) for t in target_ids]
    if qtype.endswith('_dis'):
        value = np.linalg.norm(coords[0] - coords[1], axis=1)
    elif qtype.endswith('_dir'):
        # Explicit DSR code convention: object_1 - object_2, not the reverse.
        value = coords[0] - coords[1]
    else:
        speeds = [np.linalg.norm(np.diff(p, axis=0), axis=1) / np.diff(ts[sl]) for p in coords]
        value = speeds[0] if qtype.endswith('_spd') else np.stack(speeds, axis=1)
    return value


def classify(value, qtype):
    rules = load_rules()
    value = np.asarray(value, dtype=float)
    if not np.isfinite(value).all():
        raise ValueError('Nonfinite attribute')
    with np.errstate(all='raise'):
        if qtype.endswith('_dir'):
            if (np.linalg.norm(value, axis=1) < 1e-8).any():
                raise ValueError('Undefined direction for coincident targets')
            return rules.describe_dir(value)
        if qtype.endswith('_spd_comp'):
            # Preserve original thresholds while handling zero denominator safely.
            return rules.describe_spd_comp(np.maximum(value[:, 0], 1e-10), np.maximum(value[:, 1], 1e-10))
        if qtype.endswith('_dis') and (value < 1e-8).any():
            raise ValueError('Undefined distance ratio for coincident targets')
        # DSR ratio functions divide before their near-zero check.
        return rules.describe_dist_runs(np.maximum(value, 1e-10))


def normalize_answer(s):
    return re.sub(r'\s+', ' ', s.strip().lower())


def options_for(value, qtype, answer, rng, attempts=200):
    choices = [answer]
    seen = {normalize_answer(answer)}
    n = len(value)
    for _ in range(attempts):
        if len(choices) == 4:
            break
        if qtype.endswith('_dir'):
            # Constant and piecewise directions, sampled from the same classifier.
            anchors = rng.normal(size=(int(rng.integers(1, min(n, 4)+1)), 3))
            fake = anchors[np.minimum(np.arange(n) * len(anchors) // n, len(anchors)-1)]
        elif qtype.endswith('_spd_comp'):
            fake = np.exp(rng.normal(size=(n, 2)))
        else:
            fake = np.exp(np.cumsum(rng.normal(0, .35, size=n)))
        candidate = classify(fake, qtype)
        key = normalize_answer(candidate)
        if key not in seen and candidate:
            choices.append(candidate)
            seen.add(key)
    if len(choices) != 4:
        raise ValueError('Distractor attempt budget exhausted')
    rng.shuffle(choices)
    opts = dict(zip('ABCD', choices))
    return opts, next(k for k, v in opts.items() if v == answer)


def make_qa(g, qtype, ids, start, end, reference, seed):
    value = attributes(g, qtype, ids, start, end, reference)
    answer = classify(value, qtype)
    if not answer or len(re.findall(r'\(\d+\)', answer)) > 15:
        raise ValueError('Empty or excessive state sequence')
    rng = np.random.default_rng(seed)
    # Numeric robustness screen. Not a calibrated geometric uncertainty estimate.
    agree = 0
    for _ in range(20):
        perturbed = value * rng.uniform(.99, 1.01, size=value.shape)
        agree += classify(perturbed, qtype) == answer
    if agree < 18:
        raise ValueError('Answer unstable under 1% attribute perturbations')
    options, correct = options_for(value, qtype, answer, rng)
    tracks = {t['track_id']: t for t in g['tracks']}
    ts = g['timestamps_s']
    targets, names = [], []
    for tid in ids:
        if tid == 'camera':
            names.append('camera')
            targets.append(dict(track_id=tid, label='camera'))
        else:
            tr = tracks[tid]
            box = tr['bboxes_xyxy'][start]
            names.append(f'{tr["label"]} with bounding box coordinates {np.rint(box).astype(int).tolist()} at {ts[start]:.3f}s')
            targets.append(dict(track_id=tid, label=tr['label'], bbox_xyxy=box,
                                bbox_time_s=ts[start], bbox_image_size=g['image_size_wh']))
    # Explicit timestamps retain native precision; direction wording avoids ambiguity.
    view = 'following the perspective of camera' if qtype.startswith('rel_') else f'from the perspective of camera at {ts[reference]:.3f}s'
    if qtype.endswith('_dis'):
        body = f'how does the distance between {names[0]} and {names[1]} change?'
    elif qtype.endswith('_dir'):
        body = f'how does the direction of {names[0]} relative to {names[1]} change?'
    elif qtype.endswith('_spd_comp'):
        body = f'compare the speed of {names[0]} and {names[1]} in that coordinate system.'
    else:
        body = f'how does the speed of {names[0]} in that coordinate system change?'
    key = f'{g["video_id"]}:{qtype}:{ids}:{start}:{end}:{reference}:{seed}'
    return dict(qa_id='sti_dsr_'+hashlib.sha256(key.encode()).hexdigest()[:16],
                video_id=g['video_id'], type=qtype, question=f'Between {ts[start]:.3f}s and {ts[end]:.3f}s, {view}, {body}',
                options=options, answer=correct, query_start_s=ts[start], query_end_s=ts[end],
                viewpoint=dict(entity_id='camera', mode='relative' if qtype.startswith('rel_') else 'absolute',
                               reference_time_s=None if qtype.startswith('rel_') else ts[reference]),
                targets=targets, frame_indices=g['source_frame_indices'][start:end+1],
                frame_timestamps_s=ts[start:end+1], sampling_policy=g['sampling_policy'],
                answer_evidence=dict(attribute_values=value.tolist(), reference_index=reference,
                                     start_index=start, end_index=end, rule_sha256=sha256(TEMPLATE),
                                     perturbation_agreement=agree/20, perturbation_trials=20),
                answer_states=answer, seed=seed, review_status='pending',
                source_video_sha256=g['source_video_sha256'])


def validate_qa(q, g):
    if q['video_id'] != g['video_id'] or q['source_video_sha256'] != g['source_video_sha256']:
        raise ValueError('Video provenance mismatch')
    if set(q['options']) != set('ABCD') or q['answer'] not in q['options']:
        raise ValueError('Invalid options/answer')
    if len({normalize_answer(x) for x in q['options'].values()}) != 4:
        raise ValueError('Duplicate options')
    e = q['answer_evidence']
    s, t = e['start_index'], e['end_index']
    if q['query_start_s'] != g['timestamps_s'][s] or q['query_end_s'] != g['timestamps_s'][t]:
        raise ValueError('QA timestamp mismatch')
    if q['frame_timestamps_s'] != g['timestamps_s'][s:t+1] or q['frame_indices'] != g['source_frame_indices'][s:t+1]:
        raise ValueError('QA frame mapping mismatch')
    mode = 'relative' if q['type'].startswith('rel_') else 'absolute'
    ref = None if mode == 'relative' else g['timestamps_s'][e['reference_index']]
    if q['viewpoint'] != dict(entity_id='camera', mode=mode, reference_time_s=ref):
        raise ValueError('Viewpoint mismatch')
    tracks = {x['track_id']: x for x in g['tracks']}
    for target in q['targets']:
        if target['track_id'] != 'camera':
            tr = tracks[target['track_id']]
            if target['bbox_xyxy'] != tr['bboxes_xyxy'][s] or target['bbox_time_s'] != g['timestamps_s'][s]:
                raise ValueError('Target bbox anchor mismatch')
    if e['rule_sha256'] != sha256(TEMPLATE):
        raise ValueError('Rules have changed')
    value = attributes(g, q['type'], [t['track_id'] for t in q['targets']], e['start_index'], e['end_index'], e['reference_index'])
    if not np.allclose(value, e['attribute_values']):
        raise ValueError('Saved evidence mismatch')
    answer = classify(value, q['type'])
    if q['options'][q['answer']] != answer or q['answer_states'] != answer:
        raise ValueError('Recomputed answer mismatch')
    return True


def generate(g, seed=260920, max_qa=8, max_attempts=200):
    validate_geometry(g)
    rng = np.random.default_rng(seed)
    ids = ['camera'] + [t['track_id'] for t in g['tracks']]
    candidates, failures, seen = [], [], set()
    n = len(g['timestamps_s'])
    for attempt in range(max_attempts):
        if len(candidates) >= max_qa:
            break
        qtype = SUPPORTED[attempt % len(SUPPORTED)]
        start = int(rng.integers(0, n-3))
        end = int(rng.integers(start+3, n))
        ref = start  # initial camera viewpoint; explicit and within the interval
        count = 1 if qtype.endswith('_spd') else 2
        if len(ids) < count:
            failures.append(dict(attempt=attempt, type=qtype, reason='Insufficient tracks'))
            continue
        targets = rng.choice(ids, count, replace=False).tolist()
        if qtype == 'rel_spd' and targets == ['camera']:
            failures.append(dict(attempt=attempt, type=qtype, reason='Trivial self-relative camera speed'))
            continue
        # Absolute and relative distance are invariant under rigid transforms.
        key = (('distance' if qtype.endswith('_dis') else qtype), tuple(sorted(targets)) if qtype.endswith('_dis') else tuple(targets), start, end)
        if key in seen:
            continue
        try:
            qa = make_qa(g, qtype, targets, start, end, ref, int(rng.integers(0, 2**31)))
            validate_qa(qa, g)
            candidates.append(qa)
            seen.add(key)
        except (ValueError, FloatingPointError) as e:
            failures.append(dict(attempt=attempt, type=qtype, reason=str(e)))
    return candidates, failures


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--geometry', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--max-qa', type=int, default=8)
    p.add_argument('--seed', type=int, default=260920)
    args = p.parse_args()
    if args.max_qa < 1:
        p.error("--max-qa must be positive")
    g = json.loads(args.geometry.read_text())
    qas, failures = generate(g, args.seed, args.max_qa)
    for q in qas:
        q['geometry_artifact'] = str(args.geometry.resolve())
        q['geometry_sha256'] = sha256(args.geometry)
    write_jsonl(args.output, qas)
    write_jsonl(args.output.with_suffix('.failures.jsonl'), failures)
    print(f'{len(qas)} candidate QA; {len(failures)} rejected attempts; human review pending')
    if not qas:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
