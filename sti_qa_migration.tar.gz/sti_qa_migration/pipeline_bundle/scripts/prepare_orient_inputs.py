#!/usr/bin/env python3
"""CPU preparation; preserve all 353 jobs, annotate eligible agent tracks/frames."""
import json,collections
from pathlib import Path
from orient_contract import ROOT,read_jsonl,write_json,file_hash,model_inventory
from orient_contract import verify_upstream as verify


def main():
    inventory=model_inventory();jobs=read_jsonl(ROOT/'manifests/sam2_all.jsonl');ready=[];counts=collections.Counter()
    for job in jobs:
        folder=ROOT/'artifacts/grounded_sam2'/job['video_id']/job['segment_id']
        trajectory=ROOT/'artifacts/trajectories'/job['video_id']/job['segment_id']
        geometry=Path(job['output_directory'])
        hashes={'sam2':verify(folder),'trajectory':verify(trajectory),'pi3':verify(geometry)}
        data=json.loads((folder/'tracks.json').read_text());fm=json.loads((geometry/'frame_map.json').read_text())
        if data['source_frames']!=job['frames'] or fm['frames']!=job['frames']:raise ValueError('Frame mapping mismatch')
        selected=[t for t in data['tracks'] if t['group']=='agents' and t['orientation_candidate']]
        records=[]
        for t in selected:
            for f in data['frames']:
                obj=next(x for x in f['objects'] if x['track_id']==t['track_id'])
                records.append({'track_id':t['track_id'],'frame_index':f['segment_frame_index'],
                                'mask_area_pixels':obj['mask_area_pixels'],'status':'ready' if obj['mask_area_pixels'] else 'empty_mask'})
        counts['jobs_with_targets']+=bool(selected);counts['agent_tracks']+=len(selected)
        counts['all_agent_tracks']+=sum(t['group']=='agents' for t in data['tracks'])
        counts.update(r['status'] for r in records)
        ready.append(dict(job,orientation={'track_ids':[t['track_id'] for t in selected],'samples':records,
                                          'upstream_marker_sha256':hashes,'selection':'group=agents and orientation_candidate=true; all nonempty mask frames; no size/confidence/3D gate'}))
    dest=ROOT/'manifests/orient_all.jsonl';dest.write_text(''.join(json.dumps(j)+'\n' for j in ready))
    smoke=[j for j in ready if any(x['status']=='ready' for x in j['orientation']['samples'])][:2]
    (ROOT/'manifests/orient_smoke.jsonl').write_text(''.join(json.dumps(j)+'\n' for j in smoke))
    report={'jobs':len(ready),'smoke_jobs':len(smoke),'smoke_crops':sum(x['status']=='ready' for j in smoke for x in j['orientation']['samples']),**counts,
            'jobs_without_targets':len(ready)-counts['jobs_with_targets'],'model_files':inventory,'gpu_executed':False}
    write_json(ROOT/'reports/orient_preparation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
