"""CPU DSR-style 12-type QA contract; fixed intervals, explicit observer frames."""
import hashlib,itertools,json,re
import numpy as np
from qa_cpu import classify as base_classify,options_for,normalize_answer
from orient_contract import ROOT,file_hash
TYPES=['abs_dis','rel_dis','abs_dir','rel_dir','abs_ori','rel_ori','abs_spd','rel_spd','abs_spd_comp','rel_spd_comp','abs_dir_pred','rel_dir_pred']
CAMERA_AXES=np.array([[0.,0,1],[-1,0,0],[0,-1,0]])


def stable_seed(value):return int(hashlib.sha256(value.encode()).hexdigest()[:8],16)


def entities(g):
    poses=np.asarray(g['camera_to_world']);n=len(poses)
    result={'camera':{'label':'camera','p':poses[:,:3,3], 'v':np.ones(n,bool),
                      'r':np.einsum('ij,nkj->nik',CAMERA_AXES,poses[:,:3,:3]),
                      'rv':np.ones(n,bool),'f':poses[:,:3,2], 'boxes':[None]*n}}
    for t in g['tracks']:
        r=np.asarray(t['world_to_agent'],float);conf=np.asarray(t['orientation_confidence'],float)
        result[t['track_id']]={'label':t['label'],'p':np.asarray(t['centers_world'],float),
          'v':np.asarray(t['valid'],bool),'r':r,'rv':np.isfinite(r).all(axis=(1,2))&(conf>=.6),
          'f':r[:,0,:], 'boxes':t['bboxes_xyxy']}
    return result


def attributes(g,kind,ids,observer):
    es=entities(g);ts=np.asarray(g['timestamps_s']);n=len(ts);prediction=kind.endswith('_pred')
    if kind not in TYPES:raise ValueError('unsupported_type')
    if len(ids)!=(2 if kind.endswith(('_dis','_dir','_comp')) else 1) or len(set(ids))!=len(ids):raise ValueError('target_count')
    if observer not in es or any(t not in es for t in ids):raise ValueError('unknown_entity')
    if kind.startswith('rel_') and kind.endswith(('_spd','_ori','_pred')) and observer in ids:raise ValueError('trivial_self_relative')
    if kind.endswith('_comp') and observer in ids:raise ValueError('trivial_observer_speed_comparison')
    ii=np.array([n-3,n-1]) if prediction else np.arange(n)
    obs=es[observer];refs=ii if kind.startswith('rel_') else np.zeros(len(ii),int)
    if not obs['rv'][refs].all():raise ValueError('observer_orientation_missing_or_low_confidence')
    # Fixed observers require only the reference center; moving observers need every used center.
    if not obs['v'][refs].all():raise ValueError('observer_center_missing')
    rot=obs['r'][refs];origin=obs['p'][refs]
    if kind.endswith('_ori'):
        target=es[ids[0]]
        if not target['rv'][ii].all():raise ValueError('target_orientation_missing_or_low_confidence')
        values=np.einsum('nij,nj->ni',rot,target['f'][ii])
    else:
        coords=[]
        for tid in ids:
            t=es[tid]
            if not t['v'][ii].all():raise ValueError('target_center_missing')
            coords.append(np.einsum('nij,nj->ni',rot,t['p'][ii]-origin))
        if kind.endswith('_dis'):values=np.linalg.norm(coords[0]-coords[1],axis=1)
        elif kind.endswith('_dir'):values=coords[0]-coords[1]
        elif prediction:values=(coords[0][1]-coords[0][0])[None]
        else:
            speed=[np.linalg.norm(np.diff(x,axis=0),axis=1)/np.diff(ts) for x in coords]
            values=speed[0] if kind.endswith('_spd') else np.stack(speed,axis=1)
    if not np.isfinite(values).all():raise ValueError('nonfinite_geometry')
    if prediction and np.linalg.norm(values)<g['scene_scale']*.01:raise ValueError('prediction_displacement_below_1pct_scene_scale')
    return values


def rule_kind(kind):return 'abs_dir' if kind.endswith(('_ori','_pred')) else kind

def classify(value,kind):return base_classify(value,rule_kind(kind))


def describe_entity(g,tid,anchor):
    if tid=='camera':return 'camera',{'track_id':'camera','label':'camera'}
    t=next(t for t in g['tracks'] if t['track_id']==tid);box=t['bboxes_xyxy'][anchor]
    if box is None or not np.isfinite(box).all():raise ValueError('missing_bbox_anchor')
    ref={'track_id':tid,'label':t['label'],'bbox_xyxy':box,'bbox_time_s':g['timestamps_s'][anchor],
         'bbox_image_size':g['image_size_wh']}
    return f"{t['label']} with bounding box {np.rint(box).astype(int).tolist()} at {g['timestamps_s'][anchor]:.3f}s",ref


def make_qa(g,kind,ids,observer):
    pred=kind.endswith('_pred');n=len(g['timestamps_s']);last=n-3 if pred else n-1;anchor=last if pred else 0
    value=attributes(g,kind,ids,observer);answer=classify(value,kind)
    if not answer or len(re.findall(r'\(\d+\)',answer))>15:raise ValueError('excessive_answer_states')
    key=f"{g['job_id']}:{kind}:{observer}:{ids}:260920";seed=stable_seed(key);rng=np.random.default_rng(seed)
    agree=sum(classify(value*rng.uniform(.99,1.01,value.shape),kind)==answer for _ in range(20))
    if agree<18:raise ValueError('unstable_under_1pct_numeric_perturbation')
    options,correct=options_for(value,rule_kind(kind),answer,rng)
    names=[];targets=[]
    for tid in ids:
        name,target=describe_entity(g,tid,anchor);names.append(name);targets.append(target)
    observer_anchor=0 if kind.startswith('abs_') else anchor
    observer_name,observer_target=describe_entity(g,observer,observer_anchor)
    ts=g['timestamps_s'];view=(f'from the fixed perspective of {observer_name} at {ts[0]:.3f}s' if kind.startswith('abs_') else f'following the perspective of {observer_name}')
    if pred:question=f'Using only the video through {ts[last]:.3f}s, {view}, predict the moving direction of {names[0]} from {ts[last]:.3f}s to {ts[-1]:.3f}s.'
    else:
        if kind.endswith('_dis'):body=f'how does the distance between {names[0]} and {names[1]} change?'
        elif kind.endswith('_dir'):body=f'how does the direction of {names[0]} relative to {names[1]} change?'
        elif kind.endswith('_ori'):body=f'how does the facing direction of {names[0]} change?'
        elif kind.endswith('_comp'):body=f'compare the speed of {names[0]} and {names[1]} in that coordinate system.'
        else:body=f'how does the speed of {names[0]} in that coordinate system change?'
        question=f'Between {ts[0]:.3f}s and {ts[-1]:.3f}s, {view}, {body}'
    return {'qa_id':'sti_dsr_'+hashlib.sha256(key.encode()).hexdigest()[:20],'video_id':g['video_id'],'segment_id':g['segment_id'],
      'source':g['source'],'type':kind,'question':question,'options':options,'answer':correct,'answer_states':answer,
      'query_start_s':ts[last] if pred else ts[0],'query_end_s':ts[-1],
      'observed_until_s':ts[last],'prediction_target_time_s':ts[-1] if pred else None,
      'viewpoint':dict(observer_target,mode='relative' if kind.startswith('rel_') else 'absolute',reference_time_s=None if kind.startswith('rel_') else ts[0]),
      'targets':targets,'input_frame_paths':g['frame_paths'][:last+1],'input_timestamps_s':ts[:last+1],
      'input_source_frame_indices':g['source_frame_indices'][:last+1],'sampling_policy':g['sampling_policy'],
      'answer_evidence':{'attribute_values':value.tolist(),'perturbation_agreement':agree/20,'rule_sha256':file_hash(ROOT/'vendor/dsr_template.py'),
                         'geometry_sha256':g['geometry_sha256'],'target_ids':ids,'observer_id':observer},
      'source_video_sha256':g['source_video_sha256'],'seed':seed,'review_status':'auto_validated_visual_review_pending',
      'label_source':'estimated_geometry_not_sensor_ground_truth'}


def validate_qa(q,g):
    prediction=q['type'].endswith('_pred');last=len(g['timestamps_s'])-3 if prediction else len(g['timestamps_s'])-1
    assert q['video_id']==g['video_id'] and q['segment_id']==g['segment_id']
    assert q['source_video_sha256']==g['source_video_sha256']
    assert q['input_frame_paths']==g['frame_paths'][:last+1]
    assert q['input_timestamps_s']==g['timestamps_s'][:last+1]
    assert q['input_source_frame_indices']==g['source_frame_indices'][:last+1]
    assert q['observed_until_s']==g['timestamps_s'][last]
    assert q['query_start_s']==g['timestamps_s'][last if prediction else 0] and q['query_end_s']==g['timestamps_s'][-1]
    if prediction:assert q['prediction_target_time_s']>max(q['input_timestamps_s'])
    assert set(q['options'])==set('ABCD') and len({normalize_answer(x) for x in q['options'].values()})==4
    e=q['answer_evidence'];assert e['geometry_sha256']==g['geometry_sha256'] and e['rule_sha256']==file_hash(ROOT/'vendor/dsr_template.py')
    assert [t['track_id'] for t in q['targets']]==e['target_ids'] and q['viewpoint']['track_id']==e['observer_id']
    mode='relative' if q['type'].startswith('rel_') else 'absolute'
    anchor=0 if mode=='absolute' else last if prediction else 0
    expected_view=dict(describe_entity(g,e['observer_id'],anchor)[1],mode=mode,reference_time_s=None if mode=='relative' else g['timestamps_s'][0])
    assert q['viewpoint']==expected_view
    for target in q['targets']:
        assert target==describe_entity(g,target['track_id'],last if prediction else 0)[1]
    value=attributes(g,q['type'],e['target_ids'],e['observer_id']);answer=classify(value,q['type'])
    assert np.allclose(value,e['attribute_values']) and answer==q['answer_states']==q['options'][q['answer']]
    return True
