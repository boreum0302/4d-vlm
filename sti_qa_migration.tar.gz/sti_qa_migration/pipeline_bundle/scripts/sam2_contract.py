"""CPU contracts for per-interval GroundingDINO + SAM2 tracks."""
import json
from pathlib import Path
import numpy as np
from qwen35_contract import ROOT, file_hash, digest, read_jsonl, write_json, verify_frames

from portable_paths import DependencyPath
DINO = DependencyPath('dino_model')
SAM = DependencyPath('sam_checkpoint')
SAM_CODE = DependencyPath('sam_code')
SAM_CONFIG = 'configs/sam2.1/sam2.1_hiera_l.yaml'


def qwen_objects(job):
    folder = ROOT/'artifacts/qwen35_validated'/job['video_id']/job['segment_id']
    marker = json.loads((folder/'validated.json').read_text())
    for name, expected in marker['artifact_sha256'].items():
        if file_hash(folder/name) != expected:
            raise ValueError('Qwen output integrity mismatch')
    obj = json.loads((folder/'objects.json').read_text())
    for key in ['video_id','segment_id','query_start_s','query_end_s','frames']:
        if obj[key] != job[key]:
            raise ValueError('Qwen/Pi3 interval mismatch: '+key)
    items = []
    for group in ['agents','non_agents']:
        for item in obj[group]:
            items.append(dict(item, group=group))
    if len({x['label'] for x in items}) != len(items):
        raise ValueError('Duplicate Qwen labels')
    return {'objects': items, 'source': str(folder/'objects.json'),
            'sha256': file_hash(folder/'objects.json'), 'review_status': obj['review_status'],
            'truncated': obj['truncated']}


def iou(box, boxes):
    boxes = np.asarray(boxes, dtype=float).reshape(-1,4)
    a = np.maximum(box[:2], boxes[:,:2]); b = np.minimum(box[2:], boxes[:,2:])
    inter = np.maximum(b-a,0).prod(axis=1)
    area = (box[2]-box[0])*(box[3]-box[1])
    other = np.maximum(boxes[:,2:]-boxes[:,:2],0).prod(axis=1)
    return inter / np.maximum(area+other-inter,1e-8)


def select_detections(candidates, width, height, max_objects=16):
    kept=[]; discarded=[]
    for item in sorted(candidates,key=lambda x:-x['score']):
        x=dict(item);box=np.asarray(x['bbox_xyxy'],dtype=float)
        if box.shape!=(4,) or not np.isfinite(box).all() or not np.isfinite(x['score']):
            raise ValueError('Nonfinite or invalid detection')
        box[[0,2]]=box[[0,2]].clip(0,width);box[[1,3]]=box[[1,3]].clip(0,height)
        if box[2]<=box[0] or box[3]<=box[1]:continue
        x['bbox_xyxy']=box.tolist()
        overlap=any(iou(box,[y['bbox_xyxy']])[0]>(0.5 if x['label']==y['label'] else 0.8) for y in kept)
        if overlap or len(kept)>=max_objects:
            discarded.append(dict(x,reason='overlap' if overlap else 'track_limit'));continue
        kept.append(x)
    for i,item in enumerate(kept,1):item['track_id']=i
    return kept,discarded


def mask_stats(masks, track_ids, height, width):
    masks=np.asarray(masks)
    if masks.dtype!=np.bool_ or masks.shape!=(len(track_ids),height,width):
        raise ValueError('Mask shape/dtype mismatch')
    if len(set(track_ids))!=len(track_ids):raise ValueError('Duplicate track IDs')
    result=[]
    for track_id,mask in zip(track_ids,masks):
        ys,xs=np.nonzero(mask);area=len(xs)
        box=[int(xs.min()),int(ys.min()),int(xs.max())+1,int(ys.max())+1] if area else None
        result.append({'track_id':int(track_id),'bbox_xyxy':box,'mask_area_pixels':area,
                       'mask_present':bool(area),'valid_for_lifting':bool(area>=16)})
    return result


def completed(folder, signature):
    folder=Path(folder);p=folder/'complete.json'
    if not p.exists():return False
    x=json.loads(p.read_text())
    if x['run_signature']!=signature:raise ValueError('Output configuration differs; use a new --output-root')
    for name,expected in x['artifact_sha256'].items():
        if file_hash(folder/name)!=expected:raise ValueError('Mask/track artifact changed')
    return True


def validate_screened_job(job):
    screen=job.get('screening')
    if not screen:raise ValueError('Job has not passed conservative stage-6 screening')
    if file_hash(screen['report'])!=screen['sha256']:raise ValueError('Screening report changed')
    result=json.loads(Path(screen['report']).read_text())
    base={k:v for k,v in job.items() if k!='screening'}
    expected=digest({'settings':result['settings'],'job':base})
    if not result['passed'] or expected!=result['signature'] or expected!=screen['signature']:
        raise ValueError('Screening/input mismatch')
    if len(result['endpoints'])!=2:raise ValueError('Both endpoints must be screened')
    return result
