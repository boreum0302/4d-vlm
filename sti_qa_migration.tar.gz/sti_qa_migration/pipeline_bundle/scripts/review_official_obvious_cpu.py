"""Minimal deterministic defect checks; no score thresholds, no semantic quality curation."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import json,re,string,time,collections,sys
from pathlib import Path
from orient_contract import ROOT,read_jsonl,write_json,file_hash
from prepare_cpu import write_jsonl

def option_key(text):
    # Only collapse explicit whole-interval speed-comparison synonyms.
    x=re.sub(r'\(\d+\)','',text.lower());x=re.sub(r'\s+',' ',x).strip().rstrip('.')
    if x in ('the former is always faster','the latter is always faster'):
        x=x.replace(' always','')
    return x

def parse_question(text,template):
    parts=[];count=0
    for literal,name,_,_ in string.Formatter().parse(template):
        parts.append(re.escape(literal))
        if name is not None:parts.append(f'(?P<p{count}>.*?)');count+=1
    m=re.fullmatch(''.join(parts),text)
    return [m[f'p{i}'] for i in range(count)] if m else None

def inspect_row(row,job,sam,templates):
    q=row['official_qa'];reasons=[];details={};flags=[]
    if not all(isinstance(q.get(k),str) and q[k].strip() for k in ['Type','Question','A','B','C','D','Correct']):return ['invalid_or_empty_qa_fields'],details,flags
    if q['Correct'] not in 'ABCD' or len(q['Correct'])!=1:return ['invalid_answer_key'],details,flags
    key=option_key(q[q['Correct']]);duplicates=[k for k in 'ABCD' if k!=q['Correct'] and option_key(q[k])==key]
    if duplicates:reasons.append('correct_option_has_equivalent_alternative');details['equivalent_options']=[q['Correct']]+duplicates
    if any(re.search(r'\b(?:nan|infinity|inf)\b',q[k],re.I) for k in 'ABCD'):reasons.append('nonfinite_option_text')
    slots=parse_question(q['Question'],templates[q['Type']]);details['parsed_slots']=slots
    if slots is None:return reasons,details,['question_template_parse_unresolved']
    frames=job['frames'];times=[f['timestamp_s'] for f in frames];kind=q['Type'];pred=kind.endswith('_pred');absolute=kind.startswith('abs_')
    if pred:
        start=times[-3];end=times[-1];observer_time=float(slots[1]) if absolute else start
        roles=[('observer',slots[0],observer_time),('target_1',slots[2] if absolute else slots[1],start)]
    else:
        start,end=map(float,slots[:2]);observer_time=float(slots[3]) if absolute else start
        targetslots=slots[4:] if absolute else slots[3:]
        roles=[('observer',slots[2],observer_time)]+[(f'target_{i+1}',s,start) for i,s in enumerate(targetslots)]
    details['time_context']={'start_s':start,'end_s':end,'observer_time_s':observer_time,'observed_until_s':times[-3] if pred else end,'prediction_target_s':times[-1] if pred else None}
    if not times[0]-.051<=start<end<=times[-1]+.051 or not times[0]-.051<=observer_time<=times[-1]+.051:reasons.append('query_time_outside_cached_segment')
    calls=row['provenance']['perception_calls'];resolved=[];w,h=sam['image_size_wh']
    for role,text,t in roles:
        if text=='camera':resolved.append({'role':role,'track_id':'camera','time_s':t});continue
        m=re.fullmatch(r'(.+?) with (?:initial |final )?bounding box coordinates \[([^]]+)\]',text)
        if not m:flags.append('entity_parse_unresolved');continue
        label=m[1];box=[float(x) for x in m[2].split(',')]
        if len(box)!=4 or not all(__import__('math').isfinite(x) for x in box) or not (0<=box[0]<box[2]<=w and 0<=box[1]<box[3]<=h):reasons.append('invalid_bbox');continue
        fi=min(range(len(times)),key=lambda i:abs(times[i]-t))
        if abs(times[fi]-t)>.051:reasons.append('bbox_anchor_time_not_in_cache');continue
        matches=[]
        for call in calls:
            if call['frames'][0]!=fi:continue
            for tid in call['track_ids']:
                track=next(x for x in sam['tracks'] if str(x['track_id'])==str(tid))
                obj=next(x for x in sam['frames'][fi]['objects'] if str(x['track_id'])==str(tid))
                if track['label']==label and obj['bbox_xyxy']==box:matches.append(str(tid))
        matches=sorted(set(matches))
        if not matches:reasons.append('question_bbox_or_label_not_in_generation_inputs')
        elif len(matches)>1:flags.append('track_identity_ambiguous')
        else:resolved.append({'role':role,'track_id':matches[0],'time_s':t,'frame_index':fi,'bbox_xyxy':box,'label':label})
    details['resolved_entities']=resolved
    targetids=[x['track_id'] for x in resolved if x['role'].startswith('target_')]
    if len(targetids)==2 and targetids[0]==targetids[1]:reasons.append('same_track_compared_to_itself')
    if not Path(row['source_video_path']).is_file():reasons.append('source_video_missing')
    return sorted(set(reasons)),details,sorted(set(flags))

def main():
    start=time.perf_counter();src=ROOT/'outputs/dsr_official';out=ROOT/'outputs/dsr_official_review';out.mkdir(exist_ok=True)
    ns={};exec(compile((ROOT/'vendor/official_sources/template.py').read_text(),'official_template','exec'),ns)
    jobs={j['video_id']+'/'+j['segment_id']:j for j in read_jsonl(ROOT/'manifests/sam2_all.jsonl')};samcache={};kept=[];removed=[];audits=[]
    rows=read_jsonl(src/'qa_all.jsonl')
    for row in rows:
        key=row['video_id']+'/'+row['segment_id'];job=jobs[key]
        if key not in samcache:samcache[key]=json.loads((ROOT/'artifacts/grounded_sam2'/key/'tracks.json').read_text())
        reasons,details,flags=inspect_row(row,job,samcache[key],ns['template'])
        audit={'qa_id':row['qa_id'],'decision':'remove' if reasons else 'keep','reasons':reasons,'flags_not_removed':flags,'evidence':details};audits.append(audit)
        copy=dict(row);copy['review_status']='obvious_defect_removed' if reasons else 'basic_checks_passed_not_full_quality_review';copy['basic_review']=audit
        (removed if reasons else kept).append(copy)
    write_jsonl(out/'qa_kept.jsonl',kept);write_jsonl(out/'qa_removed.jsonl',removed);write_jsonl(out/'audit_all.jsonl',audits)
    raw=collections.defaultdict(list)
    for q in kept:raw[q['video_id']+'/'+q['segment_id']].append(q['official_qa'])
    write_json(out/'qa_pairs_kept.json',dict(raw))
    assert len(kept)+len(removed)==len(rows) and len({q['qa_id'] for q in kept+removed})==len(rows)
    original={q['qa_id']:q['official_qa'] for q in rows};assert all(q['official_qa']==original[q['qa_id']] for q in kept+removed)
    summary={'input':len(rows),'kept':len(kept),'removed':len(removed),'kept_videos':len({q['video_id'] for q in kept}),
      'removal_reasons':dict(collections.Counter(r for a in audits for r in a['reasons'])),'flags_not_removed':dict(collections.Counter(f for a in audits for f in a['flags_not_removed'])),
      'kept_type_counts':dict(collections.Counter(q['official_qa']['Type'] for q in kept)),
      'seconds':time.perf_counter()-start,'gpu_executed':False,'peak_vram_gib':0,'source_sha256':file_hash(src/'qa_all.jsonl'),
      'policy':'obvious structural defects only; no confidence, reprojection, option-length or motion-stability filters; no full visual review'}
    write_json(out/'summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
