"""CPU export matching viewer: show boxes only within the QA interval."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import sys,json,subprocess
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
root=Path('.');sys.path.insert(0,str(root/'viewer'))
from server import load
vid='14107757919671295130_3546_370_3566_370_camera_1'
rows,videos=load();q,=[r for r in rows if r['video_id']==vid]
out=root/'outputs/dsr_official_viewer/exports';out.mkdir(exist_ok=True)
target=out/(vid+'_bbox.mp4');tmp=out/(vid+'_bbox.tmp.mp4')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(videos[vid])]))
s=probe['streams'][0];w,h=s['width'],s['height'];times=[float(f['best_effort_timestamp_time']) for f in probe['frames']]
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
def bbox(o,t):
 if not q['query_start_s']-.001<=t<=q['query_end_s']+.001:return None
 for a in o['anchors']:
  if abs(t-a['t'])<.001:return a['bbox']
 samples=o['samples'];inds=[i for i,a in enumerate(samples) if a['t']<=t]
 if not inds:return None
 i=inds[-1];a=samples[i]
 if not a['bbox'] or i+1==len(samples):return a['bbox']
 b=samples[i+1]
 if not b['bbox']:return None
 f=(t-a['t'])/(b['t']-a['t']);return [x+(y-x)*f for x,y in zip(a['bbox'],b['bbox'])]
dec=subprocess.Popen(['ffmpeg','-v','error','-threads','2','-i',str(videos[vid]),'-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE)
enc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r',s['r_frame_rate'],'-i','pipe:0','-i',str(videos[vid]),'-map','0:v:0','-map','1:a?','-c:v','libx264','-threads','2','-crf','18','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',str(tmp)],stdin=subprocess.PIPE)
drawn=0;after_interval=0
for t in times:
 raw=dec.stdout.read(w*h*3);assert len(raw)==w*h*3
 im=Image.frombytes('RGB',(w,h),raw);draw=ImageDraw.Draw(im)
 for j,o in enumerate(q['objects']):
  b=bbox(o,t)
  if b is None:continue
  color=['#63ffd3','#ffd36b','#c69cff'][j%3]
  draw.rectangle(b,outline=color,width=2)
  draw.text((b[0]+3,max(15,b[1]-4)),o['label'],font=font,fill=color,anchor='ls',stroke_width=1,stroke_fill='#10161e');drawn+=1
  if t>q['query_end_s']:after_interval+=1
 enc.stdin.write(im.tobytes())
enc.stdin.close();assert enc.wait()==0 and dec.wait()==0;assert drawn>0 and after_interval==0
subprocess.run(['ffmpeg','-v','error','-i',str(tmp),'-f','null','-'],check=True);tmp.replace(target)
(out/(vid+'_bbox.json')).write_text(json.dumps({'qa_id':q['qa_id'],'display_rule':'only within QA interval; missing boxes hidden','interpolation':'viewer default linear','frame_count':len(times),'drawn_boxes':drawn,'boxes_after_qa_interval':after_interval},indent=2)+'\n')
print(target,'frames',len(times),'boxes',drawn,'after QA interval',after_interval)
