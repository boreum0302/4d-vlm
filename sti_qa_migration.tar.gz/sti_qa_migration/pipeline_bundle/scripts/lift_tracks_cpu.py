#!/usr/bin/env python3
"""CPU-only mask lifting into each Pi3 interval's relative world coordinates."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import argparse,fcntl,json,time,traceback
from pathlib import Path
import numpy as np
from PIL import Image
from sam2_contract import ROOT,read_jsonl,write_json,file_hash,digest,completed


def lift(mask,local,valid,confidence,pose):
    h,w=local.shape[:2]
    grid=np.asarray(Image.fromarray(mask).resize((w,h),Image.Resampling.NEAREST),dtype=bool)
    keep=grid & valid & np.isfinite(local).all(axis=-1) & np.isfinite(confidence) & (local[...,2]>0)
    n=int(keep.sum())
    result={'mask_pixels_original':int(mask.sum()),'mask_pixels_geometry':int(grid.sum()),
            'valid_point_count':n,'valid_point_fraction':n/max(1,int(grid.sum())),
            'center_camera':None,'center_world':None,'mean_confidence':None,
            'center_available':bool(n),'valid_for_lifting':bool(n and mask.sum()>=16)}
    if n:
        center=local[keep].mean(axis=0,dtype=np.float64)
        world=pose[:3,:3]@center+pose[:3,3]
        result.update(center_camera=center.tolist(),center_world=world.tolist(),mean_confidence=float(confidence[keep].mean(dtype=np.float64)))
    return result


def verify(folder):
    marker=json.loads((folder/'complete.json').read_text())
    for name,h in marker['artifact_sha256'].items():
        if file_hash(folder/name)!=h:raise ValueError('Upstream artifact hash mismatch: '+str(folder/name))
    return file_hash(folder/'complete.json')


def process(job,output,settings):
    geom=Path(job['output_directory']);sam=ROOT/'artifacts/grounded_sam2'/job['video_id']/job['segment_id']
    inputs={'pi3_complete_sha256':verify(geom),'sam2_complete_sha256':verify(sam)}
    signature=digest({'job':job,'settings':settings,'inputs':inputs})
    dest=output/job['video_id']/job['segment_id']
    if completed(dest,signature):return json.loads((dest/'summary.json').read_text()),True
    tracks=json.loads((sam/'tracks.json').read_text());mapping=json.loads((geom/'frame_map.json').read_text())
    if tracks['source_frames']!=job['frames'] or mapping['frames']!=job['frames']:raise ValueError('Frame mapping mismatch')
    n=len(job['frames']);ids=[t['track_id'] for t in tracks['tracks']]
    if len(set(ids))!=len(ids):raise ValueError('Duplicate track IDs')
    if [x['segment_frame_index'] for x in tracks['frames']]!=list(range(n)):raise ValueError('Incomplete frame sequence')
    with np.load(geom/'scene_geometry.npz',allow_pickle=False) as g:
        local=g['local_points'];poses=g['camera_to_world'];valid=g['valid_mask'];conf=g['confidence']
        if not np.array_equal(g['timestamps_s'],[f['timestamp_s'] for f in job['frames']]):raise ValueError('Timestamp mismatch')
        if not np.array_equal(g['source_frame_indices'],[f['source_frame_index'] for f in job['frames']]):raise ValueError('Source frame mismatch')
    h,w=local.shape[1:3]
    if local.shape!=(n,h,w,3) or valid.shape!=(n,h,w) or conf.shape!=(n,h,w) or poses.shape!=(n,4,4):raise ValueError('Geometry shape mismatch')
    if mapping['model_image_size_wh']!=[w,h] or not np.isfinite(poses).all():raise ValueError('Invalid geometry mapping/poses')
    trajectories=[dict(t,samples=[]) for t in tracks['tracks']]
    original_w,original_h=tracks['image_size_wh'];available=usable=0
    for i,record in enumerate(tracks['frames']):
        maskpath=sam/'masks'/f'{i:03d}.npz'
        if Path(record['mask_path']).resolve()!=maskpath.resolve():raise ValueError('Mask path mismatch')
        frame=job['frames'][i]
        if record['timestamp_s']!=frame['timestamp_s'] or record['source_frame_index']!=frame['source_frame_index']:raise ValueError('Mask frame time mismatch')
        with np.load(maskpath,allow_pickle=False) as m:
            masks=m['masks']
            if masks.dtype!=np.bool_ or masks.shape!=(len(ids),original_h,original_w) or m['track_ids'].tolist()!=ids:raise ValueError('Mask shape/ID mismatch')
            for k,mask in enumerate(masks):
                sample=lift(mask,local[i],valid[i],conf[i],poses[i])
                sample.update(segment_frame_index=i,timestamp_s=frame['timestamp_s'],source_frame_index=frame['source_frame_index'])
                trajectories[k]['samples'].append(sample);available+=sample['center_available'];usable+=sample['valid_for_lifting']
    for t in trajectories:
        t['available_frames']=sum(s['center_available'] for s in t['samples'])
        t['valid_for_lifting_frames']=sum(s['valid_for_lifting'] for s in t['samples'])
    data={'job_id':job['job_id'],'video_id':job['video_id'],'segment_id':job['segment_id'],
          'query_start_s':job['query_start_s'],'query_end_s':job['query_end_s'],'source_frames':job['frames'],
          'coordinate_system':'Pi3 interval world: camera_to_world @ camera point',
          'is_metric':False,'cross_interval_alignment':False,'estimator':'arithmetic mean of mask & Pi3 valid finite positive-depth points',
          'missing_centers':'null; no interpolation','review_status':'needs_visual_review','tracks':trajectories}
    write_json(dest/'trajectories.json',data)
    summary={'job_id':job['job_id'],'frames':n,'tracks':len(ids),'track_frame_samples':n*len(ids),
             'centers_available':available,'valid_for_lifting_samples':usable,
             'tracks_with_2_or_more_centers':sum(t['available_frames']>=2 for t in trajectories),
             'status':'lifted' if ids else 'no_tracks','trajectories_path':str(dest/'trajectories.json')}
    write_json(dest/'summary.json',summary)
    write_json(dest/'provenance.json',{'settings':settings,'inputs':inputs,'job_id':job['job_id'],'run_signature':signature})
    write_json(dest/'complete.json',{'run_signature':signature,'artifact_sha256':{name:file_hash(dest/name) for name in ['trajectories.json','summary.json','provenance.json']}})
    return summary,False


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--subset',choices=['all','smoke'],default='all');a=p.parse_args()
    output=ROOT/'artifacts/trajectories';output.mkdir(exist_ok=True)
    lock=open(output/'.run.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    settings={'script_sha256':file_hash(__file__),'device':'cpu','mask_resize':'PIL nearest',
              'point_filter':'saved Pi3 valid_mask (confidence >0.1, non-edge) & finite & positive depth',
              'minimum_points_for_center':1,'minimum_original_mask_area_for_valid_flag':16,
              'center_estimator':'arithmetic_mean','interpolation':False}
    jobs=read_jsonl(ROOT/f'manifests/sam2_{a.subset}.jsonl');rows=[];errors=[];skipped=0;start=time.perf_counter()
    for i,job in enumerate(jobs,1):
        try:
            row,skip=process(job,output,settings);rows.append(row);skipped+=skip
        except Exception as e:
            errors.append({'job_id':job['job_id'],'error':str(e),'traceback':traceback.format_exc()})
            print(json.dumps(errors[-1]),flush=True)
        if i%25==0 or i==len(jobs):print(f'{i}/{len(jobs)} complete={len(rows)} failed={len(errors)} elapsed={time.perf_counter()-start:.1f}s',flush=True)
    path=output/f'trajectories_{a.subset}.jsonl';temp=path.with_suffix('.tmp');temp.write_text(''.join(json.dumps(x)+'\n' for x in rows));temp.replace(path)
    report={'requested':len(jobs),'complete':len(rows),'failed':len(errors),'skipped':skipped,'wall_seconds':time.perf_counter()-start,
            'gpu_executed':False,'peak_vram_gib':0,'errors':errors,
            **{key:sum(r[key] for r in rows) for key in ['frames','tracks','track_frame_samples','centers_available','valid_for_lifting_samples','tracks_with_2_or_more_centers']},
            'no_tracks':sum(r['status']=='no_tracks' for r in rows)}
    write_json(ROOT/f'reports/trajectory_execution_{a.subset}.json',report);print(json.dumps(report),flush=True)
    if errors:raise SystemExit(1)


if __name__=='__main__':main()
