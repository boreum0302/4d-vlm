"""Export conservative shortlist using numerical, reprojection and recorded visual checks."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import sys,json,time,collections
from pathlib import Path
from functools import lru_cache
ROOT=Path('.');sys.path.insert(0,str(ROOT/'scripts'))
from orient_contract import read_jsonl,write_json,file_hash
from prepare_cpu import write_jsonl
import qa_cpu
qa_cpu.load_rules=lru_cache(maxsize=1)(qa_cpu.load_rules)
from dsr_qa_contract import validate_qa

def main():
    start=time.perf_counter();src=ROOT/'outputs/dsr_qa';out=ROOT/'outputs/qa_review'
    qs=read_jsonl(src/'qa_all.jsonl');audit={r['qa_id']:r for r in read_jsonl(out/'audit_all.jsonl')}
    repro=json.loads((ROOT/'reports/qa_reprojection_review.json').read_text())
    visual=json.loads((ROOT/'reports/qa_visual_spot_review.json').read_text())
    assert visual['source_qa_sha256']==file_hash(src/'qa_all.jsonl')
    assert visual['reprojection_report_sha256']==file_hash(ROOT/'reports/qa_reprojection_review.json')
    decisions={r['qa_id']:r for r in visual['decisions']};kept=[];excluded=[];geoms={};media={};projection_pass=0
    for q in qs:
        reasons=list(audit[q['qa_id']]['reasons'])
        if not reasons:
            path=q['geometry_artifact']
            if path not in geoms:
                g=json.loads(Path(path).read_text());g['geometry_sha256']=file_hash(path);geoms[path]=g
                r=repro['jobs'][g['job_id']]
                assert r['geometry_sha256']==file_hash(Path(g['upstream']['pi3'])/'scene_geometry.npz')
            g=geoms[path]
            if not repro['jobs'][g['job_id']]['passed']:reasons.append('image_geometry_consistency_not_established')
            else:
                projection_pass+=1;d=decisions[q['qa_id']]
                for frame in d['sampled_frames']:assert file_hash(frame['path'])==frame['sha256']
                reasons.extend(d['hold_reasons'])
        if reasons:
            excluded.append({'qa_id':q['qa_id'],'video_id':q['video_id'],'type':q['type'],'status':'held_not_proven_invalid','reasons':reasons});continue
        validate_qa(q,g)
        q['review_status']='curated_auto_and_sampled_frame_review'
        q['quality_review']={'numerical_screen':'passed','all_adjacent_frame_reprojection':'passed','sampled_frame_review':'passed','full_video_review':'pending','record':str(ROOT/'reports/qa_visual_spot_review.json')}
        kept.append(q)
    ids={q['qa_id'] for q in kept}
    assert len(ids)==len(kept) and len(ids)+len(excluded)==len(qs)
    assert ids.isdisjoint({q['qa_id'] for q in excluded})
    subsets={}
    for name in ['model_inputs','answers','qa_dsr']:
        rows=[r for r in read_jsonl(src/f'{name}.jsonl') if r['qa_id'] in ids]
        assert [r['qa_id'] for r in rows]==[r['qa_id'] for r in kept]
        for r in rows:
            if 'review_status' in r:r['review_status']='curated_auto_and_sampled_frame_review'
        subsets[name]=rows
    for q,m,a in zip(kept,subsets['model_inputs'],subsets['answers']):
        assert not {'answer','answer_states','answer_evidence','geometry_artifact','source_video_path','input_frame_paths'} & set(m)
        assert m['question']==q['question'] and m['options']==q['options'] and a['answer']==q['answer']
        path=Path(m['input_video_path'])
        if str(path) not in media:
            marker=json.loads(path.with_suffix('.json').read_text());assert file_hash(path)==marker['sha256'];media[str(path)]=marker
        marker=media[str(path)]
        assert marker['sha256']==m['input_video_sha256']==q['input_video_sha256']
        assert marker['timestamps_s']==m['input_timestamps_s']==q['input_timestamps_s']
        assert marker['frame_count']==len(q['input_frame_paths'])
        if q['type'].endswith('_pred'):assert marker['kind']=='observed' and max(marker['timestamps_s'])<q['prediction_target_time_s']
    write_jsonl(out/'qa_curated.jsonl',kept);write_jsonl(out/'qa_excluded.jsonl',excluded)
    for name,rows in subsets.items():write_jsonl(out/f'{name}_curated.jsonl',rows)
    screen=json.loads((ROOT/'reports/qa_review_summary.json').read_text())
    report={'input_qa':len(qs),'numerical_pass':screen['passed_qa'],'reprojection_pass':projection_pass,'curated_qa':len(kept),'held_qa':len(excluded),'curated_videos':len({q['video_id'] for q in kept}),
      'type_counts':dict(collections.Counter(q['type'] for q in kept)),'source_counts':dict(collections.Counter(q['source'] for q in kept)),
      'reason_counts_overlapping':dict(collections.Counter(r.split(':')[0] for q in excluded for r in q['reasons'])),
      'answer_recomputed':len(kept),'future_frame_leaks':0,'model_input_answer_leaks':0,
      'seconds':{'numerical_screen':screen['wall_seconds'],'reprojection':repro['seconds'],'finalization':time.perf_counter()-start},
      'gpu_executed':False,'peak_vram_gib':0,'viewer_created':False,'full_video_review':'pending',
      'source_qa_sha256':file_hash(src/'qa_all.jsonl'),'outputs_sha256':{p.name:file_hash(p) for p in [out/'qa_curated.jsonl',out/'qa_excluded.jsonl',*[out/f'{n}_curated.jsonl' for n in subsets]]}}
    assert 'torch' not in sys.modules
    write_json(ROOT/'reports/qa_curation_final.json',report);print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
