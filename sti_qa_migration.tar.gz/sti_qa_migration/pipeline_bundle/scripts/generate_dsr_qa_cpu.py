#!/usr/bin/env python3
"""CPU QA generation from finished stages 3–8; no model or API calls."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import json,time,itertools,collections,traceback
from pathlib import Path
from functools import lru_cache
import numpy as np
import qa_cpu
qa_cpu.load_rules=lru_cache(maxsize=1)(qa_cpu.load_rules)
from orient_contract import ROOT,read_jsonl,write_json,file_hash,verify_upstream
from prepare_cpu import write_jsonl
from dsr_qa_contract import TYPES,stable_seed,make_qa,validate_qa


def adapt(job):
    root=ROOT/'artifacts';sub=Path(job['video_id'])/job['segment_id']
    paths={'sam2':root/'grounded_sam2'/sub,'trajectory':root/'trajectories'/sub,'orientation':root/'orient_anything'/sub,'pi3':Path(job['output_directory'])}
    hashes={k:verify_upstream(p) for k,p in paths.items()}
    read=lambda p:json.loads(p.read_text())
    sam=read(paths['sam2']/'tracks.json');traj=read(paths['trajectory']/'trajectories.json');ori=read(paths['orientation']/'orientations.json')
    for x in [sam,traj,ori]:
        if x['source_frames']!=job['frames']:raise ValueError('Upstream frame mismatch')
    with np.load(paths['pi3']/'scene_geometry.npz',allow_pickle=False) as z:
        poses=z['camera_to_world'];local=z['local_points']
        scale=float(np.median(local[...,2][np.isfinite(local[...,2])&(local[...,2]>0)]))
    oriented={x['track_id']:x for x in ori['tracks']};tr=[];n=len(job['frames'])
    for t in traj['tracks']:
        orientation=oriented.get(t['track_id']);boxes=[]
        for frame in sam['frames']:
            obj=next(x for x in frame['objects'] if x['track_id']==t['track_id']);boxes.append(obj['bbox_xyxy'])
        tr.append({'track_id':str(t['track_id']),'label':t['label'],'group':t['group'],
          'centers_world':[x['center_world'] or [None]*3 for x in t['samples']],
          'valid':[x['valid_for_lifting'] for x in t['samples']],'bboxes_xyxy':boxes,
          'valid_point_counts':[x['valid_point_count'] for x in t['samples']],
          'world_to_agent':[np.asarray(x['rotation_agent_to_world_dsr']).T.tolist() if x['status']=='predicted' else [[None]*3 for _ in range(3)] for x in orientation['samples']] if orientation else [[[None]*3 for _ in range(3)] for _ in range(n)],
          'orientation_confidence':[x['angles']['confidence'] if x['status']=='predicted' else 0 for x in orientation['samples']] if orientation else [0]*n})
    return {'job_id':job['job_id'],'video_id':job['video_id'],'segment_id':job['segment_id'],'source':job['source'],
      'source_video_sha256':job['source_video_sha256'],'source_video_path':job['source_video_path'],
      'image_size_wh':job['original_image_size_wh'],'frame_paths':[x['path'] for x in job['frames']],
      'timestamps_s':[x['timestamp_s'] for x in job['frames']],'source_frame_indices':[x['source_frame_index'] for x in job['frames']],
      'camera_to_world':poses.tolist(),'scene_scale':scale,'tracks':tr,'sampling_policy':'1fps_fixed_interval_seed260920',
      'is_metric':False,'upstream':{k:str(p) for k,p in paths.items()},'upstream_marker_sha256':hashes}


def generate(g):
    ids=['camera']+[t['track_id'] for t in g['tracks']];agents=[t['track_id'] for t in g['tracks'] if any(c>=.6 for c in t['orientation_confidence'])]
    accepted=[];rejected=[];seen=set()
    for viewkind,observers in [('camera',['camera']),('agent',agents)]:
        for kind in TYPES:
            k=2 if kind.endswith(('_dis','_dir','_comp')) else 1
            targets=list(itertools.permutations(ids,k));candidates=list(itertools.product(observers,targets))
            rng=np.random.default_rng(stable_seed(g['job_id']+viewkind+kind));rng.shuffle(candidates)
            reasons=collections.Counter();chosen=False
            for observer,target in candidates[:64]:
                key=('distance' if kind.endswith('_dis') else kind,tuple(sorted(target)) if kind.endswith('_dis') else target)
                if kind.endswith('_dis') and key in seen:reasons['duplicate_distance_invariant_to_observer']+=1;continue
                try:
                    q=make_qa(g,kind,list(target),observer);validate_qa(q,g)
                    q['geometry_artifact']=g['geometry_artifact'];accepted.append(q);seen.add(key);chosen=True;break
                except (ValueError,FloatingPointError) as e:reasons[str(e)]+=1
            if not chosen:rejected.append({'job_id':g['job_id'],'type':kind,'viewpoint_kind':viewkind,
                         'reasons':dict(reasons) or {'no_eligible_observer_or_target':1},'attempt_limit':64})
    return accepted,rejected


def main():
    start=time.perf_counter();jobs=read_jsonl(ROOT/'manifests/sam2_all.jsonl');allqa=[];reject=[];errors=[];video_rows=[]
    output=ROOT/'outputs/dsr_qa';output.mkdir(parents=True,exist_ok=True)
    for i,job in enumerate(jobs,1):
        try:
            g=adapt(job);path=ROOT/'artifacts/qa_geometry'/job['video_id']/job['segment_id']/'geometry.json'
            write_json(path,g);g['geometry_artifact']=str(path);g['geometry_sha256']=file_hash(path)
            q,r=generate(g);allqa.extend(q);reject.extend(r)
            video_rows.append({'job_id':job['job_id'],'video_id':job['video_id'],'qa_count':len(q),'source':job['source'],'geometry':str(path)})
        except Exception as e:errors.append({'job_id':job['job_id'],'error':str(e),'traceback':traceback.format_exc()});print(json.dumps(errors[-1]),flush=True)
        if i%25==0 or i==len(jobs):print(f'{i}/{len(jobs)} QA={len(allqa)} failed_jobs={len(errors)} elapsed={time.perf_counter()-start:.1f}s',flush=True)
    write_jsonl(output/'qa_all.jsonl',allqa);write_jsonl(output/'qa_unavailable.jsonl',reject);write_jsonl(output/'videos.jsonl',video_rows)
    report={'videos_requested':len(jobs),'videos_processed':len(video_rows),'failed_jobs':errors,'qa_count':len(allqa),
      'videos_with_qa':sum(x['qa_count']>0 for x in video_rows),'type_counts':dict(collections.Counter(q['type'] for q in allqa)),
      'viewpoint_counts':dict(collections.Counter('camera' if q['viewpoint']['track_id']=='camera' else 'agent' for q in allqa)),
      'source_counts':dict(collections.Counter(q['source'] for q in allqa)),'answer_counts':dict(collections.Counter(q['answer'] for q in allqa)),
      'unavailable_buckets':len(reject),'rejection_reasons':dict(sum((collections.Counter(x['reasons']) for x in reject),collections.Counter())),
      'wall_seconds':time.perf_counter()-start,'gpu_executed':False,'peak_vram_gib':0,
      'generation_policy':'fixed entire interval; up to 1 QA per type per camera/agent viewpoint family; 64 target attempts; seed260920',
      'orientation_confidence_min':.6,'non_template':'not generated; no LLM/API call','visual_review':'pending'}
    write_json(ROOT/'reports/qa_generation.json',report);print(json.dumps(report),flush=True)
    if errors:raise SystemExit(1)


if __name__=='__main__':main()
