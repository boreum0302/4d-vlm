#!/usr/bin/env bash
# USER ONLY: never run this GPU entry point from an agent.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
subset=smoke
gpu=0
partial=()
extra=()
while (($#)); do
  case "$1" in
    --subset) subset="${2:?missing subset}"; shift 2 ;;
    --gpu) gpu="${2:?missing gpu}"; shift 2 ;;
    --allow-partial) partial+=("--allow-partial"); shift ;;
    --output-root|--max-objects|--box-threshold|--text-threshold) extra+=("$1" "${2:?missing value}"); shift 2 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
[[ "$subset" == smoke || "$subset" == all ]] || { echo 'Invalid subset' >&2; exit 2; }
[[ -n "$gpu" && "$gpu" != *,* ]] || { echo 'Select one B200' >&2; exit 2; }
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
CUDA_VISIBLE_DEVICES='' "${CPU_PYTHON:-python3}" scripts/prepare_sam2_inputs.py --subset "$subset" "${partial[@]}"
mkdir -p logs
log="logs/grounded_sam2_${subset}_$(date +%Y%m%d_%H%M%S)_$$.log"
CUDA_VISIBLE_DEVICES="$gpu" "${SAM2_PYTHON:-python3}" \
  -u gpu/extract_grounded_sam2.py --subset "$subset" "${extra[@]}" 2>&1 | tee "$log"
