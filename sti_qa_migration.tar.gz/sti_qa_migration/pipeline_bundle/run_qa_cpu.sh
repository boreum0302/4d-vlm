#!/usr/bin/env bash
# CPU only. No model/API inference and no viewer generation.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
mkdir -p outputs/dsr_qa
exec 9>outputs/dsr_qa/.run.lock
flock -n 9
"${CPU_PYTHON:-python3}" -u scripts/generate_dsr_qa_cpu.py
"${CPU_PYTHON:-python3}" -u scripts/package_dsr_qa_cpu.py
"${CPU_PYTHON:-python3}" checks/check_qa_dataset_cpu.py
