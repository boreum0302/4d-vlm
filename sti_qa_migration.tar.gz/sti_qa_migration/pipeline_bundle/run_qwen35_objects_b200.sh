#!/usr/bin/env bash
# USER ONLY: B200 inference. Agent must never invoke this script.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
subset=smoke
gpu=0
extra=()
while (($#)); do
  case "$1" in
    --subset) subset="${2:?missing subset}"; shift 2 ;;
    --gpu) gpu="${2:?missing gpu}"; shift 2 ;;
    --output-root|--max-pixels|--max-new-tokens|--model) extra+=("$1" "${2:?missing value}"); shift 2 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
[[ "$subset" == smoke || "$subset" == all ]] || { echo 'subset must be smoke or all' >&2; exit 2; }
[[ -n "$gpu" && "$gpu" != *,* ]] || { echo 'Select one GPU' >&2; exit 2; }
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
CUDA_VISIBLE_DEVICES='' "${CPU_PYTHON:-python3}" scripts/prepare_qwen35_objects.py --subset "$subset"
mkdir -p logs
log="logs/qwen35_objects_${subset}_$(date +%Y%m%d_%H%M%S)_$$.log"
CUDA_VISIBLE_DEVICES="$gpu" "${QWEN_PYTHON:-python3}" \
  -u gpu/extract_qwen35_objects.py --subset "$subset" "${extra[@]}" 2>&1 | tee "$log"
