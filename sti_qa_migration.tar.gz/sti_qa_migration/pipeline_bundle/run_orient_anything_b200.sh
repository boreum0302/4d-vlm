#!/usr/bin/env bash
# USER ONLY. Agent must never execute this GPU entry point.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
subset=all
gpu=0
while (($#)); do
  case "$1" in
    --subset) subset="${2:?missing subset}"; shift 2 ;;
    --gpu) gpu="${2:?missing gpu}"; shift 2 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
[[ "$subset" == all || "$subset" == smoke ]] || exit 2
[[ -n "$gpu" && "$gpu" != *,* ]] || exit 2
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
CUDA_VISIBLE_DEVICES='' "${CPU_PYTHON:-python3}" scripts/prepare_orient_inputs.py
mkdir -p logs
log="logs/orient_anything_${subset}_$(date +%Y%m%d_%H%M%S)_$$.log"
CUDA_VISIBLE_DEVICES="$gpu" "${ORIENT_PYTHON:-python3}" \
  -u gpu/extract_orient_anything.py --subset "$subset" 2>&1 | tee "$log"
