#!/usr/bin/env bash
# USER-ONLY GPU retry. CPU normalization runs before/after; original outputs preserved.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
gpu="${1:-0}"
[[ -n "$gpu" && "$gpu" != *,* ]] || { echo 'Select one B200' >&2; exit 2; }
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
CUDA_VISIBLE_DEVICES='' "${CPU_PYTHON:-python3}" scripts/normalize_qwen35_objects.py
[[ -s manifests/qwen35_objects_retry.jsonl ]] || { echo 'No pending jobs'; exit 0; }
mkdir -p logs
log="logs/qwen35_retry_$(date +%Y%m%d_%H%M%S)_$$.log"
status=0
CUDA_VISIBLE_DEVICES="$gpu" "${QWEN_PYTHON:-python3}" \
 -u gpu/extract_qwen35_objects.py --subset all --manifest manifests/qwen35_objects_retry.jsonl \
 --prompt prompts/qwen35_objects_retry.txt --normalize-output --max-new-tokens 4096 \
 --output-root artifacts/qwen35_retry 2>&1 | tee "$log" || status=$?
CUDA_VISIBLE_DEVICES='' "${CPU_PYTHON:-python3}" scripts/normalize_qwen35_objects.py
exit "$status"
