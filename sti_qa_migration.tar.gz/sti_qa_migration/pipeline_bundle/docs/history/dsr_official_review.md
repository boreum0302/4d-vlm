# 공식 QA의 명백한 오류만 제외

**975개 → 958개 유지 / 17개 제외**, 273개 영상. 공식 QA의 질문·선택지·정답은 수정하지 않았다. 원본 975개는 `./outputs/dsr_official/qa_all.jsonl`에 보존한다.

제외한 17개는 단일 정답 문제에서 정답과 의미가 같은 선택지가 또 있는 경우다. 예: `(1) The former is always faster.`와 `(1) The former is faster.`. 구간 전체가 한 상태인 속도 비교에 한정해 `always` 유무를 동의어로 처리한다. 상태가 여러 개인 답을 한 상태와 같다고 처리하지 않는다.

| 검사 | 결과 |
| --- | --- |
| 정답과 동의어인 대안 선택지 | 17개 제외: abs_spd_comp 16, rel_spd_comp 1 |
| 필수 질문·선택지·정답 키, 비유한 수치 문자열 | 이상 없음 |
| 질문 시간·참조 시점의 캐시 구간 대응 | 이상 없음. 고정 시점이 질문 구간 밖이더라도 입력 캐시 안이면 허용 |
| bbox 범위, anchor 시각의 실제 track·label·bbox 대응 | 이상 없음 |
| 동일 track을 자기 자신과 비교 | 없음 |
| 원본 영상 경로 | 모두 존재 |

질문 전체를 원본 템플릿으로 파싱해 bbox를 실제 생성 당시 perception call과 대조했다. 방향·이동의 정답을 독립적으로 재계산하거나 영상을 전수 시각 검수한 것은 아니다. **958개는 기초 오류 검사를 통과한 세트이지 정밀 품질 검수가 끝난 GT 세트가 아니다.**

낮은 confidence, 경계 잘림, 많은 상태 변화, 선택지 길이 차이, 척도 민감도, 재투영 오차, 카메라 중심의 쉬운 질문은 이번 제외 기준에 넣지 않았다.

| 파일 | 용도 |
| --- | --- |
| `./outputs/dsr_official_review/qa_kept.jsonl` | 유지한 958개 + 시각·track 대응 근거 |
| `./outputs/dsr_official_review/qa_pairs_kept.json` | 유지한 공식 QA 반환 형식 |
| `./outputs/dsr_official_review/qa_removed.jsonl` | 제외한 17개 원문·동의어 선택지 ID |
| `./outputs/dsr_official_review/audit_all.jsonl` | 975개 전부의 결정·검사 근거 |
| `./outputs/dsr_official_review/summary.json` | 집계·원본 hash·CPU 실행 시간 |

재현: `CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 python scripts/review_official_obvious_cpu.py`.
