# DSR 공식 함수 기반 QA — 검수 전

공식 `external/DSR_Suite/data/qa_temp.py`의 `generate_one_video`·`prob_cal` 함수 본문을 AST로 그대로 로드한다. 모델 import·전역 GPU 실행 코드는 로드하지 않는다. 공식 `template.py`와 순수 NumPy 좌표 변환·중심 계산 함수도 그대로 사용한다. 질문·정답·오답·유형 선택·질문 구간 선택은 공식 함수가 처리한다.

| 항목 | 적용 |
| --- | --- |
| 입력 | 5–8절 완료 353개 고정 구간. 1 FPS, 8–32프레임 |
| 생성 횟수 | 공식 CLI 기본값과 같은 구간당 10회 시도. 10개 성공을 보장하는 값이 아님 |
| 추가 검수 | 없음. 공식 내부 continue·confidence 조건은 원문 유지 |
| 추론 대체 | 저장된 SAM2 mask/track 및 Orient Anything 각도 반환. GPU·신규 모델 추론 없음 |
| bbox | 요청한 첫 프레임의 저장된 track mask bbox. 원본 코드의 신규 DINO 재검출 bbox와는 입력 출처가 다름 |
| 기하 입력 | Pi3 local points·valid mask를 원본 이미지 크기로 nearest upsample. 공식 코드가 중심을 다시 계산 |
| 예측 프레임 | 공식 32프레임용 `029.jpg`/`031.jpg` 요청을 가변 길이 캐시의 N-3/N-1로 대응. 프레임 추가·재샘플링 없음 |
| 시각 | 고정 구간의 원본 영상 타임스탬프 전달. 공식 함수가 마지막 2프레임을 제외한 관측 내에서 질문별 구간·고정 시점을 선택 |
| 재현 | 구간 ID 기반 고정 seed. 공식 함수/입력 어댑터 SHA-256 기록 |

이것은 **공식 QA 생성 함수 + 기존 추론 캐시 어댑터**다. 공식 파이프라인의 신규 검출·추적·32프레임 균등 추출까지 다시 실행한 결과는 아니다. QA 본문이나 선택지를 사후 수정하지 않는다. 공식 코드가 내부 예외를 잡고 건너뛰는 경우도 원래 동작대로 유지하고 관찰용 trace로 기록한다.

| 파일 | 내용 |
| --- | --- |
| `./outputs/dsr_official/qa_pairs.json` | job ID별 공식 함수 반환 목록 그대로. Type, Question, A–D, Correct |
| `./outputs/dsr_official/qa_all.jsonl` | 공식 QA에 영상·구간·seed·캐시 호출 근거만 추가. `official_qa` 내부 값은 변경 없음 |
| `./outputs/dsr_official/generation_log.jsonl` | 구간별 생성 수·공식 함수 내부에서 잡힌 예외 |
| `./outputs/dsr_official/generation_summary.json` | 성공/실패·유형·실측 시간·공식 소스 hash |

이전 자체 생성 2,442개와 선별 후보 27개는 `outputs/dsr_qa/`, `outputs/qa_review/`에 보존한다. 이번 공식 결과에 이전 품질 필터를 적용하지 않는다. 기존 27개 뷰어 데이터도 자동 교체하지 않는다.
