# DSR-Bench: 질문 비인지(naive) 샘플링의 영향

대상 run: `gs/vggt-omega/outputs/dsr_train320_omega_fourway_20260915`
(실제 경로는 심볼릭 링크 → `gs/vggt-omega/experiments/eval/subset/dsr_train320_omega_fourway_20260915`)
DSR = Dynamic Spatial Reasoning (TencentARC `DSR_Suite`). 이 run은 공식 DSR-Bench(1,484문항, human-refined)가 아니라 teacher 필터링 이전의 **DSR-Train 320문항 balanced diagnostic subset**(카테고리당 64문항 × 5카테고리, 영상 294개, Koala-36M 소스)이다.

## 벤치마크 요약 (DSI-Bench 항목과 같은 형식)

**DSR-Bench(train 320-subset): 294 videos and 320 QA pairs (64 per category × 5 categories: direction_trajectory, distance, object_selection_interaction, orientation, speed), with 94.7% of questions anchored to an explicit temporal segment ("between X s and Y s") and 100% anchored to an explicit viewpoint clause ("from/following the perspective of <object|camera> [at Z s]") — unlike DSI-Bench/VLM4D, neither of which targets a specific temporal segment. (For reference, DSI-Bench: 943 mostly short videos and 1,769 QA pairs, with no questions targeting specific temporal segments; DSI-Bench focuses on qualitative object and camera motion reasoning, without requiring absolute metric-scale estimation.)**

**Like DSI-Bench/VLM4D, DSR-Bench's answer options are purely qualitative/categorical (e.g. "Become smaller/larger", "Front|Left|Above", "The former is faster") — it does not require absolute metric-scale estimation either. What sets DSR-Bench apart is not metric precision but segment- and viewpoint-localization: fine-grained 3D reasoning about a bounding-box-referenced object pair within one bounded time window, judged from a stated (and often differently-timed) viewpoint — rather than DSI-Bench/VLM4D's whole-clip qualitative motion reasoning.**

수치 근거:
- 전체 320문항 중 명시적 시간 구간("between X s and Y s") 포함: **303건 (94.7%)**
- 명시적 시점(perspective) 절 포함: **320건 (100%)**
- 옵션 텍스트(320문항 전체)에 단위/수치(meter, degree, %, 소수점 값 등) 포함: **0건** — DSR도 DSI-Bench와 마찬가지로 metric-scale 정답을 요구하지 않음, 전부 범주형 라벨(Become smaller/larger/constant, Front/Behind/Left/Right/Above/Below 조합, The former/latter is faster 등)
- 질의 구간 길이 / 영상 전체 길이 비율: 중앙값 **23%**, 평균 31%, 최소 6% ~ 최대 94% (n=290)
- 구간이 영상 길이의 30% 미만인 문항 비율: **63.4%**

## "질문 비인지(naive) 샘플링"이 실제로 벌어지고 있다는 근거

- 프레임 샘플링 정책(`frame_sampling.sampling_policy`)은 전 문항에서 동일하게 `dsr_official_1fps` — **질문이 묻는 구간과 무관하게 영상 전체를 균일 1fps로만 샘플링**한다. 질의 구간이 짧을수록(예: 6% 사례) 그 구간 안에 들어오는 프레임은 2~3장뿐이다.
- TG(Trajectory-Grounding) 텍스트도 `[Global Camera Behavior]`로 **영상 전체의 누적 이동/회전**을 요약할 뿐, 질문이 지목한 특정 구간이나 시점(perspective anchor)에 맞춰 재구성되지 않는다(한 사례에서 TG.txt는 2,343 단어짜리 전체-클립 요약).
- 결과적으로 DSI-Bench/VLM4D와 반대로 **TG·BEV를 추가할수록 오히려 정확도가 떨어진다**:

| 조건 | 전체 정확도 | Δ(Video only 대비) |
|---|---:|---:|
| Video only | 114/320 (35.62%) | — |
| Video + BEV | 108/320 (33.75%) | −1.87pp |
| Video + TG | 81/320 (25.31%) | **−10.31pp** |
| Video + BEV + TG | 74/320 (23.12%) | **−12.50pp** |

`distance` 카테고리는 BEV+TG에서 −26.56pp(35.94%→9.38%)까지 떨어진다 — 카테고리 중 가장 크게 악화된다.

## 샘플 2건

### 예시 1 — 질의 구간과 시점 앵커가 서로 다른 시각을 가리킴
`GSVyrlTJ_MM_21__q002` · `direction_trajectory` · 영상 길이 20.9s

> Between **16.9s and 18.2s**, from the perspective of car with bounding box coordinates [365,136,541,292] **at 8.1s**, how does the direction of camera to car with initial bounding box coordinates [570,224,636,280] change?

- 균일 1fps 샘플링(총 21프레임) 중 질의 구간(16.9–18.2s) 안에 들어오는 프레임은 **2장**뿐.
- 정답은 A인데 4개 조건 전부 오답(video-only=C, +BEV=D, +TG=C, +BEV+TG=D).
- +TG 응답 원문 일부: *"The question is about the direction of the camera to a car between 16.9s and 18.2s, from the perspective of another car at 8.1s. First, I need to understand the context..."* — 모델 스스로도 "구간 시각(16.9–18.2s)"과 "시점 앵커 시각(8.1s)"이 다르다는 것 때문에 혼란스러워하는 게 CoT에 그대로 드러난다.
- TG.txt는 영상 전체에 대한 `[Global Camera Behavior]` 요약 하나뿐이라 "8.1s 시점 기준 방향"이라는 질문의 요구를 직접 뒷받침하지 못한다.

### 예시 2 — 짧은 영상에서도 구간·시점이 어긋나고, 4개 조건이 전부 같은 오답으로 수렴
`4sCmZ-GqJiE_25__q001` · `distance` · 영상 길이 26.0s

> Between **7.5s and 10.0s**, from the perspective of camera **at 24.2s**, how does the distance between horse with initial bounding box coordinates [461,158,508,268] and camera change?

- 총 26프레임 중 질의 구간(7.5–10.0s) 안에 들어오는 프레임은 **3장**뿐.
- 정답은 C(거의 변화 없음)인데 4개 조건 전부 A(변화 있음 계열)로 수렴해 오답 — 카메라가 "전체적으로는" 이동하고 있다는 TG의 전역 요약(`[Translation] State: translating, Direction: backward`)에 이끌려, 질문이 지목한 좁은 구간에서는 오히려 거리가 거의 안 변했다는 사실을 놓친다.
- +TG 응답 원문 일부: *"Wait, no—wait... Wait, no, the question is: between 7.5s and 10.0s, how does the distance... change? Wait, no, the camera's position is at 24.2s? Wait, no..."* — 두 시각(7.5–10.0s vs 24.2s)을 구분하지 못하고 자기모순적으로 되뇌는 모습.

## 시사점
DSI-Bench/VLM4D에서는 TG·BEV가 "카메라 자신의 전체 이동/회전"을 묻는 질문에 강하게 도움이 됐지만(Cam ΔTG=+32.41pp), DSR-Bench는 애초에 **영상 전체가 아니라 좁은 시간 구간 + 특정 시점 기준**을 묻도록 설계돼 있어서, 지금처럼 질문을 고려하지 않고 영상 전체를 균일 샘플링/요약해서 만든 TG·BEV는 오히려 정답에서 먼 "전역 평균적" 정보를 주입해 정확도를 깎아먹는다. 질문이 지목한 구간·시점에 맞춰 프레임을 다시 샘플링하거나 TG를 구간별로 재구성하는 것이 다음 단계로 보인다.
