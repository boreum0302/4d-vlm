# STI → DSR QA 실행 노트

갱신: 2026-09-29

## 현재 결과

**273개 영상 · 958 QA · 12종.** 공식 함수가 생성한 975개 중 정답과 동의어인 선택지가 중복된 17개를 제외한 결과다. 질문·선택지·정답은 공식 반환값을 유지한다.

- 입력: STI Dynamic Understanding 영상 363개. 별도 Video Curation 없음.
- 후속 처리: Qwen 형식 검증 통과 353구간. 이 중 273구간에서 QA 생성, 80구간은 반환 QA 없음.
- 검수: 형식·선택지·시간·bbox·객체 참조 검사 완료. **전수 시각 검수와 독립 정답 재계산은 미실행.**
- 뷰어: 958개 중 유형별 표본 100 QA / 85개 영상.

## VLM 입력 경로

작업 루트: `.`

아래 상대경로는 모두 작업 루트 기준이다.

| 용도 | 경로 | 내용 |
| --- | --- | --- |
| **VLM 입력용 QA** | `outputs/dsr_official_review/qa_kept.jsonl` | 958줄. QA별 영상 절대경로·시간·bbox 근거 포함 |
| 공식 형식 QA | `outputs/dsr_official_review/qa_pairs_kept.json` | `video_id/segment_id` → QA 리스트, 273개 키 |
| **원본 MP4** | `../data/STI-Bench/video/` | 대상 영상은 JSONL의 `source_video_path`로 선택 |
| 입력 구간·프레임 매핑 | `manifests/sam2_all.jsonl` | 전체 처리 353구간. QA의 `video_id`·`segment_id`로 연결 |
| 선택 구간 1 FPS JPEG | `inputs/pi3/<video_id>/<segment_id>/frames/` | 프레임 시각은 manifest의 `frames[].timestamp_s` |
| 제외 QA·사유 | `outputs/dsr_official_review/qa_removed.jsonl` | 17개 |
| 검수 집계·기준 | `outputs/dsr_official_review/summary.json`, `outputs/dsr_official_review/README.md` | 검사 범위·집계 |
| 검수 전 원본 QA | `outputs/dsr_official/qa_all.jsonl` | 975개 보존 |

```bash
ROOT=.
QA_JSONL=$ROOT/outputs/dsr_official_review/qa_kept.jsonl
QA_JSON=$ROOT/outputs/dsr_official_review/qa_pairs_kept.json
VIDEO_DIR=../data/STI-Bench/video
MANIFEST=$ROOT/manifests/sam2_all.jsonl
```

| JSONL 필드 | 용도 |
| --- | --- |
| `qa_id` | 추론 결과 매칭 ID |
| `source_video_path` | 원본 MP4 절대경로 |
| `video_id`, `segment_id` | 영상·입력 구간 식별자 |
| `official_qa.Type` | 질문 유형 |
| `official_qa.Question`, `official_qa.A` ~ `D` | 모델에 넣을 질문·선택지 |
| `official_qa.Correct` | 평가용 정답. 모델 입력에서 제외 |
| `basic_review.evidence.time_context` | 질문 시작·끝, 참조 시각, 관측 끝, 예측 목표 시각 |
| `basic_review.evidence.resolved_entities` | 질문에서 참조한 객체·bbox·시각 |

**시간은 원본 영상 기준 초 단위다.** 고정 입력 구간과 QA별 질문 구간은 다르다. 참조 시각 `observer_time_s`는 질문 구간 밖에 있을 수도 있으므로 입력을 자를 때 함께 확인한다. 예측형은 `observed_until_s`까지만 모델에 제공하고 미래 프레임은 제외한다. 질문의 `initial bbox`는 해당 질문의 시작 시각 기준이다.

## 파이프라인 상태

| 단계 | 결과 |
| --- | --- |
| 1 FPS 추출 | 363개 영상 · 13,331프레임 |
| 영상별 고정 구간 선택 | 363구간 · 5,663프레임 |
| π³ 기하 추론·저장 | 363구간 완료 |
| Qwen3.5-9B 객체 추출 | 353구간 형식 검증 통과 / 10구간 미해결 |
| GroundingDINO + SAM2 | 353구간 · 5,503프레임 · 2,091 tracks |
| 3D 중심·trajectory | 353구간 · 유효 중심 17,935건 / 결측 14,369건 |
| Orient Anything | 43구간 · 143 tracks · 1,029 crops. 나머지 310구간은 대상 없음 |
| 공식 DSR QA 생성 | 353구간 처리 · 273개 영상에서 975 QA 생성 |
| 기초 검수 | 958개 유지 / 정답 선택지 중복 17개 제외 |

입력 구간은 영상당 1개, seed `260920`. 1 FPS에서 길이 8–32프레임인 모든 `(start, end)` 쌍 중 균일 선택한다. 길이별 균일분포나 내용 기반 선택은 아니다.

SAM2는 첫 프레임에서 검출한 최대 16개 객체를 추적한다(box 0.35 / text 0.25). 검출 없는 구간 1개(`scene0113_00`), 상한으로 후보를 제외한 구간 10개가 있다. Qwen 미해결 10개는 agent/orientation 분류 충돌 5개와 JSON 잘림 5개다.

3D 중심은 mask를 π³ grid에 nearest resize한 뒤 유효 점의 평균을 world 좌표로 변환한다. 구간별 상대 스케일이며 결측 보간은 없다. 중심 결측은 빈 mask 13,923건과 유효 3D 점 없음 446건이다.

QA는 공식 `generate_one_video`의 질문·정답·오답·샘플링 로직을 사용하고 추론 호출만 저장된 캐시에 연결한다. 구간당 10회 시도하며 10개 생성을 보장하지 않는다. 가변 길이 입력의 예측 프레임 `029/031`은 `N-3/N-1`로 대응한다. 공식 함수는 trajectory 파일 대신 point cloud와 mask에서 중심을 다시 계산한다. 상세: `outputs/dsr_official/README.md`.

## 중간 산출물

`<video_id>/<segment_id>`는 각 QA의 식별자에 대응한다.

| 산출물 | 경로 |
| --- | --- |
| 대상 영상·원본 검사 | `manifests/dynamic_videos.jsonl`, `manifests/inventory.jsonl` |
| 전체 363개 고정 구간 | `manifests/pi3_all_s260920_k1_f8-32.jsonl` |
| 원본 1 FPS·시간 매핑 | `cache/<video_id>/1fps/frames.json` |
| 구간 입력·시간 매핑 | `inputs/pi3/<video_id>/<segment_id>/input.json` |
| π³ 기하·해상도 매핑 | `artifacts/pi3/<video_id>/<segment_id>/scene_geometry.npz`, `frame_map.json` |
| 객체·카테고리 prompt | `artifacts/qwen35_validated/<video_id>/<segment_id>/objects.json` |
| Qwen 미해결 목록 | `manifests/qwen35_objects_retry.jsonl` |
| bbox·track | `artifacts/grounded_sam2/<video_id>/<segment_id>/tracks.json` |
| 객체 mask | `artifacts/grounded_sam2/<video_id>/<segment_id>/masks/<frame_index:03d>.npz` |
| 객체 3D 중심 | `artifacts/trajectories/<video_id>/<segment_id>/trajectories.json` |
| agent 방향 | `artifacts/orient_anything/<video_id>/<segment_id>/orientations.json` |
| 공식 QA 소스 | `external/DSR_Suite/data/qa_temp.py`, `template.py` |

## 실행 규칙·재현

**GPU 실행은 사용자 전용이며 에이전트는 GPU 작업·smoke를 실행하지 않는다.** 에이전트는 CPU 준비·코드·문서·검증을 수행할 수 있다. 아래 파이프라인 작업은 완료 상태다.

CPU 명령은 작업 루트에서 실행한다.

```bash
cd .
# 입력 준비
CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 python scripts/prepare_pi3_segments.py --subset all
CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 python scripts/prepare_sam2_inputs.py --subset all
# 저장된 추론 결과로 후처리·QA 생성·검수
CUDA_VISIBLE_DEVICES='' bash run_trajectories_cpu.sh all
CUDA_VISIBLE_DEVICES='' bash run_official_qa_cpu.sh
CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 python scripts/review_official_obvious_cpu.py
```

| 완료 작업 | 실측 시간 | peak allocated / reserved VRAM | 조건 |
| --- | --- | --- | --- |
| π³ | 21분 44초 | 5.17 / 5.86 GiB | B200 1장, BF16, pixel limit 255,000, 363구간 |
| Qwen3.5-9B | 1시간 8분 26초 | 19.69 / 19.95 GiB | 성공 구간 기준. 실패 구간 peak 미기록 |
| GroundingDINO + SAM2 | 7분 42초 | 4.27 / 5.76 GiB | B200 1장, DINO FP32 / SAM2 BF16, 353구간 |
| Orient Anything | 53.74초 | 1.16 / 1.17 GiB | B200 1장, FP32, batch 1, 224×224, 1,029 crops |
| trajectory | 4분 1초 | 0 GiB | CPU |
| 공식 QA 생성 | 4분 59초 | 0 GiB | CPU |
| 기초 검수 | 0.70초 | 0 GiB | CPU |

GPU 재현 명령의 시간·메모리 참고값은 위 실측이다. 동일 조건에서 참고하며 재실행 ETA를 보장하지 않는다.

```bash
# 사용자 전용. π³: 363구간, 위 조건 실측 21분 44초 / peak 5.17·5.86 GiB
bash run_pi3_b200.sh --subset all --gpu 0
# 사용자 전용. DINO+SAM2: 353구간, 위 조건 실측 7분 42초 / peak 4.27·5.76 GiB
bash run_grounded_sam2_b200.sh --subset all --gpu 0
# 사용자 전용. Orient Anything: 1,029 crops, 위 조건 실측 53.74초 / peak 1.16·1.17 GiB
bash run_orient_anything_b200.sh --subset all --gpu 0
```

## 뷰어·다운로드

**[현재 QA 뷰어 열기]((이전 임시 URL 생략))**

- 표본: 100 QA / 85개 영상 / 12종, seed `260921`. 유형별 최대 10개, 부족한 유형은 전부 포함(`rel_ori` 3, `rel_spd` 3, `rel_spd_comp` 4).
- 화면: 왼쪽 원본 / 오른쪽 bbox, 동기 재생·탐색·배속, 유형 선택, QA·GT 표시.
- 재생: 자르지 않은 원본 MP4. 질문 시작으로 이동하며 기본적으로 질문 끝에서 정지. 예측형은 관측 시작부터 재생.
- bbox: **질문 구간 안에서만 표시.** 1 FPS 사이 기본 선형 보간, 직전값 유지 옵션 제공.
- 오른쪽 bbox는 웹 오버레이다. 영상 컨트롤의 다운로드는 원본 MP4를 저장한다.
- 표본·샘플링: `outputs/dsr_official_viewer/qa_sample.jsonl`, `sampling.json`.
- 현재 공개 주소: `viewer/public_url.txt`. 임시 Cloudflare 주소는 터널 재시작 시 바뀔 수 있다.

bbox가 포함된 별도 MP4는 요청 샘플 `14107757919671295130_3546_370_3566_370_camera_1` 한 개다. 원본 19.4초·640×360·10 FPS를 유지하고 11–15초에 tree/car bbox를 표시한다.

- 파일: `outputs/dsr_official_viewer/exports/14107757919671295130_3546_370_3566_370_camera_1_bbox.mp4`
- [bbox MP4 다운로드]((이전 임시 URL 생략))

```bash
# 표본·bbox MP4 재현 (CPU)
CUDA_VISIBLE_DEVICES='' python scripts/sample_official_viewer_cpu.py
CUDA_VISIBLE_DEVICES='' python scripts/export_sample_overlay_cpu.py
# 서버가 종료된 경우 실행 (CPU)
CUDA_VISIBLE_DEVICES='' python viewer/server.py --port 8765
# 별도 터미널에서 터널 실행. 새 도메인 뒤에 viewer/access_token 경로를 붙인다.
cloudflared tunnel --url http://127.0.0.1:8765 --protocol http2 --no-autoupdate
```
