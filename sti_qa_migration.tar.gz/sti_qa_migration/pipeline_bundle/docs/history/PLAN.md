# STI-Bench 영상에서 DSR 방식 QA 생성 계획

작성일: 2026-09-20

최신 실행 절차: [RUN.md](RUN.md). 사용자 결정으로 Video Curation은 생략하며 Dynamic Understanding 363개를 사용한다. 1 FPS → 랜덤 QA 구간 고정 → 구간별 π³ 순서로 진행하고, GPU 실행은 사용자만 수행한다. 아래는 최초 계획의 이력이다.
작업 디렉터리: `.`
최초 계획 당시 단계: CPU 전처리 완료. 전체 369개 영상 검증, 30개 pilot/6개 smoke 샘플 고정, 1,889개 프레임 및 임시 메타데이터 준비, 8종 CPU QA 생성기와 합성 테스트 완료. 실제 3D geometry 및 STI QA는 미생성. 사용자 지시에 따라 GPU 실행 금지. 상세 결과: [CPU 준비 보고서](reports/CPU_PREPARATION.md).

## 1. 목표와 범위

STI-Bench의 **영상 일부를 영상 단위로 샘플링**하여, DSR-Suite의 기하 추출 및 QA 생성 방식을 적용한다. STI의 기존 질문·정답을 변환하는 작업이 아니라, 같은 영상에 대해 새 DSR 형식 질문·4개 선택지·정답·검증 근거를 만든다.

우선 템플릿 기반 생성으로 재현 가능한 소규모 결과를 확보하고, 이후 agent 관찰 시점 및 비템플릿 QA로 확장한다. 아래의 샘플 수, seed, 단계별 QA 목표는 실행을 위한 **제안값**이며 사용자가 확정한 요구사항은 아니다.

## 2. 직접 확인한 데이터와 레포

| 용도 | 실제 경로 | 확인 결과 |
| --- | --- | --- |
| STI GitHub clone + 데이터 | `../data/STI-Bench` | Git origin: `https://github.com/MINT-SJTU/STI-Bench.git` |
| STI 원본 영상 | `../data/STI-Bench/video` | mp4 파일 371개 |
| STI QA 메타데이터 | `../data/STI-Bench/qa.parquet` | 2,064행, 고유 영상 369개, 참조 영상 누락 0개 |
| STI HF test 파일 | `../data/STI-Bench/data/test-00000-of-00001.parquet` | 2,064행, 같은 컬럼 구성; 두 파일의 전수 내용 동일성은 미검증 |
| DSR 코드 clone | `external/DSR_Suite` | 생성 코드와 데이터가 함께 있는 기준 레포 |
| DSR 생성 코드 | `external/DSR_Suite/data` | `qa_temp.py`, `qa_nontemp.py`, `qa_utils.py`, `template.py` 등 |
| DSR-Bench QA | `external/DSR_Suite/dataset/benchmark.parquet` | 1,450 QA / 563개 videoID |
| DSR-Train QA | `external/DSR_Suite/dataset/train_qa_pairs.parquet` | 55,182 QA / 9,966개 videoID |
| DSR-Train JSON | `external/DSR_Suite/dataset/train_qa_pairs.json` | 파일 존재 확인 |
| DSR 추가 코드 사본 | `external/gvlm/DSR_Suite` | archive가 기록한 코드 사본. 이 사본의 `dataset/`은 현재 없음 |
| DSR 영상 수집 관련 자료 | `external/DSR_Suite/koala_collection` | metadata JSONL, `full_train/`, 수집 로그 존재. 영상의 완전성은 미확인 |

STI clone HEAD: `8863104d81547abea1b5ccd02fef9cab04b046ef`
DSR 기준 clone HEAD: `ae81203a672613bc746fce8299b2be3b9133ede1`
HEAD는 버전 식별값이며 작업 트리가 원본과 완전히 동일하다는 검증은 아니다. 구현 시 사용하는 파일의 해시도 기록한다.

STI 영상 단위 출처 분포(`Video` 중복 제거 후 집계):

| Source | scene | 영상 수 |
| --- | --- | ---: |
| ScanNet | indoor | 150 |
| Omni6DPose | desktop | 119 |
| Waymo | outdoor | 100 |
| 합계 | | 369 |

STI 컬럼: `Video, Source, Task, QType, Question, Prompt, time_start, time_end, Candidates, Answer, Answer Detail, ID, scene`.
공개 QA에는 caption, 프레임별 mask, 3D trajectory, camera pose 컬럼이 없다. 기존 QA의 `Prompt`를 영상 caption이라고 가정하면 안 된다. 생성용 caption 및 agent/object 목록은 별도로 준비한다.

**기존 기록의 보정**

- archive의 MD 10개를 검색했으며 STI-Bench 직접 언급은 없었다. DSR 문서의 경로에서 인접한 데이터 폴더를 탐색해 STI clone을 찾았다. DSI-Bench와 STI-Bench는 서로 다른 데이터셋이다.
- archive에는 DSR-Train 영상 수가 10,000으로 정리되어 있으나, 현재 로컬 parquet의 고유 videoID는 9,966개다. 실제 로컬 수치를 사용한다.
- `DSR_BENCH_FACTS.md`의 비템플릿 “Type 없음” 설명은 parquet에는 적용되지 않는다. 직접 확인한 스키마는 소문자 `type`이며 `non_temp` 239행이다. 템플릿 QA는 1,211행이다.
- `external/DSR_Suite/dsr-bench/`는 현재 비어 있다. 이 폴더를 준비된 영상 루트로 사용하지 않는다. 이번 작업의 영상 입력은 STI이므로 DSR 영상 다운로드가 선행 조건은 아니다.

## 3. 논문에서 가져올 원칙

[DSR-Suite 논문](https://arxiv.org/pdf/2512.20557)의 §3.1–3.3, Figure 2, Tables 1–2를 확인했다. 생성 과정은 동적 영상 선별 → 기하 단서 추출 → QA 생성이다. π³는 장면 기하와 카메라 pose, Grounded SAM2는 객체 mask/track, Orient Anything은 agent orientation을 담당한다. 정답은 상대 스케일의 기하에서 얻는 정성적 변화이며, 관찰 좌표계를 고정하거나 시간에 따라 이동시킨다. 논문은 train에 균일 32프레임, benchmark에 1 FPS를 사용하고 benchmark QA를 사람이 검수한다.

이 원칙을 STI 영상에 적용하되, 논문의 Koala 영상 길이 필터(20–120초)를 STI 전체에 자동 적용하지 않는다. 먼저 실제 길이와 유효 구간을 조사한다. 추정 기하는 센서 GT가 아니므로 자동 생성 정답을 검증 전부터 ground truth로 간주하지 않는다.

## 4. 로컬 생성 코드의 실제 동작과 수정 지점

기준: 위 레포의 `data/README.md`, `qa_temp.py`, `qa_utils.py`, `template.py`를 직접 읽었다.

### 입력 및 출력

- `agent_object.csv`: 적어도 `videoID`, `agent`, `obj` 필요. `agent`, `obj`는 마침표로 분리하는 문자열이다. `videoID`로 `<video_root>/<videoID>.mp4`를 찾는다.
- `dynamic_videos.json`: 생성 대상으로 인정할 영상 이름 목록. 원본 코드는 점 앞부분을 ID로 사용하므로 adapter에서 확장자 처리와 ID 보존을 명시한다.
- `agent`가 결측이면 원본 코드는 해당 영상을 건너뛴다. camera-only가 유효한 STI 영상도 처리하도록 결측과 빈 목록을 구분해야 한다.
- 템플릿 출력은 영상 ID별 QA 목록이며 QA 필드는 `Type`, `Question`, `A/B/C/D`, `Correct`다. benchmark parquet의 소문자 필드와는 adapter로 연결한다.
- `--qa_num`은 성공 QA 개수를 보장하지 않는다. 시도 중 탈락과 예외가 있으므로 요청·시도·성공·탈락 수를 따로 기록한다.

### 코드 재사용 전에 해결할 사항

1. **32프레임 가정**: `qa_utils.sample_uniform_frames(num_frames=32)`가 기본이다. `qa_temp.py`는 `timestamps[:-2]`와 prediction 분기의 `029.jpg`, `031.jpg`를 사용한다. 1 FPS로 바꾸려면 프레임 번호·관측 종료·예측 대상 프레임을 함께 일반화해야 한다. 단순히 샘플링 함수만 교체하지 않는다.
2. **프레임 수와 초 구분**: 원본의 최소 프레임 수 조건을 “4초”로 해석하지 않는다. 균일 32프레임에서는 영상 길이에 따라 시간 간격이 다르다. 시간은 원본 프레임 인덱스/PTS와 함께 저장한다.
3. **좌표 및 속도 정의**: 좌표 축, pose 변환 방향, 벡터의 시작/끝 객체, moving viewpoint의 속도 의미를 함수별로 점검한다. FPS 정책 변경 시 속도 계산의 실제 Δt 사용 여부를 검증한다. 수정 시 원본과의 차이를 기록한다.
4. **정답 범주화**: `describe_dist_runs`, `describe_spd_comp`의 기본 epsilon은 0.2, `describe_dir`는 0.3이다. 거리 함수에는 0.1 기준과 run 누적 비교도 있다. 단순 “매 프레임 20% 비교”로 재구현하지 않고 실제 함수를 기준으로 삼는다. 상대 스케일 변화에 민감한 상수는 별도로 검증한다.
5. **실패 추적**: 원본의 `except Exception: pass`를 구조화된 실패 로그로 바꾼다. 구간/오답 재샘플링 반복에는 최대 시도 수를 둔다.
6. **소규모 실행**: `split_data`는 데이터 수보다 process 수가 많으면 step=0이 될 수 있다. smoke 단계는 process 1개로 시작하고 분할 함수를 보완한다. 기본 process 10개와 GPU 번호 직접 매핑을 그대로 사용하지 않는다.
7. **입출력 격리**: 원본은 현재 디렉터리의 CSV/JSON, `./models/`, 임시 프레임 폴더, 출력 glob에 의존한다. 경로를 config로 명시하고 영상/run별 임시 폴더와 atomic 저장, 재개 가능한 상태 기록을 사용한다.
8. **실행 환경**: 기준 clone의 `data/models/`는 없다. 현재 확인한 Python에는 pandas/pyarrow는 있지만 cv2는 없고, ffprobe는 있다. 다른 환경·체크포인트의 재사용 가능성은 구현 시작 시 조사한다. 현재 생성 가능 상태라고 단정하지 않는다.

## 5. 실행 단계

### A. 영상 inventory와 재현 가능한 샘플링

1. `qa.parquet`의 고유 `Video` 369개를 후보 모집단으로 삼는다. 디스크의 추가 mp4 2개는 metadata 연결이 확인되기 전 제외한다.
2. ffprobe로 duration/FPS/해상도/프레임 수를 수집하고 decode, 장면 전환, 중복 영상 여부를 점검한다. 영상 경로, 파일 식별값, Source, scene, 기존 QA ID를 manifest에 남긴다.
3. Source별로 seed `260920`을 고정해 후보를 섞는다. 기존 QA 개수로 가중 샘플링하지 않는다.
4. 제안: **smoke 6개(출처별 2개) → pilot 30개(출처별 10개)**. 원본 영상의 순위와 제외 사유를 기록해 실패 영상을 조용히 교체하지 않는다.
5. 원본 영상에서 camera/object motion, 추적 가능 객체 수, 가림, 회전, 동적/정적 객체 구성을 확인한다. 출처만으로 운동 특성을 확정하지 않는다. 카메라 운동만 있는 영상도 그에 맞는 QA는 허용한다.

완료 조건: 샘플 manifest, 영상별 적합성 및 제외 사유, 출처별 실제 선택 수가 재현 가능하다.

### B. 생성용 객체 목록과 geometry 추출

1. smoke에서는 사람이 영상 및 contact sheet를 보며 간단한 caption과 agent/non-agent 목록을 작성해 schema를 확정한다. pilot부터 필요에 따라 VLM/LLM curation을 추가한다. STI 정답으로 생성 정답을 유도하지 않는다.
2. GroundingDINO + SAM2로 객체를 찾고 추적한다. bbox 원본 해상도와 bbox가 가리키는 시각을 저장한다. ID switch, 가림, mask 품질이 나쁜 구간은 제외한다.
3. π³로 point cloud/confidence/camera pose를 추출하고 유효 mask의 3D 중심을 계산한다. agent viewpoint 또는 orientation QA가 필요할 때 Orient Anything을 적용한다.
4. smoke는 코드 정합성 확인을 위해 **균일 32프레임**부터 시작한다. 이후 인덱스 가정을 수정하고 pilot에서 **1 FPS** 정책을 별도로 검증한다. 빠른 움직임과 짧은 구간은 더 조밀한 확인용 샘플을 사용하되 정책을 기록한다.
5. QA 구간과 고정 viewpoint의 참조 프레임을 모두 포함한다. 별도 재구성된 구간의 좌표를 정렬 없이 섞지 않는다. 계산량 제한 시 최대 프레임/해상도/구간 길이를 config에 명시한다.

완료 조건: 프레임 시간표, mask/track, camera pose, object centers, 필요한 orientation과 품질 지표가 저장되고 시각적으로 검토 가능하다.

### C. 템플릿 QA 생성

기존 `template.py`의 12종을 기준으로 하되 다음 순서로 늘린다.

| 단계 | 유형 | 조건 |
| --- | --- | --- |
| 첫 smoke | `abs_dis`, `rel_dis`, `abs_dir`, `rel_dir` | camera viewpoint부터 시작, 유효 객체/카메라 조합 |
| pilot 확장 | `abs_spd`, `rel_spd`, `abs_spd_comp`, `rel_spd_comp` | Δt·좌표계·track 안정성 검증 |
| orientation 확장 | `abs_ori`, `rel_ori` 및 agent viewpoint | 방향 추정 신뢰도와 축 convention 검증 |
| prediction 확장 | `abs_dir_pred`, `rel_dir_pred` | 관측 종료와 target horizon, 숨길 미래 프레임 정의 |

- `abs_*`는 지정 시각의 좌표계를 고정하고 `rel_*`는 관찰자의 좌표계를 시간에 따라 갱신한다. 절대 거리 단위를 뜻하는 `abs`가 아니다.
- 각 QA에 query interval, viewpoint 대상, viewpoint mode, reference timestamp, target object IDs, bbox timestamp를 독립 필드로 기록한다.
- 상태 시퀀스를 규칙 함수로 계산한 뒤 질문과 4개 선택지를 만든다. 오답은 정답 및 다른 오답과 중복되지 않아야 하고, 선택지 순서를 섞은 뒤 정답 label을 검증한다.
- pilot 목표는 **영상당 검수 통과 4–8 QA, 30개 영상 기준 120–240 QA**다. 목표 수를 채우려고 불안정한 유형을 강제로 생성하지 않는다. 부족분과 실패 유형을 보고한다.
- 거리의 강체 좌표변환 불변성 때문에 viewpoint만 다른 동일 거리 QA가 중복될 수 있다. 의미상 중복을 제거한다.
- prediction은 입력 영상에 이미 정답 미래 구간이 포함되는지 반드시 확인한다. 원본 구현의 관측/target 프레임 관계를 검증한 뒤 활성화한다.

### D. 품질 검증 및 비템플릿 확장

자동 검증:

- 영상/프레임 존재, 시간 범위·순서, bbox 좌표 범위, target/observer ID 일치.
- NaN/Inf, 0에 가까운 분모, 중복 timestamp, track 단절, 비정상적 좌표 점프.
- 저장한 geometry와 config에서 정답 재계산 가능 여부.
- 서로 다른 4개 선택지와 정확히 하나의 정답, answer label 정합성.
- 정지·등속·접근·이탈·좌표 회전 등 작은 합성 궤적으로 분류 및 변환 방향을 검증한다. geometry 오차/임계값 주변 perturbation으로 답이 자주 바뀌는 문항은 제외 또는 검토 대상으로 표시한다.

사람 검수:

- smoke와 pilot의 채택 QA 전수를 영상·bbox overlay·궤적·상태 구간과 함께 확인한다.
- 영상에서 식별 불가능한 객체, 모호한 좌우/관찰 시점, 잡음 때문에 상태가 과도하게 전환되는 문항은 reject한다.
- 검수 상태를 `pending/accepted/rejected`로 분리하고 수정 이력을 보관한다. 원본 코드가 허용하는 최대 15개 상태 구간을 품질 목표로 삼지 않는다.

비템플릿은 템플릿 pilot이 안정화된 뒤 `qa_nontemp.py` 방식을 검토한다. 추정 trajectory·객체·viewpoint를 텍스트로 제공하는 생성이며, 출력 정답은 가능한 한 수치 근거와 다시 대조한다. API 모델/비용/endpoint 설정은 실행 단계에서 정한다.

## 6. 산출물 구조와 provenance

아래는 최초 계획 구조다. 실제 CPU 산출물과 현재 파일 구성은 [README.md](README.md)를 따른다.

```text
260920-sti-qa-generation/
  PLAN.md
  configs/generation.yaml
  manifests/{inventory,sampled_videos,rejected_videos}.jsonl
  metadata/{captions,agent_objects}.jsonl
  scripts/                         # inventory, adapter, extraction, QA, validation
  cache/<video_id>/                # frame map, geometry, tracks, confidence
  outputs/{qa_candidates,qa_accepted,qa_rejected}.jsonl
  review/                         # contact sheets, overlays, review records
  reports/{pilot_report,implementation_changes}.md
```

QA 저장 필드 초안:

```text
qa_id, video_id, source, scene, source_video_path,
type, question, options[A..D], answer,
query_start_s, query_end_s,
viewpoint{entity_id,mode,reference_time_s},
targets[{track_id,label,bbox_xyxy,bbox_time_s,bbox_image_size}],
observed_until_s, prediction_target_time_s,
frame_indices, frame_timestamps_s, sampling_policy,
geometry_artifact, answer_states, answer_evidence,
seed, code_revision, config_hash, model_revisions,
review_status, rejection_reason
```

해당하지 않는 시간 필드는 null로 둔다. 초 단위 시간은 원본 영상 기준이며 crop을 사용하면 crop offset과 원본 시간 매핑도 저장한다. 원본 STI/DSR 폴더는 입력으로 사용하고 생성물은 작업 폴더 아래에 쓴다.

## 7. 완료 기준과 다음 작업

실행 완료는 단순 QA JSON 생성이 아니라, 다음이 갖춰졌을 때로 정의한다.

1. seed와 manifest로 동일 영상 subset을 다시 선택할 수 있다.
2. 각 QA의 객체·구간·관찰 시점·geometry·정답 계산을 추적할 수 있다.
3. pilot의 채택 QA가 자동 검사 및 사람 검수를 통과한다.
4. 출처/유형별 채택 수, 정답 위치 분포, 탈락 이유, 영상당 시간·GPU 메모리·API 사용량을 보고한다.
5. 32프레임/1 FPS 차이, 원본 코드 수정 사항, 미지원 유형을 명시한다.

위 최초 계획의 CPU 준비 단계는 완료했다. 이후 실제 geometry 확보는 별도 과제이며 현재 GPU 실행은 금지되어 있다. 최종 subset 크기와 용도(train/eval)는 아직 정해지지 않았다. 학습에 사용하게 되면 원본 영상 단위로 분리하고, 같은 STI 영상에 대한 기존 benchmark 평가와의 overlap을 명시한다.

## 8. 참고 자료

- [DSR-Suite 논문](https://arxiv.org/pdf/2512.20557)
- [DSR GitHub](https://github.com/TencentARC/DSR_Suite)
- [STI GitHub — 로컬 origin](https://github.com/MINT-SJTU/STI-Bench)
- [archive: DSR 생성 파이프라인](DSR_QA_TEMPLATE_PIPELINE.md)
- [archive: DSR 데이터 사실 정리](DSR_BENCH_FACTS.md)
- [archive: 질의 비인지 샘플링 분석](DSR_BENCH_NAIVE_SAMPLING_ANALYSIS.md)
- [archive: 참조 시각 혼동 사례](CASE11_DSR_REFERENCE_TIMESTAMP_CONFUSION.md)
- [STI 로컬 README](../data/STI-Bench/README.md)
- [DSR 생성 README](external/DSR_Suite/data/README.md)
- [DSR 템플릿](external/DSR_Suite/data/template.py)
- [DSR 생성 코드](external/DSR_Suite/data/qa_temp.py)
- [DSR geometry 및 sampling 함수](external/DSR_Suite/data/qa_utils.py)

archive의 성능 저하 원인 분석은 기존 실험의 해석으로 참고한다. 이를 STI에서도 검증된 인과관계나 추정 기하의 정확성 보장으로 취급하지 않는다.
