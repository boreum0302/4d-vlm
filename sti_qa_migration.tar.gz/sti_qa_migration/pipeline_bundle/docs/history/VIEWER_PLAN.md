# QA 검수 뷰어 표시 설계

사용자 요청으로 CPU 뷰어 구현·실행 완료. 원본 영상 위에 브라우저 SVG로 bbox를 표시하며 별도 렌더링 MP4는 만들지 않는다. 실행·접속은 RUN.md 11절 참조.

| 요소 | 표시 방식 |
| --- | --- |
| 대상 | `./outputs/dsr_official_viewer/qa_sample.jsonl`의 유형별 랜덤 QA 100개 |
| 영상 | 왼쪽 원본 MP4 / 오른쪽 bbox 오버레이. 오른쪽 영상 조작으로 양쪽 재생·탐색·배속 동기화 |
| 질문·정답 | QA, 선택지, GT 정답을 영상과 함께 표시. GT는 추정 기하 기반 정답임을 구분 |
| 객체 식별 | 질문에 등장하는 target 및 객체 observer의 동일 track ID를 유지; 색·이름 고정 |
| 초기 bbox | 질문의 `bbox_time_s`에 질문의 `bbox_xyxy`를 원본 픽셀 좌표 그대로 표시 |
| 후속 bbox | 같은 SAM2 track의 프레임별 2D bbox 사용. 3D trajectory를 새로 투영할 필요 없음 |
| 시간 범위 | 질문이 3–5초이면 그 범위 안에서만 bbox 표시. anchor가 시작 시각과 다르면 실제 명시 시각 준수 |
| 원본 좌표·시각 | 영상 표시 배율만큼 bbox 좌표 변환; 원본 PTS/frame index 매핑 사용 |
| 1 FPS 사이 | 기본 선형 보간, 직전 bbox 유지 선택 가능. 양 끝 bbox 중 결측이 있으면 보간하지 않음. 표시 추정값은 실측 bbox와 구분 |
| 결측·카메라 | bbox 결측을 임의 track으로 대체하지 않음. 촬영 카메라 자체에는 bbox 없음 |
| 예측형 | 검수 화면에서 관측 종료·예측 목표 시각 구분. 미래 정답 확인 영상과 미래 프레임이 제거된 모델 입력을 구분 |

원본 영상: `../data/STI-Bench/video/`.

bbox·track: `./artifacts/grounded_sam2/<video_id>/<segment_id>/tracks.json`.

프레임 원본 시각 매핑: `./cache/<video_id>/1fps/frames.json`.

정답: `./outputs/dsr_official_viewer/qa_sample.jsonl의 official_qa.Correct 및 A–D`.
