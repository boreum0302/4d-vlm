# DSR-Train / DSR-Bench 확인된 사실

## 데이터셋 규모
| | 영상 수 | QA 수 |
|---|---:|---:|
| DSR-Train (전체) | 10,000 | 55,182 (paper 보고치 50K) |
| DSR-Bench (전체, human-refined) | 563 | 1,450 (paper 보고치 575 videos / 1,484 QA) |
| 현재 확보한 4조건(VO/+BEV/+TG/+BEV+TG) 평가 | 294 | 320 — **DSR-Train에서 뽑은 balanced subset**, DSR-Bench 자체 평가 아님 |

## 질문 구조
- 공통 서술 패턴: `"Between X s and Y s, from/following the perspective of <camera|object [at Z s]>, ..."`
- 명시적 시간 구간("between X s and Y s") 포함 비율: DSR-Bench 80.41%(1,166/1,450), DSR-Train 85.48%(47,170/55,182). 없는 문항은 전부 `*_dir_pred`(미래 방향 예측) 타입 — 구간 대신 단일 시점만 지정.
- 명시적 시점(perspective) 절 포함 비율: DSR-Bench·DSR-Train 둘 다 **100%**.
- DSI-Bench·VLM4D에는 이런 시간 구간/시점 지정 질문이 없음(0%).

## Metric-scale(수치 단위) 정답 여부
- DSR-Bench·DSR-Train 둘 다 옵션·질문에 미터/도/%/소수점 수치 단위 **없음** (전수 검사, 실질 0건). 정답은 전부 범주형(Become smaller/larger/constant, Front/Behind/Left/Right 조합, The former/latter is faster 등).
- 단, 정답을 만드는 내부 로직(`Answer_cot`)은 각도(degree) 임계값 등 continuous 값을 계산해 범주형으로 버킷화함 — 이 수치는 생성 파이프라인 내부에서만 쓰이고 질문·정답에는 노출 안 됨.
- DSI-Bench도 동일하게 metric-scale 없음(옵션 348개 전수 확인, 0건) — DSR과 DSI 모두 "정성적 방향/추세 판단" 벤치마크.

## 객체 식별 vs 시점(perspective) — 서로 다른 메커니즘
- **객체 식별**은 bounding box 좌표(원본 영상 픽셀 좌표계)로 이루어짐. Viewpoint와 무관.
  - bbox가 있는 문항 중 80% 이상은 숫자 timestamp가 아니라 "initial"/"final"(첫/마지막 프레임) 라벨만 사용. bbox에 숫자 timestamp가 직접 붙는 경우("... coordinates [x,y,x,y] at 8.1s")는 17~19%뿐.
  - 전체 문항의 12~15%는 bbox 자체가 없음(질문 대상이 카메라 자신이거나, bbox 없이 서술만으로 비교하는 문항).
- **시점(perspective) 절**은 정답을 판단할 기준 좌표계(어느 대상의 앞/뒤/좌/우를 기준 삼을지)를 정하는 것으로, 객체 식별과는 별개. 전 문항 100%에 존재.
- 결론: `"Objects are identified by timestamps and bounding boxes, with explicit viewpoint references."` 문장은 **뒤의 `, with explicit viewpoint references` 구절만 삭제**하면 정확함 → `"Objects are identified by timestamps and bounding boxes."`

## QA 카테고리 — 공식 vs 비공식
- **공식**(`DSR_Suite` 코드/데이터에 실존, `data/template.py`의 `question_type` 리스트 및 `Type` 필드): `rel_dis, rel_dir, rel_ori, abs_dis, abs_dir, abs_ori, rel_spd, abs_spd, rel_spd_comp, abs_spd_comp, rel_dir_pred, abs_dir_pred` (12종) + `Type` 필드가 아예 없는 자유생성(`qa_nontemp.py`) 문항.
- **비공식**(`DSR_Suite`에는 없고, 우리 쪽 eval harness `gs/vggt-omega/scripts/build_dsr_train_grpo_smoke.py`의 `CATEGORY_TYPES`가 만든 그룹핑): `direction_trajectory / distance / speed / orientation / object_selection_interaction`. `object_selection_interaction`이라는 이름 자체도 비공식 — 실제로는 "Type 없는 자유생성 문항" 캐치올 버킷.

## 정확도 — DSR-Train 320-subset (Qwen3-VL-8B-Thinking, 공식 Type 기준)
| QA 유형(공식 Type) | n | Video only | +TG | +BEV | +BEV+TG |
|---|---:|---:|---:|---:|---:|
| rel_dis | 40 | 35.00% | 22.50% (−12.50) | 30.00% (−5.00) | 7.50% (−27.50) |
| rel_dir | 26 | 26.92% | 3.85% (−23.08) | 23.08% (−3.85) | 7.69% (−19.23) |
| rel_ori | 35 | 37.14% | 28.57% (−8.57) | 42.86% (+5.71) | 28.57% (−8.57) |
| abs_dis | 24 | 37.50% | 12.50% (−25.00) | 20.83% (−16.67) | 12.50% (−25.00) |
| abs_dir | 8 | 25.00% | 0.00% (−25.00) | 12.50% (−12.50) | 25.00% (+0.00) |
| abs_ori | 29 | 37.93% | 6.90% (−31.03) | 34.48% (−3.45) | 13.79% (−24.14) |
| rel_spd | 24 | 50.00% | 45.83% (−4.17) | 41.67% (−8.33) | 45.83% (−4.17) |
| abs_spd | 10 | 40.00% | 40.00% (+0.00) | 50.00% (+10.00) | 30.00% (−10.00) |
| rel_spd_comp | 14 | 21.43% | 28.57% (+7.14) | 35.71% (+14.29) | 42.86% (+21.43) |
| abs_spd_comp | 16 | 50.00% | 25.00% (−25.00) | 18.75% (−31.25) | 6.25% (−43.75) |
| rel_dir_pred | 17 | 47.06% | 41.18% (−5.88) | 47.06% (+0.00) | 29.41% (−17.65) |
| abs_dir_pred | 13 | 38.46% | 15.38% (−23.08) | 15.38% (−23.08) | 30.77% (−7.69) |
| (Type 없음, 자유생성) | 64 | 28.12% | 37.50% (+9.38) | 40.62% (+12.50) | 31.25% (+3.12) |
| **전체** | **320** | **35.62%** | **25.31% (−10.31)** | **33.75% (−1.87)** | **23.12% (−12.50)** |

DSI-Bench/VLM4D와 반대로 대부분의 Type에서 TG·BEV가 정확도를 깎음 — 질문이 좁은 시간 구간·특정 시점을 지목하는데, 현재 BEV/TG는 영상 전체를 질문과 무관하게 균일 샘플링/요약해서 만들기 때문(별도 파일: `DSR_BENCH_NAIVE_SAMPLING_ANALYSIS.md`).

## 아직 없는 것
- DSR에 대한 `+fBEV`/`+fBEV+TG`(per-frame BEV) 평가 — DSI/VLM4D 전용 ablation이라 DSR은 실행된 적 없음.
- 공식 DSR-Bench(1,450문항) 자체에 대한 4조건(VO/+BEV/+TG/+BEV+TG) 평가 — 지금 있는 건 DSR-Train 320-subset뿐.

## 관련 파일
- `dsr_train_full_time_segment_classification.json` — DSR-Train 전체 55,182문항 구간 라벨
- `dsr_bench_time_segment_classification.json` — DSR-Bench 전체 1,450문항 구간 라벨
- `DSR_BENCH_NAIVE_SAMPLING_ANALYSIS.md` — naive 샘플링이 정확도에 미치는 영향, 실패 사례 2건
