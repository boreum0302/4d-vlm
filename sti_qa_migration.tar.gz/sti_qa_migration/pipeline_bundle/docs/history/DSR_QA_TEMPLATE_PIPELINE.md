# DSR-Bench/DSR-Train QA 생성 파이프라인 (DSR_Suite 레포 확인 결과)

**출처**: `github.com/TencentARC/DSR_Suite` (로컬 `external/legacy_reference`)
**확인 파일**: `data/template.py`, `data/qa_temp.py`, `data/qa_nontemp.py`, `data/qa_utils.py`, `data/README.md`, `dataset/README.md`

## 핵심 사실

- VLM4D·DSI-Bench와 달리, DSR_Suite 레포에는 **QA를 실제로 생성하는 코드가 공개되어 있음**.
- 공식 문서(`data/README.md`)에 명시: **"Our QAs are generated with two different paradigms: template-based and non-template-based."**
- **DSR-Bench(1,484 QA)와 DSR-Train(50,000 QA)은 완전히 동일한 생성 파이프라인**을 씀. 차이는 DSR-Bench가 생성 후 **사람이 한 번 더 검수·정제**했다는 것뿐(`dataset/README.md`).
- **정답은 GPT/LLM이 영상을 보고 만드는 게 아니라, 비전 모델이 뽑은 3D 좌표를 수식·임계값으로 범주화해 결정론적으로 계산**됨. 질문 문장만 그 결과를 템플릿에 끼워 넣어 조립.

## 파이프라인 4단계 (template-based 기준)

1. **3D 정보 추출** — Grounded-SAM2(객체 bbox/mask), π³(카메라 pose·포인트클라우드), Orient-Anything(orientation). 모두 비전 모델, LLM 아님.
2. **좌표 계산** — `qa_utils.py`의 `extract_obj_center`, `cal_dis`, `camera_mutual_coordinate_transform` 등 순수 numpy 연산. 이 파일에 `openai`/`gpt`/`api_key` 호출 없음(직접 확인).
3. **규칙 기반 범주화** — `template.py`의 `describe_dist_runs`/`describe_dir`/`describe_spd_comp`가 프레임 간 변화율에 임계값(예: 20%)을 적용해 "Become larger/smaller/Keep nearly constant" 같은 정답 문장(GT)을 확정. 오답 3개는 랜덤 궤적을 같은 함수에 통과시켜 정답과 겹치지 않을 때까지 재샘플링.
4. **템플릿 조립** — 확정된 정답/agent/object 문자열을 `template[qa_type].format(...)`에 끼워 최종 질문 문장 생성.

→ **GPT/LLM은 답을 만드는 데 전혀 관여하지 않음.**

## LLM이 실제로 쓰이는 곳

- **비디오 큐레이션**: DeepSeek-R1/Gemini-2.5-Pro로 "동적 영상인지", "이 객체가 방향성 있는 agent인지" 필터링(`deepseek_motion.py`, `deepseek_agent.py`, `gemini_motion.py`). QA 생성과 무관.
- **비템플릿(`type=non_temp`) QA**: `qa_nontemp.py`가 담당. 템플릿 QA와 동일하게 Grounded-SAM2+π³로 여러 객체의 3D 궤적(`obj_coords`, 숫자 좌표 딕셔너리)까지는 코드로 계산하지만, 그 다음 **질문 + 4개 선택지 + 정답 표시까지 전부 DeepSeek-R1에게 한 번에 맡김**(`qa_nontemp.py:288-329`, DeepSeek API 프롬프트에 "generate one question... and 4 answers where one of them is the correct answer... output the symbol of correct answer" 지시). 단, DeepSeek은 영상·이미지를 직접 보지 않고 **이미 정확히 계산된 3D 좌표 숫자를 텍스트로만** 받음 — "영상 보고 추론해서 맞힌다"가 아니라 "이미 확정된 좌표 데이터를 질문·선택지 형태로 포장"하는 역할.

## 비템플릿 비율 (DSR-Bench, `dataset/benchmark.parquet` 1,450개 직접 카운트)

| 구분 | n | 비율 |
|---|---:|---:|
| 비템플릿(`type="non_temp"`, DeepSeek-R1이 Q+선택지+정답 전부 작성) | 239 | **16.48%** |
| 템플릿 기반(12종 `type`, `describe_*` 규칙함수로 정답 결정론적 계산) | 1,211 | 83.52% |

`type` 컬럼(소문자)에 `NaN`이 아니라 문자열 `"non_temp"`로 명시적으로 라벨링되어 있음 — 이전에 "Type 필드 없음"이라 표현한 것은 부정확했고 정정함.

## 공식 템플릿 12종 (`data/template.py`)

`question_type = ["rel_dis","rel_dir","rel_ori","abs_dis","abs_dir","abs_ori","rel_spd","abs_spd","rel_spd_comp","abs_spd_comp","rel_dir_pred","abs_dir_pred"]`

| Type | 템플릿 (`.format(time_2, time_end, agent, time_1, object_1, object_2)`) |
|---|---|
| `rel_dis` | `Between {t2}s and {t_end}s, following the perspective of {agent}, how does the distance between {obj1} and {obj2} change?` |
| `rel_dir` | `Between {t2}s and {t_end}s, following the perspective of {agent}, how does the direction of {obj1} to {obj2} change?` |
| `rel_ori` | `Between {t2}s and {t_end}s, following the perspective of {agent}, how does the orientation of {obj1} change?` |
| `abs_dis` | `Between {t2}s and {t_end}s, from the perspective of {agent} at {t1}s, how does the distance between {obj1} and {obj2} change?` |
| `abs_dir` | `Between {t2}s and {t_end}s, from the perspective of {agent} at {t1}s, how does the direction of {obj1} to {obj2} change?` |
| `abs_ori` | `Between {t2}s and {t_end}s, from the perspective of {agent} at {t1}s, how does the orientation of {obj1} change?` |
| `rel_spd` | `Between {t2}s and {t_end}s, following the perspective of {agent}, how does the speed of {obj1} change?` |
| `abs_spd` | `Between {t2}s and {t_end}s, from the perspective of {agent} at {t1}s, how does the speed of {obj1} change?` |
| `rel_spd_comp` | `Between {t2}s and {t_end}s, following the perspective of {agent}, compare the speed between {obj1} and {obj2}.` |
| `abs_spd_comp` | `Between {t2}s and {t_end}s, from the perspective of {agent} at {t1}s, compare the speed between {obj1} and {obj2}.` |
| `rel_dir_pred` | `Following the perspective of {agent}, predict the moving direction of {obj1}` |
| `abs_dir_pred` | `From the perspective of {agent} at {t1}s, predict the moving direction of {obj1}` |

### `rel_*` vs `abs_*`
- `rel_*`: 기준 시점(perspective)을 매 순간 갱신("following the perspective of") — 고정된 참조 시각 없음.
- `abs_*`: 기준 시점을 `{t1}s`로 고정("from the perspective of ... at {t1}s") — 이 `{t1}s`가 Case 11에서 모델이 헷갈렸던 "at 15.3s" 자리.

### agent/object 문자열 조립 규칙 (`qa_temp.py:177-179`)
```python
agent = "camera" if agent=="camera" else f"{agent_label} with bounding box coordinates [{box}]"
object_1 = "camera" if objects[0]=="camera" else f"{obj_labels[0]} with initial bounding box coordinates [{box}]"
object_2 = "camera" if objects[1]=="camera" else f"{obj_labels[1]} with initial bounding box coordinates [{box}]"
```
→ "horse with bounding box coordinates [...] at 15.3s" 같은 문구가 정확히 이 조립 규칙에서 나옴.

## 선택지(ABCD) 분석 — VLM4D와 원인이 정반대

### 선택지가 실제로 어떻게 만들어지는지

DSR-Bench 선택지 문장은 `(1) 문구. (2) 문구. (3) 문구. ...` 형태로, **정해진 짧은 문구 목록 중에서 골라 시간 구간 개수만큼 순서대로 이어붙인 것**. 예를 들어 실제 선택지 `(1) Becomes larger. (2) Keep nearly constant and then become smaller. (3) Becomes smaller.`는 "거리·속력 변화" 줄의 고정 문구 목록에서 3개를 뽑아 순서대로 이어붙인 것.

| 질문 계열 | 해당 유형 | 기본 문구(실제 데이터에 등장한 전체 목록) | 시간 구간 구분 기준 | 최종 선택지 구성 |
|---|---|---|---|---|
| 방향·자세 변화 | `abs_dir`, `rel_dir`, `abs_ori`, `rel_ori` | `Front.` `Behind.` `Left.` `Right.` `Above.` `Below.` `Front\|Left.` `Front\|Right.` `Front\|Above.` `Front\|Below.` `Behind\|Left.` `Behind\|Right.` `Behind\|Above.` `Behind\|Below.` `Left\|Above.` `Left\|Below.` `Right\|Above.` `Right\|Below.` `Front\|Left\|Above.` `Front\|Left\|Below.` `Front\|Right\|Above.` `Front\|Right\|Below.` `Behind\|Left\|Above.` `Behind\|Left\|Below.` `Behind\|Right\|Above.` `Behind\|Right\|Below.` (총 26종 — 앞/뒤, 좌/우, 위/아래 중 해당하는 축만 `\|`로 이어붙인 것) | 방향 조합 라벨이 바뀌면 새 구간 시작 | 구간별 문구를 `(1)… (2)… (3)…`으로 연결 |
| 이동 방향 예측 | `abs_dir_pred`, `rel_dir_pred` | 위와 완전히 동일한 방향 문구 26종(같은 목록) | 시간 구간으로 나누지 않음(한 시점만 판정) | 위 26종 중 1개를 그대로 사용 |
| 거리·속력 변화 | `abs_dis`, `rel_dis`, `abs_spd`, `rel_spd` | `Becomes larger.` `Becomes smaller.` `Keep nearly constant.` `Keep nearly constant and then become smaller.` `Keep nearly constant and then becomes larger.` `Keep nearly constant and then become larger.` `Become larger.` `Become smaller.` (총 8종 — 뒤 2개는 단수형 오탈자 변형으로 극소수 등장) | 증가·감소·거의 일정 등 변화 상태가 바뀌면 새 구간 시작 | 구간별 문구를 `(1)… (2)… (3)…`으로 연결 |
| 속력 비교 | `abs_spd_comp`, `rel_spd_comp` | `The former is faster.` `The latter is faster.` `Nearly the same.` `The former is always faster.` `The latter is always faster.` `Their speed is nearly the same.` (총 6종) | 어느 객체가 더 빠른지(또는 비슷한지)가 바뀌면 새 구간 시작 | 구간별 문구를 `(1)… (2)… (3)…`으로 연결 |
| 비템플릿 질문 | `non_temp` | 고정 문구 목록 없음 | 템플릿 기반 구간 구분을 적용하지 않음 | DeepSeek-R1이 bbox 좌표가 포함된 객체 이름 조합 등의 선택지를 매번 새로 생성 |

### `(1) (2) (3) ...` 개수는 어떻게 정해지나

`template.py`의 `describe_dist_runs`/`describe_dir`/`describe_spd_comp` 함수가 정함. 원리: 질의 구간을 1fps로 샘플링한 **프레임별 숫자값**(거리/방향/속력)을 처음부터 훑으면서, **"커지는 중/작아지는 중/그대로"인 상태가 이어지는 동안은 한 구간으로 묶고, 그 상태가 바뀌는 순간 새 구간을 시작**함.

예시(거리값이 초마다 이렇게 나온 경우):
```
26s: 0.13   27s: 0.15   28s: 0.17   →   0.12   →   0.09
      (계속 커지는 중)              (여기서 작아지는 쪽으로 바뀜)
```
- 26~28s는 계속 커지고 있으니 한 구간으로 묶여서 `(1) Become larger.`
- 그 다음부터 작아지기 시작하니 상태가 바뀐 것 — 여기서 새 구간이 시작돼 `(2) Become smaller.`가 붙음.

즉 **`(N)`의 개수 = "커진다/작아진다/그대로다" 상태가 바뀐 횟수 + 1**. 한 번도 안 바뀌면 `(1)`만, 세 번 바뀌면 `(1)(2)(3)(4)`가 됨. 방향(`describe_dir`)·속력비교(`describe_spd_comp`)도 같은 원리이되, "커진다/작아진다" 대신 "방향 조합 라벨이 같은지" / "누가 더 빠른지"가 바뀌는 시점마다 구간이 나뉨.

**개수를 좌우하는 요인**:
- **질의 구간이 길수록**(1fps라 프레임 수 = 초 수) 상태가 바뀔 기회가 많아져서 구간 수가 늘어남.
- **움직임이 불규칙할수록**(자주 방향을 바꾸는 영상) 구간 수가 늘어남.
- `qa_temp.py`의 안전장치: **구간 수가 15개를 넘거나, 질의 구간이 4프레임(=4초) 미만이면 그 QA 후보는 버리고 다시 뽑음**(`if len_answer>15 or (idx-idx_2+1)<4: continue`). 그래서 실제 데이터의 `(N)`은 최대 15개까지만 나오고(위 예시들은 6~10개 수준), 3초 이하로 너무 짧은 구간은 애초에 QA로 안 만들어짐.

### type별로 정리

| type(질문 유형) | 문항 수 | 위 고정 문구 목록 중 실제로 쓰인 개수 | 최종 선택지 문장이 서로 다른 정도(고유값/전체) | 왜 이렇게 나오는지 |
|---|---:|---:|---|---|
| `abs_dir_pred` | 117 | 26 | **26 / 468** | 시간 구간 없이 한 시점만 판정하는 질문이라 문구를 이어붙이지 않고 26개 중 1개만 그대로 씀 → 최종 문장도 26가지뿐 |
| `rel_dir_pred` | 167 | 26 | **26 / 668** | 동일 |
| `abs_dir` | 65 | 26 | 224 / 260 | 26개 방향 문구를 시간 구간이 바뀔 때마다 `(1)...(2)...(3)...`로 이어붙여서 260개 중 224종으로 다양해짐 |
| `rel_dir` | 88 | 26 | 299 / 352 | 동일 |
| `abs_ori` | 82 | 26 | 270 / 328 | 동일 |
| `rel_ori` | 80 | 26 | 301 / 320 | 동일 |
| `abs_dis` | 85 | 5 | 127 / 340 | 거리 문구 5개를 이어붙여서 다양해짐 |
| `rel_dis` | 112 | 7 | 177 / 448 | 동일 계열(오탈자 변형 포함 7종) |
| `abs_spd` | 84 | 8 | 162 / 336 | 동일 계열 |
| `rel_spd` | 98 | 7 | 190 / 392 | 동일 계열 |
| `abs_spd_comp` | 93 | 6 | 178 / 372 | 속력비교 문구 6개를 이어붙여서 다양해짐 |
| `rel_spd_comp` | 140 | 6 | 232 / 560 | 동일 계열 |
| `non_temp` | 239 | 고정 목록 없음(937종 전부 제각각) | **937 / 956** | 애초에 정해진 문구가 없고 DeepSeek-R1이 매번 새로 씀 |

**결론**: `*_dir_pred`(예측형)만 진짜로 26개 중 하나를 그대로 쓰는 순수 객관식이고, 나머지 방향/거리/속력 계열은 위에 나열한 5~26개짜리 짧은 고정 문구 목록에서 몇 개를 뽑아 시간 구간 개수만큼 `(1)...(2)...(3)...`으로 이어붙인 것. `non_temp`만 고정 문구 없이 DeepSeek-R1이 매번 새로 씀 — 이게 VLM4D와 같은 성격의 유일한 예외.

### type별 실제 예시 (질문 + A/B/C/D 원문, 정답 굵게)

`benchmark.parquet`에서 type별 첫 번째 행을 그대로 가져온 실제 데이터. 괄호 안 `(N)`은 구간을 여러 세그먼트로 쪼갠 순번(예: "26s~27s는 이랬다가, 그 다음엔 이랬다가...").

**`abs_dir_pred`** — Q: *From the perspective of camera at 0.0s, predict the moving direction of camera*
- A. Behind\|Left\|Below.
- **B. Left. (정답)**
- C. Left\|Below.
- D. Behind\|Left\|Above.

**`rel_dir_pred`** — Q: *Following the perspective of camera, predict the moving direction of horse with final bounding box coordinates [325,251,353,317]*
- A. Behind\|Right\|Below.
- B. Left\|Above.
- **C. Behind. (정답)**
- D. Behind\|Above.

**`abs_dir`** — Q: *Between 12.0s and 27.0s, from the perspective of camera at 27.0s, how does the direction of elephant [...] to elephant [...] change?*
- **A. (1) Front\|Right. (2) Behind\|Right. (3) Front\|Right. (4) Front. (5) Front\|Right. (6) Behind\|Right. (7) Front\|Right. (8) Front. (9) Front\|Right. (정답)**
- B. (1) Front\|Above. (2) Behind\|Right\|Above. (3) Below. ... (총 9세그먼트)
- C. (1) Front\|Right\|Above. (2) Behind\|Right. (3) Behind\|Below. ... (총 6세그먼트)
- D. (1) Front\|Left\|Above. (2) Behind\|Left\|Above. (3) Right\|Below. ... (총 10세그먼트)

**`rel_dir`** — Q: *Between 10.0s and 19.0s, following the perspective of camera, how does the direction of camera to guardrail [...] change?*
- A. (1) Front\|Left\|Above. (2) Left\|Below. (3) Front. (4) Behind\|Right\|Below.
- **B. (1) Behind\|Right. (정답)**
- C. (1) Behind\|Right\|Above. (2) Right\|Below. (3) Front.
- D. (1) Front\|Right\|Above. (2) Behind\|Left\|Above. (3) Left\|Above.

**`abs_ori`** — Q: *Between 18.0s and 38.0s, from the perspective of camera at 18.0s, how does the orientation of camera change?*
- A. (1) Behind\|Right. (2) Left\|Below. (3) Behind\|Left.
- B. (1) Left\|Above. (2) Front\|Right\|Above. (3) Front\|Left. (4) Above. (5) Front\|Left.
- **C. (1) Front. (2) Front\|Left. (3) Front. (4) Front\|Left. (5) Front. (정답)**
- D. (1) Front\|Left. (2) Behind\|Left\|Below.

**`rel_ori`** — Q: *Between 3.8s and 8.6s, following the perspective of rower [...], how does the orientation of camera change?*
- A. (1) Right\|Above. (2) Front\|Left\|Above.
- B. (1) Left\|Below. (2) Behind\|Left\|Above.
- **C. (1) Below. (2) Behind\|Below. (3) Below. (정답)**
- D. (1) Left\|Below. (2) Behind\|Right\|Below. (3) Front\|Right\|Below. (4) Behind\|Right. (5) Front\|Below.

**`abs_dis`** — Q: *Between 1.0s and 4.0s, from the perspective of camera at 20.0s, how does the distance between car [...] and camera change?*
- **A. (1) Becomes smaller. (2) Keep nearly constant. (정답)**
- B. (1) Keep nearly constant.
- C. (1) Becomes smaller. (2) Becomes larger.
- D. (1) Becomes larger.

**`rel_dis`** — Q: *Between 7.0s and 25.0s, following the perspective of child [...], how does the distance between child [...] and child [...] change?*
- A. (1) Becomes smaller. (2) Becomes larger. (3) Keep nearly constant and then become smaller. ... (총 8세그먼트)
- B. (1) Becomes smaller. (2) Becomes larger. (3) Becomes smaller. (4) Becomes larger. (5) Becomes smaller.
- C. (1) Becomes smaller. (2) Becomes larger. (3) Becomes smaller. (4) Becomes larger. (5) Keep nearly constant and then become smaller.
- **D. (1) Becomes larger. (2) Keep nearly constant and then become smaller. (3) Becomes smaller. ... (총 8세그먼트, 정답)**

**`abs_spd`** — Q: *Between 22.0s and 31.0s, from the perspective of camera at 6.0s, how does the speed of camera change?*
- **A. (1) Keep nearly constant. (정답)**
- B. (1) Becomes smaller. (2) Becomes larger. (3) Becomes smaller.
- C. (1) Becomes smaller. (2) Becomes larger. (3) Becomes smaller. (4) Becomes larger.
- D. (1) Becomes smaller.

**`rel_spd`** — Q: *Between 6.0s and 16.0s, following the perspective of camera, how does the speed of guardrail [...] change?*
- A. (1) Becomes smaller. (2) Keep nearly constant and then become smaller.
- B. (1) Becomes smaller. (2) Becomes smaller. (3) Keep nearly constant and then become smaller.
- C. (1) Becomes smaller.
- **D. (1) Keep nearly constant and then becomes larger. (2) Becomes larger. (3) Keep nearly constant and then become smaller. (4) Keep nearly constant and then become smaller. (5) Keep nearly constant. (정답)**

**`abs_spd_comp`** — Q: *Between 15.0s and 43.0s, from the perspective of woman [...] at 64.0s, compare the speed between camera and dog [...]*
- A. (1) Nearly the same. (2) The former is faster. (3) The latter is faster. ... (총 7세그먼트)
- B. (1) The latter is faster. (2) The former is faster. (3) The latter is faster. ... (총 9세그먼트)
- **C. (1) Nearly the same. (2) The latter is faster. (3) Nearly the same. (4) The latter is faster. ... (총 8세그먼트, 정답)**
- D. (1) The former is faster. (2) Nearly the same. (3) The latter is faster. ... (총 10세그먼트)

**`rel_spd_comp`** — Q: *Between 3.0s and 7.0s, following the perspective of camera, compare the speed between sign [...] and tree [...]*
- A. (1) The latter is faster. (2) The former is faster.
- B. (1) The former is faster.
- **C. (1) The former is faster. (2) The latter is faster. (정답)**
- D. (1) The latter is faster. (2) Nearly the same.

**`non_temp`** — Q: *Following the perspective of camera, between 14.0s and 16.0s, considering the changing 3d positions over time, which pair of objects shows one moving generally towards the camera while the other moves generally away from it?*
- **A. person with initial bounding box coordinates [399,141,441,203] and atv with initial bounding box coordinates [389,167,460,230] (정답)**
- B. atv [...] and traffic_sign [...]
- C. atv [...] and atv [...]
- D. traffic_sign [...] and atv [...]

→ `non_temp`만 선택지 자체가 "객체 조합"이라는 완전히 다른 형식(문장이 아니라 bbox 딸린 객체쌍)이라는 것도 이번에 확인됨 — 다른 12종은 전부 `describe_*` 문구 조합인 것과 대조적.

## 한계/비판 — 사람이 "정답의 의도대로" 풀 수 없는 구조

템플릿 기반 QA의 정답·구간이 만들어지는 방식을 보면, 이 벤치마크가 요구하는 능력이 "영상을 보고 상식적으로 판단하는 것"이 아니라 **"영상 속 3D 기하 수치를 암묵적으로 정확히 계산해내는 것"**에 가깝다는 문제가 있음.

1. **임계값(epsilon=20%) 자체가 영상에서 안 보임**: `Becomes larger`와 `Keep nearly constant`를 가르는 기준이 프레임 간 거리 비율이 ±20% 넘느냐인데, 사람은 영상만 보고 "18%야 22%야"를 구분할 수 없음. 카메라-객체 거리가 15% 멀어졌는지 25% 멀어졌는지는 3D 좌표 숫자 없인 판단 불가능.
2. **정답 자체가 사람이 접근 못 하는 정보에서 나옴**: "정답"의 근거가 되는 3D 좌표는 π³가 monocular 영상에서 **추정**한 포인트클라우드·카메라 pose임(센서로 잰 진짜 ground truth 아님, 자체 추정 오차 있음). 사람은 2D 영상만 보는데 정답은 모델이 뽑아낸 3D 수치 기준으로 만들어짐.
3. **구간(N)까지 정확한 순서로 맞혀야 함**: 최대 15개 세그먼트까지, 몇 초에 상태가 바뀌었는지 순서까지 일치해야 정답 선택지와 맞아떨어짐(오답 3개도 같은 방식으로 만들어져 얼추 비슷하게 생김). 영상을 보고 "대략 이런 느낌"으로는 못 맞히고 프레임 단위 수치 계산이 필요한 문제.
4. **방향 조합도 동일한 문제**: `Front|Left|Above.`처럼 3축(전후/좌우/상하)을 동시에 20~30% 임계값으로 판정한 조합인데, 사람 눈으로 그 정도 정밀도까지 구분하는 건 불가능.

**연결되는 관찰**: 이게 바로 [[dsr-bench-facts]]에서 본 "Video-only가 오히려 정황상 판단(경마 중계는 카메라가 대상과 일정 거리 유지 등)으로 맞히고, +TG/+BEV로 정확한 숫자를 줘도 모델이 그걸 잘못 다뤄서 틀리는" 현상의 근본 원인. 질문 문구는 자연어 QA처럼 생겼어도 실제로 요구하는 건 정밀 수치 계산이라, 사람이든 VLM이든 "영상을 보고 이해"하는 방식으로는 원리적으로 풀기 어려운 구조.

## 관련 파일
- `external/legacy_reference` — **QA 템플릿 실물이 들어있는 파일.** 12종 템플릿 문자열(`template` dict, 4~16번째 줄)과 정답 범주화 함수(`describe_dist_runs`/`describe_dir`/`describe_spd_comp`)가 이 파일 하나에 다 있음. 로컬에 동일 내용 사본이 하나 더 있음: `external/legacy_reference`(diff 결과 완전 동일).
- `external/legacy_reference` — 템플릿 QA 생성 메인 스크립트 (1,283줄)
- `external/legacy_reference` — 비템플릿 QA 생성 (DeepSeek-R1 사용)
- `external/legacy_reference` — 좌표 변환/거리 계산 순수 수학 함수
- `external/legacy_reference` — 공식 파이프라인 설명("template-based and non-template-based")
- `external/legacy_reference` — DSR-Train/DSR-Bench 관계 설명
- [[dsr-bench-facts]] — 기존 DSR-Bench 데이터셋 규모/카테고리 사실 정리
