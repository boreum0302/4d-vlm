# User execution constraints

- Never execute GPU workloads, GPU smoke tests, or the GPU entry points in this directory. The user explicitly reserves all GPU execution for themselves. Do not infer permission from a request to prepare, fix, or document GPU commands.
- CPU preparation/testing is allowed. Keep CUDA_VISIBLE_DEVICES empty for agent-run environment checks. Do not run run_pi3_b200.sh or gpu/extract_pi3.py yourself.
- Whenever documenting a GPU command, include peak VRAM and ETA with workload assumptions. Clearly distinguish estimates from measurements; never invent measured values. After the user runs a job, use its logs to update estimates.
- RUN.md is the authoritative execution note. Keep it current and concise.
