# CPU QA 입력 계약

`scripts/qa_cpu.py`는 다음 구조의 UTF-8 JSON을 받는다. 모델이나 GPU를 호출하지 않는다. 실제 값이 있는 파일만 넣으며, 형식 예시는 `tests/fixtures/synthetic_geometry.json`에 있다. 합성 예시는 실제 영상 데이터로 사용하면 안 된다.

| 필드 | 의미 |
| --- | --- |
| `video_id` | 원본 영상 ID |
| `source_video_sha256` | 원본 영상 파일 SHA-256 |
| `coordinate_system` | 정확히 `opencv_camera_to_world` |
| `is_metric` | `false`; DSR 원본의 상대 스케일 규칙 사용 |
| `timestamps_s` | 길이 N, 원본 영상 시작 기준 초, 유한하고 엄격히 증가 |
| `source_frame_indices` | 길이 N, 원본 프레임 인덱스, 엄격히 증가 |
| `image_size_wh` | 원본 bbox 좌표계의 `[width,height]` |
| `sampling_policy` | 예: `uniform32` 또는 `1fps` |
| `camera_to_world` | N×4×4, OpenCV 카메라 좌표를 공통 world 좌표로 보내는 행렬 |
| `tracks` | 객체별 아래 구조의 배열 |

객체 track:

```text
track_id: 고유 문자열; 'camera' 예약어 사용 금지
label: 비어 있지 않은 객체 설명
centers_world: N×3, 같은 world 좌표계에서의 중심
bboxes_xyxy: N×4, 원본 영상 해상도 기준 픽셀 bbox
valid: N개 boolean; mask/track 품질이 유효할 때만 true
```

N은 최소 4다. 일부 frame에서 유효하지 않은 객체는 `valid=false`로 표시할 수 있지만, QA 구간 안에서는 모든 대상 객체가 연속 유효해야 한다. padding/resize된 이미지에서 나온 bbox는 반드시 원본 해상도 좌표로 환산한다. 해당 구간의 crop-relative timestamp를 원본 시간으로 잘못 저장하면 안 된다.

각 geometry 파일은 하나의 일관된 재구성 좌표계만 담는다. 다른 window에서 독립적으로 나온 point cloud나 camera pose를 정렬 없이 연결하지 않는다. pose 회전의 직교성, det=+1, 동차행렬의 마지막 행을 검사한다.

DSR의 상대 스케일 수치 상수(0.1)는 그대로 사용하므로 임의 단위 정규화/백엔드 변경은 답을 바꿀 수 있다. 다른 geometry backend의 결과는 별도 검증 없이 동등한 것으로 취급하지 않는다.

## 검증 범위

입력 shape·유한값·시간 순서·bbox·pose·track 연속성 검증 → 좌표 변환 → attribute 계산 → DSR 범주화 → 오답 중복 검사 → 저장된 evidence에서 정답 재계산.

이 검증은 입력 3D가 실제 장면과 일치하는지 판정하지 못한다. mask overlay·track ID·기하 재구성의 시각적 검수는 별도로 필요하다.

`manifests/window_jobs.jsonl`은 프레임 구간을 묶은 작업 명세일 뿐 실행 큐가 아니다. `execution_enabled=false`, `status=awaiting_verified_3d_geometry`다. 장면 전환 및 객체 연속성 검증 전에는 그대로 생성 구간으로 확정하지 않는다.
