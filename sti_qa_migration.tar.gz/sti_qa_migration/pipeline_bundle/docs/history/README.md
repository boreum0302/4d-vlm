# STI → DSR QA: CPU 준비 결과

**에이전트는 CPU 작업만 실행한다. GPU 실행은 사용자가 직접 한다.**
아래는 CPU 준비 단계의 기록이다. 최신 구간별 π³ 실행 절차, B200 사용자 실행 스크립트, 예상 peak VRAM·ETA는 [RUN.md](RUN.md)를 따른다. 사용자가 π³ 363구간 실행을 완료했다. Qwen3.5 직접 객체 추출은 준비 완료이며 GPU 실행 대기다.

- 전체 영상 369개: SHA-256, ffprobe 메타데이터, CPU 전체 디코딩 검사 완료.
- Source별 10개씩 pilot 30개, 그 안에 Source별 2개씩 smoke 6개 고정.
- 원본 해상도 프레임: uniform32 960장 + 1 FPS 929장 = 1,889장.
- 30개 contact sheet, 로컬 검토 페이지, 원본 영상 링크 준비.
- 30개 영상의 임시 캡션/객체 후보/위험 요소 기록. 샘플 프레임에 대한 assistant 검토이며 사람의 영상 전수 검수는 아니다.
- camera viewpoint의 거리·방향·속력·속력 비교 8종 CPU 생성기 및 검증기 구현.
- 기존 합성 궤적 21개, π³ 입력·출력 계약 10개, DeepSeek 출력 parser 4개, Qwen 객체 추출 계약 9개로 총 CPU 테스트 44개 통과. **실제 STI QA는 아직 0개**다.

## 결과 보기

- [상태 보고서](reports/CPU_PREPARATION.md)
- [영상 검토 페이지](review/index.html): JPEG 30개와 원본 mp4 심볼릭 링크. 서버 환경에서는 폴더를 로컬로 옮기거나 적절한 정적 파일 서비스로 열면 된다. mp4 링크 대상은 원본 공유 파일시스템에 있다.
- [고정된 30개 샘플](manifests/sampled_videos.jsonl)
- [6개 smoke 샘플](manifests/smoke_videos.jsonl)
- [임시 캡션](metadata/captions.jsonl), [임시 객체 목록](metadata/agent_objects.jsonl)
- [검증 결과](reports/cpu_summary.json), [테스트 로그](reports/cpu_tests.txt)

## CPU로 재실행

작업 폴더에서 실행한다. 준비에 사용한 Python은 `/usr/bin/python`이며 numpy, pandas, pyarrow, Pillow 및 ffmpeg/ffprobe를 사용한다.

```bash
bash run_cpu.sh check    # 기존 파일 검증 및 보고서 재생성
bash run_cpu.sh test     # CPU 합성 궤적/샘플링/검증 테스트
bash run_cpu.sh prepare  # 전체 inventory부터 다시 수행
```

`run_cpu.sh`는 CUDA 노출을 차단하며, 자체 Python 코드에는 torch/transformers 등의 모델 라이브러리 import가 없다. ffmpeg는 하드웨어 가속 없이 CPU 디코딩을 수행한다. 설정값은 [configs/cpu.json](configs/cpu.json)에 기록했다.

## CPU QA 생성기 사용

검증된 3D geometry JSON을 입력받는 별도 단계다. geometry 모델을 호출하거나 없는 데이터를 만들어서 채우지 않는다. 입력 계약은 [GEOMETRY_CONTRACT.md](GEOMETRY_CONTRACT.md)를 따른다.

합성 데이터로만 실행하는 예:

```bash
CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 python scripts/qa_cpu.py \
  --geometry tests/fixtures/synthetic_geometry.json \
  --output tests/fixtures/synthetic_cli_qa.jsonl
```

실제 geometry가 확보되면 같은 CLI로 입력만 교체할 수 있다. 현재 실제 geometry는 생성하지 않았다. 성공 출력도 `review_status=pending`이며 자동으로 accepted QA가 되지 않는다.

## DSR 원본과의 차이

- `vendor/dsr_template.py`는 원본을 그대로 복사했다. 원본 라이선스와 파일 해시는 `vendor/DSR_LICENSE.txt`, `reports/source_provenance.json`에 있다.
- 생성기는 원본 거대 추론 스크립트와 분리한 NumPy CPU 구현이다. 원본 실행을 완전히 재현했다고 주장하지 않는다.
- OpenCV camera-to-world pose를 받아 DSR 축 `[front,left,up]=[z,-x,-y]`로 변환한다.
- 방향은 `object_1 - object_2`이며 질문에는 `relative to`로 명확히 쓴다.
- 속력은 실제 Δt로 나눈다. relative speed는 움직이는 관찰 좌표계에서의 좌표 변화율이다.
- 원본의 정성적 분류 함수를 사용하고, 0 분모 처리·유효성 검증·시도 횟수 제한을 추가했다.
- 질문과 bbox 시각은 원본 PTS 기반이며 0.001초까지 표시한다. 프레임 map에는 반올림 전 값을 저장한다.
- geometry 품질을 보장하지 않는 1% attribute perturbation 검사로 임계값 주변의 불안정한 답을 선별한다. 이 검사는 모델의 3D 오차에 대한 통계적 보증이 아니다.
- 오답은 동일 분류기를 사용해 생성하되 200회 이내에 4개 고유 선택지를 구성하지 못하면 실패 처리한다.
- 관찰자는 camera만 지원한다. agent viewpoint, orientation, prediction, non-template은 활성화하지 않았다.

## 아직 필요한 것

실제 영상의 mask/track, camera pose, 3D centers와 기하 품질 검증이 필요하다. 임시 객체 목록은 grounding 결과가 아니며, agent 후보가 있다고 실제 이동하거나 방향이 안정적으로 추정된다는 뜻도 아니다. `dynamic_videos.json`을 임의로 확정하지 않았다.

STI 원본 QA/Answer/Answer Detail은 캡션·객체 후보·생성기 입력에 사용하지 않았다. Inventory의 기존 QA ID/개수는 출처 추적용이다.
