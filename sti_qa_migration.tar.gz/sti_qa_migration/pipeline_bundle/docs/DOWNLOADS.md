# 새 서버에서 받을 코드·데이터·체크포인트

이 문서는 링크만 제공한다. 이사 묶음에는 모델·체크포인트·외부 저장소 사본을 포함하지 않았다. 외부 코드는 링크와 설치 방법만 제공한다. 각 항목을 원하는 위치에 받은 뒤 `paths.json`에 지정한다.

| 항목 | 링크 | paths.json 설정 / 필요 내용 |
| --- | --- | --- |
| STI-Bench | [GitHub](https://github.com/MINT-SJTU/STI-Bench), [HF dataset](https://huggingface.co/datasets/MINT-SJTU/STI-Bench) | `sti_bench`: qa.parquet, data/test parquet, video/ |
| DSR Suite | [GitHub](https://github.com/TencentARC/DSR_Suite) | `dsr_code`: data/; 공식 QA 함수는 이미 vendor/official_sources에 보존 |
| Pi3 코드 | [GitHub](https://github.com/yyfz/Pi3) | `pi3_code`: pi3/를 포함한 루트. Pi3X 대신 기존 Pi3 사용 |
| Pi3 weights | [HF](https://huggingface.co/yyfz233/Pi3/tree/ae722e7039287d0c8fde9f11f197f804f44b510c) | `pi3_model`: config.json 및 model.safetensors 디렉터리 |
| Qwen3.5-9B | [HF](https://huggingface.co/Qwen/Qwen3.5-9B) | `qwen_model`: config, processor/tokenizer, 모든 weight shard |
| GroundingDINO tiny | [HF](https://huggingface.co/IDEA-Research/grounding-dino-tiny/tree/a2bb814dd30d776dcf7e30523b00659f4f141c71) | `dino_model`: 모델 전체 디렉터리 |
| SAM2 코드 | [GitHub](https://github.com/facebookresearch/sam2) | `sam_code`: sam2/를 포함한 루트; configs/sam2.1/sam2.1_hiera_l.yaml 필요 |
| SAM2.1 Hiera large | [HF](https://huggingface.co/facebook/sam2.1-hiera-large/tree/665f8e2ad61cf5f53d65644ff27c8ee525124610), [pt 파일](https://huggingface.co/facebook/sam2.1-hiera-large/resolve/665f8e2ad61cf5f53d65644ff27c8ee525124610/sam2.1_hiera_large.pt) | `sam_checkpoint`: pt 파일 |
| Orient Anything 코드 | [GitHub](https://github.com/SpatialVision/Orient-Anything), [vision_tower.py](https://github.com/SpatialVision/Orient-Anything/blob/main/vision_tower.py) | `orient_model_code`: vision_tower.py; 같은 저장소의 paths.py도 필요 |
| Orient Anything weights | [HF](https://huggingface.co/Viglong/Orient-Anything/tree/ecfa089828d9fab521d47133bedbdbfdef151cd4), [pt 파일](https://huggingface.co/Viglong/Orient-Anything/resolve/ecfa089828d9fab521d47133bedbdbfdef151cd4/croplargeEX2/dino_weight.pt) | `orient_checkpoint`: croplargeEX2/dino_weight.pt |
| DINOv2 large backbone | [HF](https://huggingface.co/facebook/dinov2-large/tree/47b73eefe95e8d44ec3623f8890bd894b6ea2d6c) | `orient_backbone`: config, preprocessor_config, model.safetensors |
| PyTorch | [설치 안내](https://pytorch.org/get-started/locally/) | 새 서버 CUDA에 맞는 torch/torchvision 설치 |

기존 기록의 STI code HEAD는 `8863104d81547abea1b5ccd02fef9cab04b046ef`, DSR HEAD는 `ae81203a672613bc746fce8299b2be3b9133ede1`이다. Pi3와 Orient 모델 revision은 위 링크에 고정했다. Qwen weight revision과 실제 사용한 Pi3/SAM2/Orient 외부 코드 commit은 기존 기록에서 확정되지 않아 임의로 기재하지 않았다.

Orient Anything 어댑터는 `DINOv2_MLP('large',1024,722,True,False,False,cache_dir=...)`와 722-logit angle 출력 규약을 사용한다. 다운로드한 코드에서 이 생성자와 weight shape이 맞는지 확인한다. 기존 실행의 vision_tower.py는 별도 third_party 사본이었으므로 공개 저장소 최신 코드와 동일하다고 보장하지 않는다. 모델 로드 시 로컬 DINOv2 경로를 지정하고 체크포인트를 strict=True로 로드한다.

공식 QA 생성 함수와 템플릿의 당시 사본은 `vendor/official_sources/`에 포함했다. 원본 생성 소스 hash:

| 파일 | SHA-256 |
| --- | --- |
| qa_temp.py | 14ae1643956cdd1cd3547e380ae268b8a76851d7dad77a40ff4cb9f2e204b591 |
| qa_utils.py | 1a10d4ab12e84ad86ff468a32551a0d133478325d372529d2420457fc7d0ceb4 |
| template.py | f349fac330a58a0ed6952f8ffb0609b28299128178f8a5a93f50fba9f9e201c2 |

HF CLI 설치 후 새 서버에서 받는 명령 형식은 `hf download REPO --revision REVISION --local-dir checkpoints/NAME`이며, dataset은 `--repo-type dataset`을 추가한다. 외부 코드는 각 GitHub의 설치 안내를 따른다. 코드가 `HF_HUB_OFFLINE=1`로 실행되므로 실행 전에 파일을 모두 받아 둔다.
