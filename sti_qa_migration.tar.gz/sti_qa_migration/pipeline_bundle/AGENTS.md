# Execution constraints

- Agents must never execute GPU workloads, GPU smoke tests, run_pipeline.sh, run_*_b200.sh, or gpu/*.py entrypoints. GPU execution is reserved for the user.
- CPU preparation and testing are allowed with CUDA_VISIBLE_DEVICES empty.
- GPU command documentation must include VRAM and ETA with workload assumptions, distinguishing original measurements from estimates.
- RUN.md and README.md describe the current portable execution procedure. docs/history contains historical notes.
