import json
from pathlib import Path
import sys
import tempfile
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from prepare_pi3_segments import sample_intervals
from pi3_contract import completion_matches, file_hash, validate_output, verify_job


class Pi3Preparation(unittest.TestCase):
    def test_reproducible_intervals(self):
        a=sample_intervals(45,'video',260920,8,8,32)
        self.assertEqual(a,sample_intervals(45,'video',260920,8,8,32))
        self.assertEqual(len(set(a)),8)
        for start,end in a:
            self.assertTrue(0<=start<end<45)
            self.assertTrue(8<=end-start+1<=32)

    def test_shortest_video(self):
        self.assertEqual(sample_intervals(8,'v',0,1,8,32),[(0,7)])

    def test_invalid_requests(self):
        for args in [(3,'v',0,1,8,32),(8,'v',0,2,8,32),(30,'v',0,1,2,32)]:
            with self.assertRaises(ValueError):sample_intervals(*args)

    def output_fixture(self):
        return (np.ones((4,2,3,3)),np.repeat(np.eye(4)[None],4,axis=0),np.zeros((4,2,3)),np.ones((4,2,3),dtype=bool))

    def test_numeric_output(self):
        d=validate_output(*self.output_fixture())
        self.assertEqual(d['frames'],4)
        self.assertEqual(d['image_size_wh'],[3,2])

    def test_nan_rejected(self):
        x=self.output_fixture();x[0][0,0,0,0]=np.nan
        with self.assertRaises(ValueError):validate_output(*x)

    def test_empty_valid_frame_rejected(self):
        x=self.output_fixture();x[3][2]=False
        with self.assertRaises(ValueError):validate_output(*x)

    def test_pose_reflection_rejected(self):
        x=self.output_fixture();x[1][0,0,0]=-1
        with self.assertRaises(ValueError):validate_output(*x)

    def test_resume_integrity(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td);data=out/'data';data.write_bytes(b'valid')
            self.assertFalse(completion_matches(out,'sig'))
            (out/'complete.json').write_text(json.dumps(dict(run_signature='sig',artifact_sha256={'data':file_hash(data)})))
            self.assertTrue(completion_matches(out,'sig'))
            with self.assertRaises(ValueError):completion_matches(out,'other')
            data.write_bytes(b'tampered')
            with self.assertRaises(ValueError):completion_matches(out,'sig')

    def test_only_interval_frames(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td);frames=[]
            for i in range(4):
                f=out/f'{i:03d}.jpg';f.write_bytes(b'fake-for-hash-test')
                frames.append(dict(path=str(f),sha256=file_hash(f),timestamp_s=float(i+10),segment_frame_index=i))
            job=dict(frames=frames,frame_directory=str(out),query_start_s=10.,query_end_s=13.)
            verify_job(job)
            (out/'999.jpg').write_bytes(b'extra')
            with self.assertRaises(ValueError):verify_job(job)

    def test_gpu_entrypoint_compiles_without_execution(self):
        path=ROOT/'gpu/extract_pi3.py'
        compile(path.read_text(),str(path),'exec')


if __name__=='__main__':unittest.main()
