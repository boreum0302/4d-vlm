import ast,sys,unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from orient_contract import crop_object,decode_logits,dsr_camera_to_agent

class OrientContract(unittest.TestCase):
    def test_decode_722_bins_including_rotation(self):
        x=np.full(722,-10.);x[359]=4;x[360]=4;x[719]=4;x[720:]=[2,0]
        r=decode_logits(x)
        self.assertEqual((r['azimuth_deg'],r['polar_deg'],r['rotation_deg']),(359,-90,89))
        self.assertAlmostEqual(r['confidence'],1/(1+np.exp(-2)))
    def test_bad_logits_fail(self):
        for x in [np.zeros(902),np.full(722,np.nan)]:
            with self.assertRaises(ValueError):decode_logits(x)
    def test_single_pixel_crop_not_filtered(self):
        rgb=np.zeros((20,20,3),np.uint8);mask=np.zeros((20,20),bool);mask[0,0]=True
        image,box=crop_object(rgb,mask)
        self.assertEqual(box,[0,0,11,11]);a=np.asarray(image)
        self.assertTrue((a[0,0]==0).all());self.assertTrue((a[1,1]==255).all())
    def test_empty_mask(self):self.assertIsNone(crop_object(np.zeros((2,2,3),np.uint8),np.zeros((2,2),bool)))
    def test_dsr_rotation_and_inverse(self):
        source=Path('vendor/official_sources/qa_utils.py').read_text()
        names={'rotation_matrix_x','rotation_matrix_y','rotation_matrix_z','rotate_point_cloud','agent_camera_coord_trans'}
        nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in names]
        namespace={'np':np};exec(compile(ast.Module(body=nodes,type_ignores=[]),'dsr_rotation','exec'),namespace)
        for az,pol,rot in [(0,0,0),(90,-21,0),(359,89,-90),(45,30,20)]:
            r=dsr_camera_to_agent(az,pol,rot);points=np.array([[1.,2,3],[-2,4,1]])
            actual=namespace['rotate_point_cloud'](points,pol,az,rot)
            np.testing.assert_allclose(actual,points@r.T,atol=1e-12)
            restored=namespace['agent_camera_coord_trans'](actual,pol,az,rot,np.zeros(3))
            np.testing.assert_allclose(restored,points,atol=1e-12)
            np.testing.assert_allclose(r.T@r,np.eye(3),atol=1e-12)

if __name__=='__main__':unittest.main()
