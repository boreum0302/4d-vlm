import ast,sys,unittest,json,tempfile
from unittest.mock import patch
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from generate_official_dsr_cpu import UP,load_functions,Cache
from orient_contract import read_jsonl
class OfficialAdapterTests(unittest.TestCase):
 def test_generator_code_unchanged(self):
  ns={};load_functions(UP/'qa_temp.py',['prob_cal','generate_one_video'],ns)
  tree=ast.parse((UP/'qa_temp.py').read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='generate_one_video');ref={};exec(compile(ast.Module(body=[f],type_ignores=[]),str(UP/'qa_temp.py'),'exec'),ref)
  self.assertEqual(ns['generate_one_video'].__code__.co_code,ref['generate_one_video'].__code__.co_code)
  self.assertEqual(ns['generate_one_video'].__code__.co_consts,ref['generate_one_video'].__code__.co_consts)
 def test_cached_mask_native_shape(self):
  import generate_official_dsr_cpu as adapter
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);sub=Path('fixture')/'segment';sam=root/'artifacts/grounded_sam2'/sub;sam.mkdir(parents=True)
   ori=root/'artifacts/orient_anything'/sub;ori.mkdir(parents=True)
   geom=root/'geometry';geom.mkdir()
   frames=[]
   for i in range(2):
    path=sam/f'{i:03d}.npz';mask=np.zeros((1,6,8),dtype=bool);mask[:,1:5,2:6]=True
    np.savez_compressed(path,track_ids=np.array([1]),masks=mask)
    frames.append({'mask_path':str(path)})
   (sam/'tracks.json').write_text(json.dumps({'image_size_wh':[8,6],'frames':frames}))
   (ori/'orientations.json').write_text(json.dumps({'tracks':[]}))
   np.savez_compressed(geom/'scene_geometry.npz',local_points=np.ones((2,3,4,3)),valid_mask=np.ones((2,3,4),dtype=bool),camera_to_world=np.tile(np.eye(4),(2,1,1)))
   job={'video_id':'fixture','segment_id':'segment','frames':[{},{}],'output_directory':str(geom)}
   with patch.object(adapter,'ROOT',root):c=Cache(job)
   w,h=c.sam['image_size_wh'];self.assertTrue(all(m.shape==(h,w) for m in c.frame(0).values()))
   points,masks,poses=c.geometry();self.assertEqual(points.shape,(c.n,3,h,w));self.assertEqual(masks.shape,(c.n,h,w))
   self.assertEqual(int(next(iter(c.frame(0).values())).sum()),16)
 def test_no_gpu_imports(self):
  self.assertNotIn('torch',sys.modules);self.assertNotIn('transformers',sys.modules)
if __name__=='__main__':unittest.main()
