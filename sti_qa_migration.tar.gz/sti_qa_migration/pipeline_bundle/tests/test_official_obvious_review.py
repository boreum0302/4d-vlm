import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from review_official_obvious_cpu import option_key,parse_question
class BasicReviewTests(unittest.TestCase):
 def test_single_state_comparison_equivalence(self):
  self.assertEqual(option_key('(1) The former is always faster.'),option_key('(1) The former is faster.'))
  self.assertEqual(option_key('The latter is always faster.'),option_key('(1) The latter is faster.'))
 def test_different_meaning_not_collapsed(self):
  self.assertNotEqual(option_key('(1) The former is faster.'),option_key('(1) The latter is faster.'))
  self.assertNotEqual(option_key('(1) The former is faster. (2) Nearly the same.'),option_key('(1) The former is faster.'))
 def test_reference_outside_question_interval_parses(self):
  tpl='Between {:.1f}s and {:.1f}s, from the perspective of {} at {:.1f}s, how does the orientation of {} change?'
  slots=parse_question('Between 2.0s and 8.0s, from the perspective of camera at 12.0s, how does the orientation of camera change?',tpl)
  self.assertEqual(slots,['2.0','8.0','camera','12.0','camera'])
if __name__=='__main__':unittest.main()
