"""Ensure stage 6 includes every schema-validated job, without semantic screening."""
import json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import prepare_sam2_inputs as prep

class Preparation(unittest.TestCase):
    def test_all_validated_jobs_including_quality_flags(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'manifests').mkdir()
            (root/'artifacts/qwen35_validated').mkdir(parents=True)
            jobs=[dict(job_id=str(i),source='test',frames=[{}]) for i in range(4)]
            def rows(path,data):path.write_text(''.join(json.dumps(x)+'\n' for x in data))
            rows(root/'manifests/pi3_all_s260920_k1_f8-32.jsonl',jobs)
            rows(root/'artifacts/qwen35_validated/objects_all.jsonl',jobs[:3])
            (root/'model.safetensors').touch();(root/'sam.pt').touch()
            flagged={'truncated':True,'objects':[{'label':'road','evidence_frames':[2]}]*12,
                     'review_status':'needs_visual_review'}
            with patch.object(prep,'ROOT',root),patch.object(prep,'DINO',root),patch.object(prep,'SAM',root/'sam.pt'),patch.object(prep,'verify_frames'),patch.object(prep,'qwen_objects',return_value=flagged),patch.object(sys,'argv',['prepare','--subset','all']):
                prep.main()
            output=prep.read_jsonl(root/'manifests/sam2_all.jsonl')
            self.assertEqual([j['job_id'] for j in output],['0','1','2'])
            self.assertTrue(all('screening' not in j for j in output))
            self.assertTrue(all(j['object_input']==flagged for j in output))

if __name__=='__main__':unittest.main()
