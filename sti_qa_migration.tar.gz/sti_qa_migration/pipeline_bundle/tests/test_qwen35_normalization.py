import json,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from normalize_qwen35_objects import normalize

def item(label,motion='stationary',orientation=False,frames=None):
 return dict(label=label,motion=motion,orientation_candidate=orientation,evidence_frames=frames or [0])
def run(a=None,b=None):return normalize(json.dumps(dict(agents=a or [],non_agents=b or [],truncated=False)),8)[0]

class Normalization(unittest.TestCase):
 def test_underscore_and_case(self):self.assertEqual(run(b=[item('Trash_Can')])['non_agents'][0]['label'],'trash can')
 def test_same_class_merges_evidence(self):
  x=run(b=[item('chair',frames=[0]),item('chair',frames=[3])]);self.assertEqual(x['non_agents'][0]['evidence_frames'],[0,3]);self.assertEqual(x['grounding_prompt'],'chair.')
 def test_mixed_motion_unknown(self):
  x=run(a=[item('car','moving',True),item('car','stationary',False)]);self.assertEqual(x['agents'][0]['motion'],'unknown');self.assertTrue(x['agents'][0]['orientation_candidate'])
 def test_cross_group_not_reclassified(self):
  with self.assertRaisesRegex(ValueError,'conflict'):run(a=[item('car')],b=[item('car')])
 def test_nonagent_orientation_not_changed(self):
  with self.assertRaises(ValueError):run(b=[item('person','moving',True)])
 def test_no_category_dropped(self):
  labels=['chair','table','bed','sofa','lamp','cabinet','door','book','shelf','bottle','cup','monitor','keyboard']
  self.assertEqual(run(b=[item(x) for x in labels])['category_count'],13)
 def test_truncated_json_not_completed(self):
  with self.assertRaises(ValueError):normalize('{"agents": [',8)
 def test_bad_evidence_not_hidden_by_merge(self):
  with self.assertRaises(ValueError):run(b=[item('chair'),item('chair',frames=[99])])
