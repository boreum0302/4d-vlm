import json
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from qwen35_contract import parse_objects, verify_frames, file_hash, completed, write_json

def example():
    return {'agents':[{'label':'person','motion':'stationary','orientation_candidate':True,'evidence_frames':[0]}], 'non_agents':[{'label':'ball','motion':'moving','orientation_candidate':False,'evidence_frames':[1]}], 'truncated':False}

class QwenContract(unittest.TestCase):
    def test_stationary_agent_moving_nonagent(self):
        self.assertEqual(parse_objects(json.dumps(example()),2)['grounding_prompt'],'person. ball.')
    def test_empty_scene(self):
        self.assertEqual(parse_objects(json.dumps(dict(agents=[],non_agents=[],truncated=False)),2)['grounding_prompt'],'')
    def test_cross_group_duplicate(self):
        x=example();x['non_agents'][0]['label']='person'
        with self.assertRaises(ValueError):parse_objects(json.dumps(x),2)
    def test_invalid_evidence(self):
        for ids in [[2],[-1],[],[True],[0,0]]:
            x=example();x['agents'][0]['evidence_frames']=ids
            with self.assertRaises(ValueError):parse_objects(json.dumps(x),2)
    def test_invalid_schema(self):
        for raw in ['{}','[]','not json','{"agents":[],"non_agents":[],"truncated":"false"}']:
            with self.assertRaises(ValueError):parse_objects(raw,2)
    def test_invalid_label_motion_orientation(self):
        for field,value in [('label','person. car'),('motion','camera'),('orientation_candidate',True)]:
            x=example();x['non_agents'][0][field]=value
            with self.assertRaises(ValueError):parse_objects(json.dumps(x),2)
    def test_frame_tampering(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'f.jpg';p.write_bytes(b'original')
            job={'frames':[{'path':str(p),'sha256':file_hash(p),'segment_frame_index':0,'timestamp_s':3}],'query_start_s':3,'query_end_s':3}
            verify_frames(job);p.write_bytes(b'changed')
            with self.assertRaises(ValueError):verify_frames(job)
    def test_resume_integrity(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);self.assertFalse(completed(p,'sig'))
            write_json(p/'objects.json',example())
            write_json(p/'complete.json',{'run_signature':'sig','artifact_sha256':{'objects.json':file_hash(p/'objects.json')}})
            self.assertTrue(completed(p,'sig'))
            with self.assertRaises(ValueError):completed(p,'different')
            (p/'objects.json').write_text('{}')
            with self.assertRaises(ValueError):completed(p,'sig')
    def test_gpu_source_compile_only(self):
        p=ROOT/'gpu/extract_qwen35_objects.py';compile(p.read_text(),str(p),'exec')

class QwenFenceRegression(unittest.TestCase):
    def test_json_fence(self):
        raw='```json'+chr(10)+json.dumps(example())+chr(10)+'```'+chr(10)
        self.assertEqual(parse_objects(raw,2)['grounding_prompt'],'person. ball.')
    def test_prose_outside_fence_rejected(self):
        raw='Here is output: '+chr(10)+'```json'+chr(10)+json.dumps(example())+chr(10)+'```'
        with self.assertRaises(ValueError):parse_objects(raw,2)
    def test_fenced_bad_schema_still_rejected(self):
        with self.assertRaises(ValueError):parse_objects('```json'+chr(10)+'{}'+chr(10)+'```',2)

class QwenLongEvidence(unittest.TestCase):
    def test_all_visible_frames_allowed(self):
        x=example();x['agents'][0]['evidence_frames']=list(range(8))
        self.assertEqual(parse_objects(json.dumps(x),8)['agents'][0]['evidence_frames'],list(range(8)))
