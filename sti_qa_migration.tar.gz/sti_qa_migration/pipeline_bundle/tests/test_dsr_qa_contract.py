import unittest,sys,copy
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from dsr_qa_contract import attributes,make_qa,validate_qa,CAMERA_AXES

def fixture():
 n=8;poses=np.repeat(np.eye(4)[None],n,axis=0);poses[:,0,3]=np.arange(n)
 return {'job_id':'v/s','video_id':'v','segment_id':'s','source':'synthetic','timestamps_s':list(range(n)),
 'camera_to_world':poses.tolist(),'scene_scale':1,'frame_paths':[str(i) for i in range(n)],'source_frame_indices':list(range(n)),
 'image_size_wh':[100,100],'sampling_policy':'fixed','source_video_sha256':'hash','geometry_sha256':'geo',
 'tracks':[{'track_id':'1','label':'car','centers_world':[[0,0,10]]*n,'valid':[True]*n,
 'bboxes_xyxy':[[1,1,20,20]]*n,'world_to_agent':[CAMERA_AXES.tolist()]*n,'orientation_confidence':[1]*n}]}

class Contract(unittest.TestCase):
 def test_camera_axis_and_distance(self):
  g=fixture();v=attributes(g,'abs_dir',['1','camera'],'camera');np.testing.assert_allclose(v[:,0],10);np.testing.assert_allclose(v[:,1],np.arange(8))
  np.testing.assert_allclose(attributes(g,'abs_dis',['1','camera'],'camera'),attributes(g,'rel_dis',['1','camera'],'camera'))
 def test_speed_uses_dt(self):
  g=fixture();g['timestamps_s']=[i*2 for i in range(8)]
  np.testing.assert_allclose(attributes(g,'abs_spd',['camera'],'camera'),.5)
 def test_agent_orientation(self):
  g=fixture();np.testing.assert_allclose(attributes(g,'rel_ori',['camera'],'1'),[[1,0,0]]*8)
 def test_prediction_input_holds_out_future(self):
  g=fixture();q=make_qa(g,'abs_dir_pred',['camera'],'camera');self.assertEqual(q['input_frame_paths'],g['frame_paths'][:6]);self.assertEqual(q['prediction_target_time_s'],7);validate_qa(q,g)
  q['input_frame_paths'].append('6')
  with self.assertRaises(AssertionError):validate_qa(q,g)
 def test_missing_track_and_low_confidence(self):
  g=fixture();g['tracks'][0]['valid'][3]=False
  with self.assertRaises(ValueError):attributes(g,'abs_dis',['1','camera'],'camera')
  g=fixture();g['tracks'][0]['orientation_confidence'][2]=.2
  with self.assertRaises(ValueError):attributes(g,'rel_ori',['1'],'camera')
 def test_recompute_detects_wrong_answer(self):
  g=fixture();q=make_qa(g,'abs_dir_pred',['camera'],'camera');q['answer']=next(k for k in q['options'] if k!=q['answer'])
  with self.assertRaises(AssertionError):validate_qa(q,g)

if __name__=='__main__':unittest.main()
