import unittest,tempfile,json
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from sam2_contract import select_detections,mask_stats,completed,write_json,file_hash

class Sam2Contracts(unittest.TestCase):
    def box(self,label,box,score=.9):return dict(label=label,bbox_xyxy=box,score=score)
    def test_nms_keeps_distinct_instances(self):
        kept,removed=select_detections([self.box('person',[0,0,10,10]),self.box('person',[1,1,11,11],.8),self.box('person',[20,20,30,30],.7)],40,40)
        self.assertEqual([x['track_id'] for x in kept],[1,2]);self.assertEqual(len(removed),1)
    def test_cross_class_conflict_recorded(self):
        kept,removed=select_detections([self.box('car',[0,0,10,10]),self.box('truck',[0,0,10,10],.8)],20,20)
        self.assertEqual(len(kept),1);self.assertEqual(removed[0]['reason'],'overlap')
    def test_box_clipping_and_limits(self):
        kept,removed=select_detections([self.box('chair',[-5,-6,12,15]),self.box('table',[20,20,30,30],.8)],30,30,max_objects=1)
        self.assertEqual(kept[0]['bbox_xyxy'],[0,0,12,15]);self.assertEqual(removed[0]['reason'],'track_limit')
    def test_bad_boxes_rejected(self):
        with self.assertRaises(ValueError):select_detections([self.box('car',[0,0,float('nan'),3])],10,10)
    def test_mask_bbox_exclusive_and_visibility(self):
        masks=np.zeros((2,8,9),dtype=bool);masks[0,1:5,2:6]=True
        x=mask_stats(masks,[2,7],8,9)
        self.assertEqual(x[0]['bbox_xyxy'],[2,1,6,5]);self.assertTrue(x[0]['valid_for_lifting'])
        self.assertIsNone(x[1]['bbox_xyxy']);self.assertFalse(x[1]['mask_present'])
    def test_empty_scene(self):
        self.assertEqual(mask_stats(np.zeros((0,8,9),dtype=bool),[],8,9),[])
    def test_mask_shape_and_ids(self):
        with self.assertRaises(ValueError):mask_stats(np.zeros((1,9,8),dtype=bool),[1],8,9)
        with self.assertRaises(ValueError):mask_stats(np.zeros((2,8,9),dtype=bool),[1,1],8,9)
    def test_mask_artifact_integrity(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);np.savez_compressed(p/'000.npz',masks=np.zeros((1,8,9),dtype=bool))
            write_json(p/'complete.json',{'run_signature':'a','artifact_sha256':{'000.npz':file_hash(p/'000.npz')}})
            self.assertTrue(completed(p,'a'))
            with self.assertRaises(ValueError):completed(p,'b')
            (p/'000.npz').write_bytes(b'changed')
            with self.assertRaises(ValueError):completed(p,'a')
    def test_user_runner_compile_only(self):
        p=ROOT/'gpu/extract_grounded_sam2.py';compile(p.read_text(),str(p),'exec')
