import sys,unittest,collections,importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from sample_official_viewer_cpu import sample
from orient_contract import read_jsonl
class SampleTests(unittest.TestCase):
 def test_stratified_deterministic(self):
  rows=read_jsonl(ROOT.parent/'viewer_bundle/qa/qa_kept.jsonl');a,c=sample(rows);b,_=sample(list(reversed(rows)))
  self.assertEqual([x['qa_id'] for x in a],[x['qa_id'] for x in b]);self.assertEqual(len(a),100)
  self.assertTrue(all(v['sampled']==min(10,v['available']) for v in c.values()))
 def test_viewer_question_and_bbox_anchor(self):
  rows=json.loads((ROOT.parent/'viewer_bundle/qa/viewer_sample.json').read_text());videos={r['video_id'] for r in rows}
  selected={x['qa_id']:x for x in read_jsonl(ROOT.parent/'viewer_bundle/qa/qa_sample.jsonl')}
  self.assertEqual(len(rows),100);self.assertEqual(len(videos),85)
  for q in rows:
   self.assertEqual(q['question'],selected[q['qa_id']]['official_qa']['Question'])
   for obj in q['objects']:
    for anchor in obj['anchors']:
     self.assertEqual(next(s['bbox'] for s in obj['samples'] if s['t']==anchor['t']),anchor['bbox'])
if __name__=='__main__':unittest.main()
