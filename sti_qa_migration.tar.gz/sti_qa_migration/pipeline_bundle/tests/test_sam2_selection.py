import unittest,json,tempfile,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from select_sam2_candidates import reasons_for
from sam2_contract import validate_screened_job,file_hash,digest,write_json

def obj(label='chair',frames=None):return {'agents':[],'non_agents':[{'label':label,'evidence_frames':frames or [0,7]}],'truncated':False}

class Selection(unittest.TestCase):
 def test_clean_candidate(self):self.assertEqual(reasons_for(obj(),8),[])
 def test_misclassified_vehicle(self):self.assertIn('agent_label_in_non_agents',reasons_for(obj('pickup truck'),8))
 def test_layout_and_ambiguous(self):
  for label in ['road','toy','food','wheel']:self.assertIn('ambiguous_layout_or_part_label',reasons_for(obj(label),8))
 def test_missing_endpoint(self):self.assertIn('insufficient_first_and_last_frame_evidence',reasons_for(obj(frames=[0]),8))
 def test_truncated(self):
  x=obj();x['truncated']=True;self.assertIn('model_reports_omitted_categories',reasons_for(x,8))
 def test_empty_or_too_many(self):
  x=obj();x['non_agents']=[];self.assertIn('require_1_to_8_categories',reasons_for(x,8))
  x['non_agents']=[obj()['non_agents'][0]]*9;self.assertIn('require_1_to_8_categories',reasons_for(x,8))
 def test_unscreened_job_rejected(self):
  with self.assertRaises(ValueError):validate_screened_job({'job_id':'x'})
 def test_screen_is_bound_to_input(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'screen.json';job={'job_id':'x','frames':[1,2]};settings={'threshold':.45};sig=digest({'settings':settings,'job':job})
   write_json(p,{'passed':True,'settings':settings,'signature':sig,'endpoints':[{},{}]})
   job['screening']={'report':str(p),'sha256':file_hash(p),'signature':sig}
   validate_screened_job(job);job['frames']=[2,3]
   with self.assertRaises(ValueError):validate_screened_job(job)
