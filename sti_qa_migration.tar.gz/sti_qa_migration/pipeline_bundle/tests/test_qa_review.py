import sys,unittest,copy
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from test_dsr_qa_contract import fixture
from dsr_qa_contract import make_qa,classify
from review_dsr_qa_cpu import review,needed,option_key

class Review(unittest.TestCase):
 def camera_case(self,g):
  q=make_qa(g,'abs_ori',['camera'],'camera')
  return q,{'g':g,'tracks':{},'centers':{},'orientations':{},'mask_cache':{},'alternatives':{}}
 def test_fast_uniform_camera_is_not_pose_failure(self):
  g=fixture();q,d=self.camera_case(g);reasons,_=review(q,d)
  self.assertNotIn('isolated_camera_pose_jump',reasons)
 def test_isolated_pose_jump_is_flagged(self):
  g=fixture();g['camera_to_world'][-1][0][3]=100;q,d=self.camera_case(g)
  self.assertIn('isolated_camera_pose_jump',review(q,d)[0])
 def test_unrelated_bad_object_does_not_reject_camera_qa(self):
  g=fixture();q,d=self.camera_case(g);expected=review(q,d)[0]
  d['tracks']['unused']={'label':'road','group':'non_agents','score':.1}
  self.assertEqual(review(q,d)[0],expected)
 def test_needed_only_references_relevant_tracks(self):
  g=fixture();q=make_qa(g,'abs_dir',['1','camera'],'camera')
  p,o,a=needed(q,8);self.assertEqual(set(p),{'1'});self.assertEqual(o,{})
  self.assertEqual(a['1'],set(range(8)))
 def test_rule_scale_artifact_detectable(self):
  values=np.array([.01,.02,.04,.08])
  self.assertNotEqual(classify(values,'abs_spd'),classify(values*4,'abs_spd'))
 def test_semantic_option_normalization(self):
  self.assertEqual(option_key('(1) Becomes larger.'),option_key('(1) Become larger.'))

if __name__=='__main__':unittest.main()
