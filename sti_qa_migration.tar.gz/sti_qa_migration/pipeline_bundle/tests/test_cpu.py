import ast
import copy
from pathlib import Path
import sys
import unittest
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from prepare_cpu import select_indices
from qa_cpu import attributes, classify, generate, make_qa, transform_world, validate_geometry, validate_qa

def fixture():
    n=8;ts=np.arange(n,dtype=float)
    poses=np.repeat(np.eye(4)[None],n,axis=0);poses[:,0,3]=ts*.25
    tracks=[]
    for i,speed in enumerate([1.,2.]):
        tracks.append(dict(track_id=f'obj{i}',label=f'synthetic object {i}',centers_world=np.stack([np.full(n,i+1.),np.zeros(n),5+ts*speed],axis=1).tolist(),bboxes_xyxy=[[10+i*30,10,30+i*30,40]]*n,valid=[True]*n))
    return dict(video_id='SYNTHETIC_CPU_TEST_ONLY',coordinate_system='opencv_camera_to_world',is_metric=False,timestamps_s=ts.tolist(),source_frame_indices=list(range(n)),image_size_wh=[100,100],camera_to_world=poses.tolist(),tracks=tracks,sampling_policy='synthetic_1fps',source_video_sha256='synthetic-no-video')

class CPU(unittest.TestCase):
    def test_sampling32(self):
        out=select_indices(np.arange(300)/30,'uniform32')
        self.assertEqual(len(set(out)),32);self.assertEqual((out[0],out[-1]),(0,299))
    def test_1fps(self):
        self.assertEqual(select_indices(np.arange(300)/30,'1fps'),list(range(0,300,30)))
    def test_invalid_timestamps(self):
        for ts in [[0]*40,list(range(31))]:
            with self.assertRaises(ValueError):select_indices(ts,'uniform32')
    def test_camera_axes(self):
        np.testing.assert_allclose(transform_world(np.eye(3),np.repeat(np.eye(4)[None],3,axis=0)),[[0,-1,0],[0,0,-1],[1,0,0]])
    def test_direction(self):
        for v,label in [([1,0,0],'Front'),([0,1,0],'Left'),([0,0,1],'Above'),([-1,0,0],'Behind')]:
            self.assertEqual(classify([v]*4,'abs_dir'),f'(1) {label}.')
    def test_approach_recede_stationary(self):
        for values,text in [([1,2,4,8],'Become larger'),([8,4,2,1],'Become smaller'),([2,2,2,2],'Keep nearly constant')]:
            self.assertEqual(classify(values,'abs_dis'),f'(1) {text}.')
    def test_zero_speed(self):
        self.assertEqual(classify([0,0,0],'abs_spd'),'(1) Keep nearly constant.')
        self.assertIn('former',classify([[1,0]]*3,'abs_spd_comp'))
        self.assertIn('same',classify([[0,0]]*3,'abs_spd_comp'))
    def test_zero_direction_rejected(self):
        with self.assertRaises(ValueError):classify([[0,0,0]]*4,'abs_dir')
    def test_coincident_distance_rejected(self):
        with self.assertRaises(ValueError):classify([0,1,2,3],'abs_dis')
    def test_world_pose_invariance(self):
        g=fixture();expected=attributes(g,'abs_dir',['obj0','obj1'],0,7,0);theta=.7
        r=np.array([[np.cos(theta),0,np.sin(theta)],[0,1,0],[-np.sin(theta),0,np.cos(theta)]]);t=np.array([10,3,-4])
        poses=np.array(g['camera_to_world']);poses[:,:3,3]=poses[:,:3,3]@r.T+t;poses[:,:3,:3]=r@poses[:,:3,:3];g['camera_to_world']=poses.tolist()
        for tr in g['tracks']:tr['centers_world']=(np.array(tr['centers_world'])@r.T+t).tolist()
        np.testing.assert_allclose(attributes(g,'abs_dir',['obj0','obj1'],0,7,0),expected,atol=1e-12)
    def test_distance_viewpoint_invariance(self):
        g=fixture();np.testing.assert_allclose(attributes(g,'abs_dis',['obj0','camera'],0,7,6),attributes(g,'rel_dis',['obj0','camera'],0,7,0))
    def test_nonuniform_dt(self):
        g=fixture();ts=np.array([0,1,3,6,10,15,21,28.]);g['timestamps_s']=ts.tolist()
        g['tracks'][0]['centers_world']=np.stack([ts*0,ts*0,5+2*ts],axis=1).tolist()
        np.testing.assert_allclose(attributes(g,'abs_spd',['obj0'],0,7,0),2.)
    def test_self_relative_camera_is_stationary(self):
        np.testing.assert_allclose(attributes(fixture(),'rel_spd',['camera'],0,7,0),0.)
    def test_track_gap_rejected(self):
        g=fixture();g['tracks'][0]['valid'][3]=False
        with self.assertRaises(ValueError):attributes(g,'abs_dis',['camera','obj0'],0,7,0)
    def test_invalid_pose(self):
        g=fixture();g['camera_to_world'][0][0][0]=2
        with self.assertRaises(ValueError):validate_geometry(g)
    def test_invalid_bbox(self):
        g=fixture();g['tracks'][0]['bboxes_xyxy'][0]=[0,0,101,50]
        with self.assertRaises(ValueError):validate_geometry(g)
    def test_unsupported_prediction(self):
        with self.assertRaises(ValueError):attributes(fixture(),'abs_dir_pred',['obj0'],0,7,0)
    def test_qa_recompute_and_tampering(self):
        g=fixture();q=make_qa(g,'abs_dir',['obj0','camera'],0,7,0,10);self.assertTrue(validate_qa(q,g))
        for key in ['answer_states','query_start_s','source_video_sha256']:
            bad=copy.deepcopy(q);bad[key]='tampered'
            with self.assertRaises(ValueError):validate_qa(bad,g)
    def test_duplicate_option_rejected(self):
        g=fixture();q=make_qa(g,'abs_dir',['obj0','camera'],0,7,0,10);q['options']['B']=q['options']['A']
        with self.assertRaises(ValueError):validate_qa(q,g)
    def test_reproducible_generation(self):
        a,_=generate(fixture());b,_=generate(fixture());self.assertEqual(a,b);self.assertEqual(len(a),8)
        for q in a:self.assertTrue(validate_qa(q,fixture()))
    def test_no_gpu_model_imports(self):
        forbidden={'torch','transformers','cv2','sam2','pi3','cupy'}
        for path in (ROOT/'scripts').glob('*.py'):
            tree=ast.parse(path.read_text())
            # Shared OA adapter loads models only when explicitly called by the
            # user GPU runner or the CPU preflight; importing QA contracts is CPU-only.
            lazy_loader_nodes=set()
            if path.name=='orient_contract.py':
                loaders=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='load_model']
                self.assertEqual(len(loaders),1)
                lazy_loader_nodes={id(n) for n in ast.walk(loaders[0])}
            for n in ast.walk(tree):
                if id(n) in lazy_loader_nodes:continue
                if isinstance(n,ast.Import):names=[a.name for a in n.names]
                elif isinstance(n,ast.ImportFrom):names=[n.module or '']
                else:continue
                self.assertFalse(forbidden & {x.split('.')[0] for x in names},path.name)

if __name__=='__main__':unittest.main()
