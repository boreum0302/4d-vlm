import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from prepare_deepseek_prompts import parse_categories

class Categories(unittest.TestCase):
    def test_two_lines(self):
        r=parse_categories('person. car\nchair. bottle')
        self.assertEqual(r['agents'],['person','car'])
        self.assertEqual(r['objects'],['chair','bottle'])
        self.assertEqual(r['grounding_prompt'],'person. car. chair. bottle.')
    def test_empty_agents(self):
        self.assertEqual(parse_categories('None\nchair. table')['agents'],[])
    def test_empty_both(self):
        self.assertEqual(parse_categories('None\nNone')['grounding_prompt'],'')
    def test_bad_output(self):
        for s in ['car','car\nchair\nextra','car\ncar','Agents: car\nObjects: chair']:
            with self.assertRaises(ValueError):parse_categories(s)

if __name__=='__main__':unittest.main()
