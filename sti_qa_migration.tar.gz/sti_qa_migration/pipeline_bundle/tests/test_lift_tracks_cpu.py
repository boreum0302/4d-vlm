import sys,unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from lift_tracks_cpu import lift

class LiftTests(unittest.TestCase):
    def test_mean_transform_and_invalid_point_exclusion(self):
        local=np.array([[[1.,0,2],[3,0,2]],[[100,0,2],[float('nan'),0,2]]])
        valid=np.array([[True,True],[False,True]])
        pose=np.array([[0.,-1,0,10],[1,0,0,20],[0,0,1,30],[0,0,0,1]])
        result=lift(np.ones((4,4),bool),local,valid,np.ones((2,2)),pose)
        np.testing.assert_allclose(result['center_camera'],[2,0,2]);np.testing.assert_allclose(result['center_world'],[10,22,32])
        self.assertEqual(result['valid_point_count'],2);self.assertTrue(result['valid_for_lifting'])
    def test_empty_mask_has_null_center(self):
        r=lift(np.zeros((4,4),bool),np.ones((2,2,3)),np.ones((2,2),bool),np.ones((2,2)),np.eye(4))
        self.assertIsNone(r['center_world']);self.assertFalse(r['center_available'])
    def test_nearest_resize_and_tiny_mask_retained(self):
        m=np.zeros((4,4),bool);m[:2,:2]=True
        points=np.ones((2,2,3));points[0,0]=[5,6,7]
        r=lift(m,points,np.ones((2,2),bool),np.ones((2,2)),np.eye(4))
        self.assertEqual(r['center_camera'],[5,6,7]);self.assertEqual(r['valid_point_count'],1)
        self.assertFalse(r['valid_for_lifting']);self.assertTrue(r['center_available'])

if __name__=='__main__':unittest.main()
