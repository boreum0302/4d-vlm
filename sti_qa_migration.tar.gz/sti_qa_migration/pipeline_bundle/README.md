# STI → DSR QA 재현

모든 명령은 `pipeline_bundle/` 안에서 실행한다. 기존 중간결과는 포함하지 않으며 새 서버의 원본 STI-Bench에서 새로 생성한다. 외부 모델/코드 경로는 `paths.json` 한 곳에서 설정한다.

## 1. 환경 준비

기존 실행 환경 기록: Python 3.12.3, NumPy 2.1.0, pandas 2.3.3, pyarrow 22.0.0, Pillow 12.0.0, PyTorch 2.11.0+cu130, Transformers 5.15.0. 기록된 버전은 당시 환경이며 새 서버의 드라이버와 맞는 PyTorch CUDA 빌드를 직접 설치한다. 아래는 환경 구성 명령이며 이사 준비 중에는 실행하지 않았다.

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements-cpu.txt
# 새 서버 CUDA/드라이버에 맞는 torch와 torchvision을 먼저 설치한다.
python3 -m pip install -r requirements-gpu.txt
```

`ffmpeg`, `ffprobe`도 필요하다. [다운로드 안내](docs/DOWNLOADS.md)의 외부 저장소별 의존성을 이 환경에 설치한다. SAM2는 다운로드한 코드 루트에서 editable 설치하거나 `sam_code`에 `sam2/`를 포함한 디렉터리를 지정한다. Pi3는 `pi3_code`에 `pi3/`를 포함한 디렉터리를 지정한다. 기존 vendored Python 패키지와 플랫폼별 바이너리는 가져오지 않았다.

## 2. 경로 설정

`paths.json`의 빈 항목을 다운로드한 위치로 채운다. 상대경로 기준은 `pipeline_bundle/`이다. 외부 파일을 폴더 안에 두려면 다음과 같이 작성할 수 있다. 이름은 예시이며 자동 다운로드는 없다.

```json
{
  "sti_bench": "../viewer_bundle/data/STI-Bench",
  "dsr_code": "external/DSR_Suite/data",
  "pi3_code": "external/Pi3",
  "pi3_model": "checkpoints/Pi3",
  "qwen_model": "checkpoints/Qwen3.5-9B",
  "dino_model": "checkpoints/grounding-dino-tiny",
  "sam_checkpoint": "checkpoints/sam2.1-hiera-large/sam2.1_hiera_large.pt",
  "sam_code": "external/sam2",
  "orient_cache": "checkpoints/orient_cache",
  "orient_checkpoint": "checkpoints/Orient-Anything/croplargeEX2/dino_weight.pt",
  "orient_backbone": "checkpoints/dinov2-large",
  "orient_model_code": "external/Orient-Anything/vision_tower.py"
}
```

`orient_cache`는 존재하는 캐시 디렉터리다. `dsr_code`는 보존한 과거 보조 코드용이며 기본 전체 파이프라인은 `vendor/official_sources/`의 공식 QA 함수 사본을 사용한다. 설정을 채우기 전에도 CPU 유틸리티를 import할 수 있도록 모델 경로는 사용 시점에 확인한다.

STI-Bench에는 `qa.parquet`, `data/test-00000-of-00001.parquet`, `video/*.mp4`가 필요하다. HF에서 내려받은 영상 아카이브는 풀어 MP4가 `video/` 바로 아래에 있도록 한다.

```bash
CUDA_VISIBLE_DEVICES='' python3 scripts/validate_paths.py
```

## 3. 전체 실행

**사용자 전용 GPU 명령.** 기존 B200 1장 실측을 기준으로 약 1시간 40분 + 새 환경의 전처리·재시도 시간이며 새 GPU에서의 ETA는 미측정이다. 최대 실측 VRAM은 Qwen 성공 구간 기준 allocated 19.69 / reserved 19.95 GiB다. 실패 구간 peak는 기록되지 않았고 새 GPU의 메모리 요구는 미검증이다.

```bash
bash run_pipeline.sh 0
```

B200 외의 CUDA GPU를 사용할 때는 사용자가 명시적으로 다음 환경 변수를 지정한다. Pi3는 BF16 지원을 요구한다. 동시 노출 GPU는 1장이다.

```bash
# ETA·VRAM: 위 B200 실측 참고, 다른 GPU 실측 없음.
ALLOW_OTHER_GPU=1 bash run_pipeline.sh 0
```

실행 순서는 inventory → Dynamic Understanding 영상 선택 → 1 FPS 및 고정 구간 → Pi3 → Qwen 객체 분류 → 정규화 및 재시도 → GroundingDINO+SAM2 → trajectory → Orient Anything → 공식 QA 생성 → 기초 검수 → 표본 선택이다.

Qwen 최초 생성 및 재시도에서 일부 형식 실패가 남을 수 있다. 원래 실행과 같이 검증된 구간만 후속 처리한다. 실패 목록은 새로 생성되는 `reports/qwen35_validation.json` 및 `manifests/qwen35_objects_retry.jsonl`에서 확인한다. 다른 단계의 오류는 실행을 중단한다.

## 4. 단계별 실행·결과

GPU 단계별 실행 스크립트는 기존 `run_*_b200.sh`를 유지했다. 동일 B200 조건의 실측 시간 및 VRAM은 [RUN.md](RUN.md)에 있다. CPU 후처리는 다음과 같다.

```bash
CUDA_VISIBLE_DEVICES='' bash run_trajectories_cpu.sh all
CUDA_VISIBLE_DEVICES='' bash run_official_qa_cpu.sh
CUDA_VISIBLE_DEVICES='' python3 scripts/review_official_obvious_cpu.py
CUDA_VISIBLE_DEVICES='' python3 scripts/sample_official_viewer_cpu.py
```

최종 결과: `outputs/dsr_official_review/qa_kept.jsonl`, `qa_pairs_kept.json`, `summary.json`. 검수 전 결과: `outputs/dsr_official/qa_all.jsonl`, `qa_pairs.json`, `generation_summary.json`. 폴더를 옮길 때 실행 중인 작업은 종료하고 묶음 전체를 옮긴 뒤 같은 작업 루트에서 재개한다.

영상별 구간 seed 260920, 구간당 공식 생성 10회 시도, 표본 seed 260921이다. Dynamic Understanding 영상 363개 중 당시 Qwen 검증 통과 353개, QA 생성 영상 273개, 최종 958 QA였다. 샘플링 규칙·공식 캐시 어댑터 설명·과거 판단은 `docs/history/`에 모았다. 해당 문서는 과거 이력이며 새 서버 실행은 이 README와 paths.json을 따른다.

직접 실행되는 코드는 상대경로를 쓰며 생성 프레임 symlink도 상대경로다. 입력·출력의 hash 및 공식 함수는 유지하지만 경로와 GPU 모델 추론 환경이 달라지면 기존 QA와 바이트 단위 동일성을 보장하지 않는다. 외부 코드의 당시 정확한 사본은 이 묶음에 포함하지 않았으므로 아래 버전·hash 기록을 참고한다.
