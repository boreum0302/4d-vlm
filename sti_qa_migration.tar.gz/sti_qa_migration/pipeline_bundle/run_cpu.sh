#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export CUDA_VISIBLE_DEVICES=""
export NVIDIA_VISIBLE_DEVICES="none"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
case "${1:-check}" in
  prepare) python scripts/prepare_cpu.py all --workers 4; python scripts/finalize_cpu.py ;;
  check) python scripts/finalize_cpu.py ;;
  test) python -m unittest discover -s tests -v ;;
  *) echo 'Usage: bash run_cpu.sh {prepare|check|test}' >&2; exit 2 ;;
esac
