import os
#!/usr/bin/env python3
"""USER-ONLY B200 entry point. Direct visual categories; no caption or API stage."""
import argparse
import fcntl
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
from qwen35_contract import (ROOT, MODEL, PROMPT, build_inputs, completed, digest, file_hash,
                             model_inventory, parse_objects, read_jsonl, verify_frames, write_json)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--subset', choices=['smoke', 'all'], default='smoke')
    parser.add_argument('--model', type=Path, default=MODEL)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--prompt', type=Path, default=PROMPT)
    parser.add_argument('--normalize-output', action='store_true')
    parser.add_argument('--output-root', type=Path, default=ROOT/'artifacts/qwen35_objects')
    parser.add_argument('--max-pixels', type=int, default=262144)
    parser.add_argument('--max-new-tokens', type=int, default=1536)
    args = parser.parse_args()
    args.model = Path(args.model)
    if args.max_pixels < 4096 or args.max_new_tokens < 1:
        parser.error('Invalid pixel/token limit')
    manifest = args.manifest or ROOT/f'manifests/qwen35_objects_{args.subset}.jsonl'
    jobs = read_jsonl(manifest)
    prompt = args.prompt.read_text()
    settings = {'model': model_inventory(args.model), 'prompt_sha256': file_hash(args.prompt),
                'runner_sha256': file_hash(__file__), 'contract_sha256': file_hash(ROOT/'scripts/qwen35_contract.py'),
                'max_pixels': args.max_pixels, 'max_new_tokens': args.max_new_tokens,
                'normalize_output': args.normalize_output, 'normalizer_sha256': file_hash(ROOT/'scripts/normalize_qwen35_objects.py'),
                'enable_thinking': False, 'dtype': 'bfloat16', 'attention': 'sdpa', 'batch_size': 1}
    import torch
    import transformers
    from transformers import AutoProcessor, Qwen3_5ForConditionalGeneration
    if torch.cuda.device_count() != 1 or ('B200' not in torch.cuda.get_device_name(0) and os.environ.get('ALLOW_OTHER_GPU') != '1'):
        raise RuntimeError('Expose exactly one B200 with CUDA_VISIBLE_DEVICES')
    settings.update(torch=torch.__version__, transformers=transformers.__version__)
    args.output_root.mkdir(parents=True, exist_ok=True)
    # Prevent concurrent smoke/all workers from overwriting per-job and aggregate files.
    lock = open(args.output_root/'.run.lock', 'a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    started = time.perf_counter()
    processor = AutoProcessor.from_pretrained(args.model, local_files_only=True)
    model = Qwen3_5ForConditionalGeneration.from_pretrained(
        args.model, dtype=torch.bfloat16, device_map={'': 0},
        attn_implementation='sdpa', local_files_only=True).eval()
    peak_load = {'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                 'reserved_gib': torch.cuda.max_memory_reserved()/2**30}
    print(json.dumps({'model_loaded_seconds': time.perf_counter()-started, 'load_peak': peak_load}), flush=True)
    results, errors, durations = [], [], []
    for index, job in enumerate(jobs):
        out = args.output_root/job['video_id']/job['segment_id']
        signature = digest({'settings': settings, 'job': job})
        inputs = generated = None
        try:
            verify_frames(job)
            if completed(out, signature):
                results.append(json.loads((out/'objects.json').read_text()))
                print(f'[{index+1}/{len(jobs)}] SKIP {job["job_id"]}', flush=True)
                continue
            tick = time.perf_counter()
            inputs = build_inputs(processor, job, prompt, args.max_pixels).to('cuda')
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
            infer_start = time.perf_counter()
            with torch.inference_mode():
                generated = model.generate(**inputs, do_sample=False, max_new_tokens=args.max_new_tokens)
            torch.cuda.synchronize()
            inference_seconds = time.perf_counter()-infer_start
            tokens = generated[0, inputs['input_ids'].shape[-1]:]
            raw = processor.decode(tokens, skip_special_tokens=True)
            write_json(out/'raw_response.json', {'text': raw, 'generated_tokens': len(tokens)})
            if len(tokens) >= args.max_new_tokens:
                raise ValueError('Output hit max-new-tokens; review raw response, use new output root with higher limit')
            if args.normalize_output:
                from normalize_qwen35_objects import normalize
                data, normalization_changes = normalize(raw, len(job['frames']))
            else:
                data = parse_objects(raw, len(job['frames']))
                normalization_changes = []
            result = dict(data, job_id=job['job_id'], video_id=job['video_id'], segment_id=job['segment_id'],
                          query_start_s=job['query_start_s'], query_end_s=job['query_end_s'],
                          frames=job['frames'], source_video_path=job['source_video_path'])
            stats = {'inference_seconds': inference_seconds, 'total_seconds': time.perf_counter()-tick,
                     'input_tokens': int(inputs['input_ids'].shape[-1]), 'output_tokens': len(tokens),
                     'peak_allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                     'peak_reserved_gib': torch.cuda.max_memory_reserved()/2**30,
                     'model_load_peak': peak_load}
            write_json(out/'objects.json', result)
            write_json(out/'quality.json', stats)
            write_json(out/'provenance.json', {'run_signature': signature, 'settings': settings,
                                              'manifest': str(manifest), 'prompt': prompt, 'normalization_changes': normalization_changes})
            names = ['objects.json', 'raw_response.json', 'quality.json', 'provenance.json']
            write_json(out/'complete.json', {'run_signature': signature,
                       'artifact_sha256': {n: file_hash(out/n) for n in names}})
            results.append(result)
            durations.append(time.perf_counter()-tick)
            eta = sum(durations[-10:])/len(durations[-10:])*(len(jobs)-index-1)/60
            print(f'[{index+1}/{len(jobs)}] OK {job["job_id"]}: {inference_seconds:.2f}s, '
                  f'peak allocated={stats["peak_allocated_gib"]:.2f} GiB reserved={stats["peak_reserved_gib"]:.2f} GiB, ETA={eta:.1f} min', flush=True)
        except Exception as exc:
            error = {'job_id': job['job_id'], 'error': str(exc)}
            errors.append(error)
            # Keep completed output immutable when provenance or integrity mismatches.
            if not (out/'complete.json').exists():
                write_json(out/'last_error.json', error)
            print(json.dumps(error), flush=True)
        finally:
            inputs = generated = None
            torch.cuda.empty_cache()
    target = args.output_root/f'objects_{args.subset}.jsonl'
    temp = target.with_suffix('.jsonl.tmp')
    temp.write_text(''.join(json.dumps(r) + '\n' for r in results))
    temp.replace(target)
    report = {'jobs': len(jobs), 'valid_or_cached': len(results), 'failed': len(errors),
              'errors': errors, 'wall_seconds': time.perf_counter()-started,
              'visual_review_pending': True, 'aggregate': str(target)}
    write_json(args.output_root/f'run_{args.subset}.json', report)
    print(json.dumps(report), flush=True)
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
