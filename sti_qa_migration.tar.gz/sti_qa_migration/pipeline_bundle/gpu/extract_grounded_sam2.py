import os
#!/usr/bin/env python3
"""USER-ONLY B200 runner: first-frame GroundingDINO -> SAM2 interval tracks."""
import argparse,fcntl,json,sys,time,traceback
from pathlib import Path
ROOT=Path('.')
sys.path.insert(0,str(ROOT/'scripts'))
from sam2_contract import (DINO,SAM,SAM_CODE,SAM_CONFIG,read_jsonl,write_json,file_hash,digest,
                           verify_frames,select_detections,mask_stats,completed,qwen_objects)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--subset',choices=['smoke','all'],default='smoke')
    p.add_argument('--output-root',type=Path,default=ROOT/'artifacts/grounded_sam2')
    p.add_argument('--max-objects',type=int,default=16)
    p.add_argument('--box-threshold',type=float,default=.35)
    p.add_argument('--text-threshold',type=float,default=.25)
    a=p.parse_args()
    if not 1<=a.max_objects<=64 or not 0<a.box_threshold<1 or not 0<a.text_threshold<1:p.error('Invalid limits')
    manifest=ROOT/f'manifests/sam2_{a.subset}.jsonl';jobs=read_jsonl(manifest)
    if not jobs:raise ValueError('Empty stage-6 manifest')
    sys.path.insert(0,str(ROOT/'vendor/sam2_deps'));sys.path.insert(0,str(SAM_CODE))
    import numpy as np
    import torch
    import transformers
    from PIL import Image
    from transformers import AutoConfig,AutoProcessor,AutoModelForZeroShotObjectDetection
    from sam2.build_sam import build_sam2_video_predictor
    if torch.cuda.device_count()!=1 or ('B200' not in torch.cuda.get_device_name(0) and os.environ.get('ALLOW_OTHER_GPU') != '1'):
        raise RuntimeError('Expose exactly one B200')
    a.output_root.mkdir(parents=True,exist_ok=True)
    lock=open(a.output_root/'.run.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    sam_source={str(p.relative_to(SAM_CODE/'sam2')):file_hash(p) for p in sorted((SAM_CODE/'sam2').rglob('*.py'))}
    settings={'dino':str(DINO),'dino_sha256':file_hash(DINO/'model.safetensors'),'sam':str(SAM),
              'sam_sha256':file_hash(SAM),'sam_config':SAM_CONFIG,'sam_source_sha256':digest(sam_source),
              'sam_config_sha256':file_hash(SAM_CODE/'sam2'/SAM_CONFIG),
              'runner_sha256':file_hash(__file__),'contract_sha256':file_hash(ROOT/'scripts/sam2_contract.py'),
              'max_objects':a.max_objects,'box_threshold':a.box_threshold,'text_threshold':a.text_threshold,
              'seed_frame':0,'dino_dtype':'float32','sam_autocast':'bfloat16','dino_custom_kernels':False,
              'sam_fill_holes':False,'offload_video_to_cpu':True,'torch':torch.__version__,
              'transformers':transformers.__version__}
    started=time.perf_counter()
    config=AutoConfig.from_pretrained(str(DINO),local_files_only=True);config.disable_custom_kernels=True
    processor=AutoProcessor.from_pretrained(str(DINO),local_files_only=True)
    detector=AutoModelForZeroShotObjectDetection.from_pretrained(str(DINO),config=config,local_files_only=True).to('cuda').eval()
    tracker=build_sam2_video_predictor(SAM_CONFIG,str(SAM),device='cuda',apply_postprocessing=False,
                                      hydra_overrides_extra=['++model.fill_hole_area=0'])
    load_peak={'allocated_gib':torch.cuda.max_memory_allocated()/2**30,'reserved_gib':torch.cuda.max_memory_reserved()/2**30}
    print(json.dumps({'loaded_seconds':time.perf_counter()-started,'load_peak':load_peak}),flush=True)
    summaries=[];failures=[];times=[];skipped=0
    for idx,job in enumerate(jobs,1):
        out=a.output_root/job['video_id']/job['segment_id'];signature=digest({'settings':settings,'job':job})
        state=det_inputs=det_out=logits=None;mask_files=[]
        try:
            verify_frames(job)
            if qwen_objects(job)!=job['object_input']:
                raise ValueError('Stage-5 objects changed; re-prepare inputs')
            if completed(out,signature):
                summaries.append(json.loads((out/'summary.json').read_text()));skipped+=1
                print(f'[{idx}/{len(jobs)}] SKIP {job["job_id"]}',flush=True);continue
            tick=time.perf_counter();torch.cuda.reset_peak_memory_stats()
            write_json(out/'provenance.json',{'settings':settings,'run_signature':signature,'input':job})
            with Image.open(job['frames'][0]['path']) as im:first=im.convert('RGB')
            width,height=first.size;candidates=[]
            # Separate category prompts retain an exact mapping to agent/non-agent labels.
            for obj in job['object_input']['objects']:
                det_inputs=processor(images=first,text=obj['label']+'.',return_tensors='pt').to('cuda')
                with torch.inference_mode():det_out=detector(**det_inputs)
                detection=processor.post_process_grounded_object_detection(
                    det_out,det_inputs.input_ids,threshold=a.box_threshold,text_threshold=a.text_threshold,
                    target_sizes=[(height,width)])[0]
                for box,score in zip(detection['boxes'].cpu().tolist(),detection['scores'].cpu().tolist()):
                    candidates.append(dict(label=obj['label'],group=obj['group'],score=score,bbox_xyxy=box,
                                           orientation_candidate=obj['orientation_candidate']))
                det_inputs=det_out=None
            seeds,discarded=select_detections(candidates,width,height,a.max_objects)
            write_json(out/'detections.json',{'seed_frame':0,'kept':seeds,'discarded':discarded})
            ids=[x['track_id'] for x in seeds];records=[]
            (out/'masks').mkdir(exist_ok=True)
            def save_frame(index,masks):
                stats=mask_stats(masks,ids,height,width)
                dest=out/'masks'/f'{index:03d}.npz';temp=dest.with_name(dest.stem+'.tmp.npz')
                np.savez_compressed(temp,masks=masks,track_ids=np.asarray(ids,dtype=np.int32));temp.replace(dest)
                mask_files.append(str(dest.relative_to(out)))
                records.append({'segment_frame_index':index,'timestamp_s':job['frames'][index]['timestamp_s'],
                                'source_frame_index':job['frames'][index]['source_frame_index'],
                                'mask_path':str(dest.resolve()),'objects':stats})
            if seeds:
                with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                    state=tracker.init_state(video_path=job['frame_directory'],offload_video_to_cpu=True,offload_state_to_cpu=False)
                    if state['num_frames']!=len(job['frames']) or (state['video_width'],state['video_height'])!=(width,height):
                        raise ValueError('SAM2 loader frame/size mismatch')
                    for seed in seeds:
                        tracker.add_new_points_or_box(state,frame_idx=0,obj_id=seed['track_id'],box=np.asarray(seed['bbox_xyxy'],dtype=np.float32))
                    for index,out_ids,logits in tracker.propagate_in_video(state):
                        if list(out_ids)!=ids:raise ValueError('SAM2 track ID order changed')
                        masks=(logits[:,0]>0).cpu().numpy()
                        save_frame(index,masks)
            else:
                for index in range(len(job['frames'])):save_frame(index,np.zeros((0,height,width),dtype=bool))
            if sorted(x['segment_frame_index'] for x in records)!=list(range(len(job['frames']))):
                raise ValueError('SAM2 did not return every interval frame exactly once')
            records.sort(key=lambda x:x['segment_frame_index'])
            tracks={'job_id':job['job_id'],'video_id':job['video_id'],'segment_id':job['segment_id'],
                    'query_start_s':job['query_start_s'],'query_end_s':job['query_end_s'],
                    'image_size_wh':[width,height],'bbox_convention':'xyxy, exclusive upper bound, original image pixels',
                    'tracks':seeds,'frames':records,'source_frames':job['frames'],
                    'review_status':'needs_visual_review','mask_presence_is_not_verified_visibility':True,
                    'initial_frame_detection_only':True}
            write_json(out/'tracks.json',tracks)
            torch.cuda.synchronize();seconds=time.perf_counter()-tick
            stats={'total_seconds':seconds,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,
                   'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30,'model_load_peak':load_peak}
            write_json(out/'quality.json',stats)
            summary={'job_id':job['job_id'],'tracks':len(seeds),'frames':len(records),
                     'tracks_path':str((out/'tracks.json').resolve()),
                     'status':'tracked' if seeds else 'no_initial_detections',
                     'category_truncated':job['object_input']['truncated'],
                     'track_limit_hit':any(x['reason']=='track_limit' for x in discarded)}
            write_json(out/'summary.json',summary)
            names=mask_files+['tracks.json','detections.json','provenance.json','quality.json','summary.json']
            write_json(out/'complete.json',{'run_signature':signature,'artifact_sha256':{n:file_hash(out/n) for n in names}})
            summaries.append(summary);times.append(time.perf_counter()-tick)
            eta=sum(times[-10:])/len(times[-10:])*(len(jobs)-idx)/60
            print(f'[{idx}/{len(jobs)}] OK {job["job_id"]} tracks={len(seeds)} seconds={seconds:.1f} '
                  f'peak={stats["peak_allocated_gib"]:.2f}/{stats["peak_reserved_gib"]:.2f} GiB ETA={eta:.1f} min',flush=True)
        except Exception as exc:
            error={'job_id':job['job_id'],'error':str(exc),'traceback':traceback.format_exc()};failures.append(error)
            if not (out/'complete.json').exists():write_json(out/'last_error.json',error)
            print(json.dumps(error),flush=True)
        finally:
            state=det_inputs=det_out=logits=None
            torch.cuda.empty_cache()
    write_json(a.output_root/f'run_{a.subset}.json',{'requested':len(jobs),'complete':len(summaries),'skipped':skipped,
               'failed':len(failures),'no_initial_detections':sum(x['status']=='no_initial_detections' for x in summaries),
               'wall_seconds':time.perf_counter()-started,'errors':failures})
    dest=a.output_root/f'tracks_{a.subset}.jsonl';temp=dest.with_suffix('.jsonl.tmp')
    temp.write_text(''.join(json.dumps(x)+'\n' for x in summaries));temp.replace(dest)
    if failures:raise SystemExit(1)


if __name__=='__main__':main()
