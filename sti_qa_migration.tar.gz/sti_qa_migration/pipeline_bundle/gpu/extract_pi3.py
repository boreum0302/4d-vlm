#!/usr/bin/env python3
"""USER-LAUNCHED GPU ENTRY POINT. The assistant must never execute this file."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT=Path('.')
sys.path.insert(0,str(ROOT/'scripts'))
from pi3_contract import completion_matches, file_hash, source_hash, validate_output, verify_job


def atomic_json(p,value):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(p)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',required=True,type=Path)
    p.add_argument('--model',required=True,type=Path)
    p.add_argument('--code-root',required=True,type=Path)
    p.add_argument('--pixel-limit',type=int,default=255000)
    p.add_argument('--output-root',type=Path)
    args=p.parse_args()
    if args.pixel_limit<196:p.error('pixel-limit must be >=196')
    os.environ['HF_HUB_OFFLINE']='1'
    os.environ['TRANSFORMERS_OFFLINE']='1'
    sys.path.insert(0,str(args.code_root))
    # GPU/model libraries are imported ONLY by this explicitly user-launched entry point.
    import numpy as np
    import torch
    from pi3.models.pi3 import Pi3
    from pi3.utils.basic import load_images_as_tensor
    from pi3.utils.geometry import depth_edge

    if not torch.cuda.is_available():raise RuntimeError('No CUDA device; this entry point never falls back to CPU')
    if torch.cuda.device_count()!=1:raise RuntimeError('Expose exactly one B200 via CUDA_VISIBLE_DEVICES')
    device_name=torch.cuda.get_device_name(0)
    if 'B200' not in device_name and os.environ.get('ALLOW_OTHER_GPU') != '1':raise RuntimeError(f'Expected B200, found {device_name}')
    if not torch.cuda.is_bf16_supported():raise RuntimeError('BF16 support is required')
    jobs=[json.loads(x) for x in args.manifest.read_text().splitlines() if x.strip()]
    if not jobs:raise ValueError('Empty input manifest')
    model_file=args.model/'model.safetensors'
    if not model_file.is_file() or not (args.model/'config.json').is_file():raise FileNotFoundError(args.model)
    settings=dict(model_path=str(args.model.resolve()),model_sha256=file_hash(model_file),
                  model_config_sha256=file_hash(args.model/'config.json'),
                  source_sha256=source_hash(args.code_root/'pi3'),runner_sha256=file_hash(__file__),
                  contract_sha256=file_hash(ROOT/'scripts/pi3_contract.py'),
                  pixel_limit=args.pixel_limit,dtype='bfloat16',torch_version=torch.__version__,
                  cuda_version=torch.version.cuda,gpu_name=device_name,conf_threshold=.1,depth_edge_rtol=.03)
    model=None;failures=0;completed=0;skipped=0;recent_seconds=[];run_started=time.perf_counter()
    for idx,job in enumerate(jobs,1):
        out=(args.output_root/job['video_id']/job['segment_id']) if args.output_root else Path(job['output_directory'])
        out.mkdir(parents=True,exist_ok=True)
        lock=(out/'run.lock').open('a+')
        result=None;images=None
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            verify_job(job)
            signature=hashlib.sha256(json.dumps(dict(settings=settings,input=job),sort_keys=True).encode()).hexdigest()
            if completion_matches(out,signature):
                skipped+=1;print(f'[{idx}/{len(jobs)}] SKIP {job["job_id"]}',flush=True);continue
            if model is None:
                print(f'Loading Pi3 once on {device_name}',flush=True)
                model=Pi3.from_pretrained(str(args.model),local_files_only=True).to('cuda:0').eval()
            start=time.perf_counter()
            images=load_images_as_tensor(job['frame_directory'],interval=1,PIXEL_LIMIT=args.pixel_limit)
            if images.shape[0]!=len(job['frames']):raise ValueError('Loader dropped input frames')
            rgb=(images.permute(0,2,3,1).numpy()*255).round().clip(0,255).astype(np.uint8)
            images=images.to('cuda:0')
            torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
            inference_start=time.perf_counter()
            with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                result=model(images[None])
            torch.cuda.synchronize()
            inference_seconds=time.perf_counter()-inference_start
            conf=torch.sigmoid(result['conf'][0,...,0].float())
            edge=depth_edge(result['local_points'][0,...,2].float(),rtol=.03)
            valid=((conf>.1)&~edge).cpu().numpy()
            local=result['local_points'][0].float().cpu().numpy()
            poses=result['camera_poses'][0].float().cpu().numpy()
            logits=result['conf'][0,...,0].float().cpu().numpy()
            stats=validate_output(local,poses,logits,valid)
            # Pi3's returned world points must match lifting local points with c2w.
            expected=np.einsum('nij,nhwj->nhwi',poses[:,:3,:3],local)+poses[:,:3,3][:,None,None,:]
            world=result['points'][0].float().cpu().numpy()
            if not np.allclose(expected,world,rtol=2e-4,atol=2e-4):raise ValueError('World/local pose convention mismatch')
            tmp=out/'scene_geometry.npz.tmp'
            with tmp.open('wb') as f:
                np.savez_compressed(f,local_points=local,camera_to_world=poses,confidence_logits=logits,
                    confidence=conf.cpu().numpy(),valid_mask=valid,images_uint8=rgb,
                    timestamps_s=np.array([f['timestamp_s'] for f in job['frames']]),
                    source_frame_indices=np.array([f['source_frame_index'] for f in job['frames']]))
            tmp.replace(out/'scene_geometry.npz')
            frame_map=dict(job,model_image_size_wh=stats['image_size_wh'],
                           resize_policy='Pi3 load_images_as_tensor: aspect-ratio resize, 14-multiple, LANCZOS',
                           coordinate_system='opencv_camera_to_world',is_metric=False,
                           bbox_alignment='resize original masks with nearest-neighbor to model pixel grid')
            atomic_json(out/'frame_map.json',frame_map)
            stats.update(inference_seconds=inference_seconds,total_seconds=time.perf_counter()-start,
                         peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                         peak_reserved_gib=torch.cuda.max_memory_reserved()/2**30)
            atomic_json(out/'quality.json',stats)
            atomic_json(out/'provenance.json',dict(settings=settings,run_signature=signature,
                        job_id=job['job_id'],manifest=str(args.manifest.resolve()),
                        manifest_sha256=file_hash(args.manifest),status='numeric_validation_passed_visual_review_pending'))
            names=['scene_geometry.npz','frame_map.json','quality.json','provenance.json']
            atomic_json(out/'complete.json',dict(run_signature=signature,artifact_sha256={n:file_hash(out/n) for n in names}))
            completed+=1
            recent_seconds.append(stats['total_seconds'])
            remaining=len(jobs)-idx
            eta_seconds=sum(recent_seconds[-10:])/len(recent_seconds[-10:])*remaining
            print(f'ETA {eta_seconds/60:.1f} min for {remaining} remaining jobs (last <=10 jobs; cached jobs may shorten ETA)',flush=True)
            print(f'[{idx}/{len(jobs)}] OK {job["job_id"]}: {inference_seconds:.2f}s inference, {stats["peak_allocated_gib"]:.2f} GiB allocated / {stats["peak_reserved_gib"]:.2f} GiB reserved',flush=True)
        except Exception as exc:
            failures+=1
            # Never remove or mark partial outputs complete. Retry starts this job again.
            error=dict(job_id=job['job_id'],error=str(exc),traceback=traceback.format_exc())
            if not isinstance(exc,BlockingIOError):atomic_json(out/'last_error.json',error)
            print(f'[{idx}/{len(jobs)}] FAILED {job["job_id"]}: {exc}',file=sys.stderr,flush=True)
        finally:
            result=None;images=None;conf=None;edge=None
            torch.cuda.empty_cache()
            lock.close()
    print(json.dumps(dict(completed=completed,skipped=skipped,failed=failures,wall_seconds=time.perf_counter()-run_started)),flush=True)
    if failures:raise SystemExit(1)


if __name__=='__main__':main()
