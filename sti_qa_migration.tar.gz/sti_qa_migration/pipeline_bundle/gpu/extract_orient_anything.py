import os
#!/usr/bin/env python3
"""USER ONLY: B200 Orient Anything inference; never run this entry point from an agent."""
import argparse,fcntl,json,sys,time,traceback
from pathlib import Path
ROOT=Path('.');sys.path.insert(0,str(ROOT/'scripts'))
from orient_contract import (read_jsonl,write_json,file_hash,digest,completed,model_inventory,
                             load_model,crop_object,decode_logits,dsr_camera_to_agent)
from qwen35_contract import verify_frames
from orient_contract import verify_upstream as verify


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--subset',choices=['all','smoke'],default='all')
    p.add_argument('--output-root',type=Path,default=ROOT/'artifacts/orient_anything');a=p.parse_args()
    import numpy as np
    import torch
    from PIL import Image
    if torch.cuda.device_count()!=1 or ('B200' not in torch.cuda.get_device_name(0) and os.environ.get('ALLOW_OTHER_GPU') != '1'):raise RuntimeError('Expose exactly one B200')
    torch.backends.cuda.matmul.allow_tf32=False
    jobs=read_jsonl(ROOT/f'manifests/orient_{a.subset}.jsonl')
    if not jobs:raise ValueError('Empty orientation manifest')
    a.output_root.mkdir(parents=True,exist_ok=True)
    lock=open(a.output_root/'.run.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    settings={'models':model_inventory(),'contract_sha256':file_hash(ROOT/'scripts/orient_contract.py'),
              'runner_sha256':file_hash(__file__),'dtype':'float32','batch_size':1,'input_size':[224,224],
              'crop':'mask on white, bbox with 10px padding','angle_convention':'DSR croplargeEX2: az360/polar180/rotation180/conf2',
              'selection':'agents & orientation_candidate, every nonempty mask, no confidence/area/geometry filter',
              'torch':torch.__version__,'world_rotation':'Pi3 c2w R @ DSR camera_to_agent R transpose'}
    started=time.perf_counter();model=processor=None;rows=[];errors=[];skipped=0;peaks=[];reserved=[]
    for index,job in enumerate(jobs,1):
        tick=time.perf_counter();out=a.output_root/job['video_id']/job['segment_id']
        try:
            verify_frames(job)
            sam=ROOT/'artifacts/grounded_sam2'/job['video_id']/job['segment_id']
            traj=ROOT/'artifacts/trajectories'/job['video_id']/job['segment_id'];geom=Path(job['output_directory'])
            inputs={'sam2':verify(sam),'trajectory':verify(traj),'pi3':verify(geom)}
            if inputs!=job['orientation']['upstream_marker_sha256']:raise ValueError('Upstream changed; re-prepare inputs')
            signature=digest({'settings':settings,'job':job})
            if completed(out,signature):
                rows.append(json.loads((out/'summary.json').read_text()));skipped+=1
                continue
            torch.cuda.reset_peak_memory_stats()
            tracks=json.loads((sam/'tracks.json').read_text());centers=json.loads((traj/'trajectories.json').read_text())
            if tracks['source_frames']!=job['frames'] or centers['source_frames']!=job['frames']:raise ValueError('Frame mismatch')
            selected=[dict(t,samples=[]) for t in tracks['tracks'] if t['track_id'] in job['orientation']['track_ids']]
            lookup={t['track_id']:t for t in selected};center_lookup={t['track_id']:t for t in centers['tracks']}
            with np.load(geom/'scene_geometry.npz',allow_pickle=False) as z:poses=z['camera_to_world']
            predicted=empty=low=0
            for i,frame in enumerate(job['frames']):
                if not selected:break
                with np.load(sam/'masks'/f'{i:03d}.npz',allow_pickle=False) as z:
                    ids=z['track_ids'].tolist();masks=z['masks']
                with Image.open(frame['path']) as im:rgb=np.asarray(im.convert('RGB'))
                for track_id,t in lookup.items():
                    mask=masks[ids.index(track_id)];crop=crop_object(rgb,mask)
                    sample={'segment_frame_index':i,'timestamp_s':frame['timestamp_s'],'source_frame_index':frame['source_frame_index'],
                            'mask_area_pixels':int(mask.sum()),'center_world':center_lookup[track_id]['samples'][i]['center_world'],
                            'angles':None,'rotation_camera_to_agent_dsr':None,'rotation_agent_to_world_dsr':None}
                    if crop is None:
                        sample['status']='empty_mask';empty+=1
                    else:
                        if model is None:model,processor=load_model('cuda')
                        x=processor(images=crop[0],return_tensors='pt').to('cuda')
                        with torch.inference_mode():pred=model(x)
                        angles=decode_logits(pred[0].float().cpu().numpy())
                        r=dsr_camera_to_agent(angles['azimuth_deg'],angles['polar_deg'],angles['rotation_deg'])
                        rw=poses[i,:3,:3]@r.T
                        if not np.isfinite(rw).all() or not np.allclose(rw.T@rw,np.eye(3),atol=3e-3):raise ValueError('Invalid rotation')
                        sample.update(status='predicted',angles=angles,crop_bbox=crop[1],low_confidence=angles['confidence']<.5,
                                      rotation_camera_to_agent_dsr=r.tolist(),rotation_agent_to_world_dsr=rw.tolist())
                        predicted+=1;low+=angles['confidence']<.5
                    t['samples'].append(sample)
            result={'job_id':job['job_id'],'video_id':job['video_id'],'segment_id':job['segment_id'],
                    'query_start_s':job['query_start_s'],'query_end_s':job['query_end_s'],'source_frames':job['frames'],
                    'tracks':selected,'angle_units':'degrees','angle_convention':'DSR croplargeEX2; polar and in-plane rotation, not generic yaw/pitch/roll',
                    'world_basis':'Pi3 interval world; matrix columns are DSR agent axes in world coordinates',
                    'review_status':'needs_visual_review','interpolation':False}
            write_json(out/'orientations.json',result);torch.cuda.synchronize()
            quality={'wall_seconds':time.perf_counter()-tick,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,
                     'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30}
            peaks.append(quality['peak_allocated_gib']);reserved.append(quality['peak_reserved_gib'])
            summary={'job_id':job['job_id'],'tracks':len(selected),'predicted':predicted,'empty_mask':empty,'low_confidence':low,
                     'status':'no_eligible_agents' if not selected else 'predicted' if predicted else 'empty_masks',
                     'orientations_path':str((out/'orientations.json').resolve())}
            write_json(out/'summary.json',summary);write_json(out/'quality.json',quality)
            write_json(out/'provenance.json',{'settings':settings,'inputs':inputs,'run_signature':signature})
            write_json(out/'complete.json',{'run_signature':signature,'artifact_sha256':{n:file_hash(out/n) for n in ['orientations.json','summary.json','quality.json','provenance.json']}})
            rows.append(summary)
            print(f'[{index}/{len(jobs)}] OK {job["job_id"]} crops={predicted} seconds={quality["wall_seconds"]:.2f} peak={quality["peak_allocated_gib"]:.2f}/{quality["peak_reserved_gib"]:.2f} GiB',flush=True)
        except Exception as exc:
            error={'job_id':job['job_id'],'error':str(exc),'traceback':traceback.format_exc()};errors.append(error)
            if not (out/'complete.json').exists():write_json(out/'last_error.json',error)
            print(json.dumps(error),flush=True)
    dest=a.output_root/f'orientations_{a.subset}.jsonl';tmp=dest.with_suffix('.tmp');tmp.write_text(''.join(json.dumps(x)+'\n' for x in rows));tmp.replace(dest)
    write_json(a.output_root/f'run_{a.subset}.json',{'requested':len(jobs),'complete':len(rows),'failed':len(errors),'skipped':skipped,
               'wall_seconds':time.perf_counter()-started,'peak_allocated_gib':max(peaks,default=0),'peak_reserved_gib':max(reserved,default=0),
               'predicted':sum(x['predicted'] for x in rows),'errors':errors})
    if errors:raise SystemExit(1)


if __name__=='__main__':main()
