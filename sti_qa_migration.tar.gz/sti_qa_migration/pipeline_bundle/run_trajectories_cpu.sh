#!/usr/bin/env bash
# CPU only: no torch or GPU model imports.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
"${CPU_PYTHON:-python3}" -u scripts/lift_tracks_cpu.py --subset "${1:-all}"
