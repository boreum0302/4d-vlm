# 새 서버 실행 노트

설치·상대경로 설정·전체 실행은 [README.md](README.md), 다운로드 링크는 [docs/DOWNLOADS.md](docs/DOWNLOADS.md)를 따른다. 과거 실행 기록은 [docs/history/RUN.md](docs/history/RUN.md)에 보존했다.

GPU 명령은 사용자만 실행한다. 기존 실측은 B200 1장, Pi3 BF16 pixel limit 255000, Qwen 9B, SAM2 BF16, Orient Anything FP32 batch 1 조건이다. 새 서버 ETA/VRAM은 미측정이며 아래 값은 참고값이다.

| 단계 | 기존 처리량 | 기존 실측 시간 | peak allocated / reserved |
| --- | --- | --- | --- |
| Pi3 | 363구간 | 21분 44초 | 5.17 / 5.86 GiB |
| Qwen3.5-9B | 성공 구간 기준 | 1시간 8분 26초 | 19.69 / 19.95 GiB |
| DINO+SAM2 | 353구간 | 7분 42초 | 4.27 / 5.76 GiB |
| Orient Anything | 1029 crops | 53.74초 | 1.16 / 1.17 GiB |
| trajectory | 353구간 | 4분 1초 | CPU / 0 GiB |
| 공식 QA | 353구간 | 4분 59초 | CPU / 0 GiB |

```bash
# 사용자 전용. ETA/VRAM은 위 표의 동일 조건 실측을 참고한다.
bash run_pipeline.sh 0
```
