#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
export CUDA_VISIBLE_DEVICES=''
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python -u scripts/generate_official_dsr_cpu.py "$@"
