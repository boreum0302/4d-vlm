#!/usr/bin/env bash
# USER ONLY: this orchestrates GPU workloads. Agents must not execute it.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
gpu="${1:-0}"
mkdir -p reports manifests artifacts inputs cache logs
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
CUDA_VISIBLE_DEVICES='' python3 scripts/validate_paths.py
CUDA_VISIBLE_DEVICES='' python3 scripts/prepare_cpu.py inventory --workers 4
CUDA_VISIBLE_DEVICES='' python3 scripts/prepare_cpu.py sample
CUDA_VISIBLE_DEVICES='' python3 scripts/select_dynamic.py
bash run_pi3_b200.sh --subset all --gpu "$gpu"
# The first Qwen run can exit nonzero for invalid output; normalize/retry those jobs.
if ! bash run_qwen35_objects_b200.sh --subset all --gpu "$gpu"; then
  [[ -f artifacts/qwen35_objects/run_all.json ]] || exit 1
fi
if ! bash run_qwen35_retry_b200.sh "$gpu"; then
  [[ -f reports/qwen35_validation.json ]] || exit 1
fi
bash run_grounded_sam2_b200.sh --subset all --gpu "$gpu"
CUDA_VISIBLE_DEVICES='' bash run_trajectories_cpu.sh all
bash run_orient_anything_b200.sh --subset all --gpu "$gpu"
CUDA_VISIBLE_DEVICES='' bash run_official_qa_cpu.sh
CUDA_VISIBLE_DEVICES='' python3 scripts/review_official_obvious_cpu.py
CUDA_VISIBLE_DEVICES='' python3 scripts/sample_official_viewer_cpu.py
echo 'Done: outputs/dsr_official_review/qa_kept.jsonl'
