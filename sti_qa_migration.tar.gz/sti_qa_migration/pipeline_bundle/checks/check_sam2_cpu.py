"""CPU-only dependency, checkpoint, processor, and SAM2 shape preflight."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['HF_HUB_OFFLINE']='1'
import sys,time,inspect
from pathlib import Path
ROOT=Path('.')
sys.path.insert(0,str(ROOT/'scripts'))
from portable_paths import configured
sys.path.insert(0,str(configured('sam_code')))
from sam2_contract import *
import torch
from PIL import Image
from transformers import AutoProcessor,AutoConfig,AutoModelForZeroShotObjectDetection
from sam2.build_sam import build_sam2_video_predictor
from sam2.utils.misc import load_video_frames
start=time.perf_counter();torch.set_num_threads(4)
config=AutoConfig.from_pretrained(str(DINO),local_files_only=True);config.disable_custom_kernels=True
processor=AutoProcessor.from_pretrained(str(DINO),local_files_only=True)
model=AutoModelForZeroShotObjectDetection.from_pretrained(str(DINO),config=config,local_files_only=True).eval()
assert next(model.parameters()).device.type=='cpu'
print('GroundingDINO weights loaded on CPU',flush=True)
# Small synthetic CPU image tests model forward and postprocess, not semantic quality.
inputs=processor(images=Image.new('RGB',(256,256)),text='person.',return_tensors='pt',size={'shortest_edge':256,'longest_edge':256})
with torch.inference_mode():pred=model(**inputs)
result=processor.post_process_grounded_object_detection(pred,inputs.input_ids,threshold=.35,text_threshold=.25,target_sizes=[(256,256)])
assert len(result)==1 and result[0]['boxes'].shape[-1]==4
print('GroundingDINO CPU forward/postprocess OK',flush=True)
del pred,inputs,model
tracker=build_sam2_video_predictor(SAM_CONFIG,str(SAM),device='cpu',apply_postprocessing=False,hydra_overrides_extra=['++model.fill_hole_area=0'])
assert next(tracker.parameters()).device.type=='cpu'
assert tracker.fill_hole_area==0
print('SAM2.1-large weights loaded on CPU',flush=True)
# Exercise loader and prompt/propagation on one synthetic frame, always on CPU.
import tempfile
with tempfile.TemporaryDirectory() as d:
    Image.new('RGB',(64,48),(110,120,130)).save(Path(d)/'000.jpg')
    Image.new('RGB',(64,48),(115,125,135)).save(Path(d)/'001.jpg')
    with torch.inference_mode():
        state=tracker.init_state(video_path=d,offload_video_to_cpu=True,offload_state_to_cpu=True)
        tracker.add_new_points_or_box(state,frame_idx=0,obj_id=1,box=[10,10,40,35])
        out=list(tracker.propagate_in_video(state))
    assert len(out)==2 and [x[0] for x in out]==[0,1]
    assert all(x[1]==[1] and tuple(x[2].shape)==(1,1,48,64) for x in out)
assert not torch.cuda.is_initialized()
report={'grounding_dino_cpu_load_forward_postprocess':True,'sam2_cpu_load_prompt_propagate':True,'sam2_frames_tested':2,'sam2_output_shape':[1,1,48,64],'cuda_initialized':False,'gpu_executed':False,'seconds':time.perf_counter()-start,'torch':torch.__version__,'sam2_source':str(SAM_CODE),'postprocessing_fill_holes':False}
write_json(ROOT/'reports/sam2_cpu_preflight.json',report);print(report,flush=True)
