"""CPU final dataset integrity, answer recomputation, and prediction input audit."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import sys,json,time
from pathlib import Path
from functools import lru_cache
ROOT=Path('.');sys.path.insert(0,str(ROOT/'scripts'))
import qa_cpu
qa_cpu.load_rules=lru_cache(maxsize=1)(qa_cpu.load_rules)
from orient_contract import read_jsonl,file_hash,write_json
from dsr_qa_contract import validate_qa

def main():
    start=time.perf_counter();out=ROOT/'outputs/dsr_qa';qas=read_jsonl(out/'qa_all.jsonl');model=read_jsonl(out/'model_inputs.jsonl');answers=read_jsonl(out/'answers.jsonl')
    assert [q['qa_id'] for q in qas]==[q['qa_id'] for q in model]==[q['qa_id'] for q in answers]
    assert len({q['qa_id'] for q in qas})==len(qas)
    geometries={};videos={};predicted=0
    for q,m,a in zip(qas,model,answers):
        assert not {'answer','answer_states','answer_evidence','geometry_artifact','source_video_path','input_frame_paths'} & set(m)
        assert m['question']==q['question'] and m['options']==q['options'] and a['answer']==q['answer']
        path=q['geometry_artifact']
        if path not in geometries:
            g=json.loads(Path(path).read_text());g['geometry_sha256']=file_hash(path);geometries[path]=g
        validate_qa(q,geometries[path])
        path=Path(m['input_video_path'])
        if path not in videos:
            marker=json.loads(path.with_suffix('.json').read_text());assert file_hash(path)==marker['sha256'];videos[path]=marker
        marker=videos[path]
        assert q['input_video_sha256']==m['input_video_sha256']==marker['sha256']
        assert marker['timestamps_s']==m['input_timestamps_s']==q['input_timestamps_s']
        assert marker['frame_count']==len(q['input_frame_paths'])
        for target in m['targets']+[m['viewpoint']]:
            if target['track_id']!='camera':
                w,h=target['bbox_image_size'];assert marker['width'] in (w,w+1) and marker['height'] in (h,h+1)
        if q['type'].endswith('_pred'):
            assert marker['kind']=='observed' and max(marker['timestamps_s'])<q['prediction_target_time_s'];predicted+=1
    assert not (out/'review.html').exists()
    assert 'torch' not in sys.modules and 'transformers' not in sys.modules
    report={'qa_verified':len(qas),'unique_videos':len({q['video_id'] for q in qas}),'prediction_qa_verified':predicted,
            'future_frame_leaks':0,'answer_recomputed':len(qas),'verified_media_used_by_qa':len(videos),
            'model_input_answer_leaks':0,'viewer_created':False,'gpu_executed':False,'wall_seconds':time.perf_counter()-start,
            'visual_correctness':'not certified; visual_review_pending'}
    write_json(ROOT/'reports/qa_final_audit.json',report);print(json.dumps(report))

if __name__=='__main__':main()
