"""CPU integration check using synthetic videos and explicitly fabricated model outputs.

No existing intermediate outputs are copied, no models are loaded and no GPU
entrypoints are executed. Fixtures live only in a temporary extracted copy.
"""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['OPENBLAS_NUM_THREADS']='1'
import hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path
import numpy as np
import pandas as pd

SOURCE=Path(__file__).resolve().parents[2]
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
def write(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,indent=2)+'\n')
def rows(path,values):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(''.join(json.dumps(v)+'\n' for v in values))
def readrows(path):return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def marker(folder,names):write(folder/'complete.json',{'run_signature':'synthetic_fixture','artifact_sha256':{name:digest(folder/name) for name in names}})

def main():
 with tempfile.TemporaryDirectory(prefix='sti-cpu-integration-') as temp:
  root=Path(temp)/'relocated project with spaces'
  shutil.copytree(SOURCE,root,ignore=shutil.ignore_patterns('__pycache__','*.pyc','SHA256SUMS'))
  pipe=root/'pipeline_bundle'; data=root/'viewer_bundle/data/STI-Bench'; video=data/'video';video.mkdir(parents=True,exist_ok=True)
  def command(args):
   p=subprocess.run(args,cwd=pipe,env=ENV,capture_output=True,text=True,timeout=180)
   if p.returncode:raise RuntimeError(' '.join(args)+'\n'+p.stdout[-4000:]+p.stderr[-4000:])
   return p.stdout
  def cpu(script,*args):
   result=command([sys.executable,'scripts/'+script,*args]);print('PASS '+script+' '+' '.join(args),flush=True);return result
  base=Path(temp)/'source.mp4'
  command(['ffmpeg','-v','error','-nostdin','-f','lavfi','-i','testsrc=size=64x48:rate=10:duration=9','-threads','1','-c:v','libx264','-pix_fmt','yuv420p','-an',str(base)])
  metadata=[]
  for source in ['ScanNet','Omni6DPose','Waymo']:
   for i in range(10):
    vid=f'fixture_{source}_{i:02d}';target=video/(vid+'.mp4')
    command(['ffmpeg','-v','error','-nostdin','-i',str(base),'-c','copy','-metadata','comment='+vid,str(target)])
    metadata.append({'Video':target.name,'Source':source,'scene':'synthetic','ID':len(metadata),'Task':'Speed & Acceleration'})
  frame=pd.DataFrame(metadata);frame.to_parquet(data/'qa.parquet');(data/'data').mkdir();frame.to_parquet(data/'data/test-00000-of-00001.parquet')
  config=json.loads((pipe/'paths.json').read_text())
  for key in config:
   if key=='sti_bench':continue
   config[key]='external/'+key
   p=pipe/config[key]
   if key in ['sam_checkpoint','orient_checkpoint','orient_model_code']:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'synthetic-placeholder')
   else:p.mkdir(parents=True,exist_ok=True)
  for key,names in [('dino_model',['model.safetensors']),('orient_backbone',['config.json','preprocessor_config.json','model.safetensors'])]:
   for name in names:(pipe/config[key]/name).write_bytes(b'{}')
  qwen=pipe/config['qwen_model'];write(qwen/'config.json',{'model_type':'qwen3_5'})
  write(qwen/'model.safetensors.index.json',{'weight_map':{'fixture':'model-00001-of-00001.safetensors'}})
  (qwen/'model-00001-of-00001.safetensors').write_bytes(b'synthetic-placeholder')
  write(pipe/'paths.json',config)
  for name in ['reports','manifests','artifacts','inputs','cache','logs']:(pipe/name).mkdir(exist_ok=True)
  cpu('prepare_cpu.py','inventory','--workers','2');cpu('prepare_cpu.py','sample');cpu('select_dynamic.py')
  cpu('prepare_pi3_segments.py','--subset','all','--workers','2')
  cpu('prepare_qwen35_objects.py','--subset','all')
  jobs=readrows(pipe/'manifests/pi3_all_s260920_k1_f8-32.jsonl')
  assert len(jobs)==30
  raw={'agents':[{'label':'car','motion':'moving','orientation_candidate':True,'evidence_frames':[0]}],
       'non_agents':[{'label':'bottle','motion':'stationary','orientation_candidate':False,'evidence_frames':[0]}],'truncated':False}
  for job in jobs:
   folder=pipe/'artifacts/qwen35_objects'/job['job_id']
   write(folder/'raw_response.json',{'text':json.dumps(raw),'generated_tokens':100})
  cpu('normalize_qwen35_objects.py');cpu('prepare_sam2_inputs.py','--subset','all')
  jobs=readrows(pipe/'manifests/sam2_all.jsonl')
  for job in jobs:
   geom=pipe/job['output_directory'];geom.mkdir(parents=True)
   n=len(job['frames']);h,w=24,32
   yy,xx=np.mgrid[:h,:w];grid=np.stack(((xx-w/2)/10,(yy-h/2)/10,np.ones_like(xx)*5),axis=-1).astype('float32')
   local=np.tile(grid,(n,1,1,1));poses=np.tile(np.eye(4,dtype='float32'),(n,1,1));poses[:,0,3]=np.arange(n)*.1
   np.savez_compressed(geom/'scene_geometry.npz',local_points=local,camera_to_world=poses,valid_mask=np.ones((n,h,w),dtype=bool),confidence=np.ones((n,h,w),dtype='float32'),timestamps_s=np.array([f['timestamp_s'] for f in job['frames']]),source_frame_indices=np.array([f['source_frame_index'] for f in job['frames']]))
   write(geom/'frame_map.json',{**job,'model_image_size_wh':[w,h]});marker(geom,['scene_geometry.npz','frame_map.json'])
   sam=pipe/'artifacts/grounded_sam2'/job['job_id'];(sam/'masks').mkdir(parents=True)
   tracks=[{'track_id':1,'label':'car','group':'agents','orientation_candidate':True},{'track_id':2,'label':'bottle','group':'non_agents','orientation_candidate':False}]
   fs=[]
   for i,f in enumerate(job['frames']):
    masks=np.zeros((2,48,64),dtype=bool);masks[0,4:20,4:20]=True;masks[1,24:40,36:52]=True
    path=sam/'masks'/f'{i:03d}.npz';np.savez_compressed(path,track_ids=np.array([1,2]),masks=masks)
    fs.append({'segment_frame_index':i,'source_frame_index':f['source_frame_index'],'timestamp_s':f['timestamp_s'],'mask_path':str(path.relative_to(pipe)), 'objects':[{'track_id':t,'mask_present':True,'mask_area_pixels':256,'bbox_xyxy':box} for t,box in [(1,[4,4,20,20]),(2,[36,24,52,40])]]})
   write(sam/'tracks.json',{'image_size_wh':[64,48],'source_frames':job['frames'],'tracks':tracks,'frames':fs});marker(sam,['tracks.json']+[str(f.relative_to(sam)) for f in sorted((sam/'masks').glob('*.npz'))])
  cpu('lift_tracks_cpu.py','--subset','all');cpu('lift_tracks_cpu.py','--subset','all')
  assert json.loads((pipe/'reports/trajectory_execution_all.json').read_text())['skipped']==30
  cpu('prepare_orient_inputs.py')
  for job in jobs:
   angles={'azimuth_deg':0,'polar_deg':0,'rotation_deg':0,'confidence':1.0}
   write(pipe/'artifacts/orient_anything'/job['job_id']/'orientations.json',{'tracks':[{'track_id':1,'samples':[{'status':'predicted','angles':angles} for _ in job['frames']]}]})
  cpu('generate_official_dsr_cpu.py');cpu('review_official_obvious_cpu.py');cpu('sample_official_viewer_cpu.py')
  first=(pipe/'outputs/dsr_official/qa_pairs.json').read_bytes()
  cpu('generate_official_dsr_cpu.py')
  assert first==(pipe/'outputs/dsr_official/qa_pairs.json').read_bytes()
  summary=json.loads((pipe/'outputs/dsr_official/generation_summary.json').read_text());assert not summary['failed'] and summary['qa_count']>0
  review=json.loads((pipe/'outputs/dsr_official_review/summary.json').read_text());assert review['kept']>0
  for f in (pipe/'manifests').glob('*.jsonl'):
   assert '/tmp/' not in f.read_text(),f
  for f in (pipe/'inputs').rglob('*.jpg'):
   assert f.is_symlink() and not Path(os.readlink(f)).is_absolute() and f.is_file()
  # No browser is required to verify that a valid MP4 survives viewer byte streaming.
  print(json.dumps({'synthetic_videos':30,'segments':len(jobs),'generated_qa':summary['qa_count'],'kept_qa':review['kept'],'qa_deterministic':True,'trajectory_resume':True,'relative_manifests_and_symlinks':True,'models_loaded':False,'gpu_executed':False},indent=2),flush=True)
if __name__=='__main__':main()
