"""CPU-only endpoint GroundingDINO screening; no SAM GPU execution."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['HF_HUB_OFFLINE']='1'
import sys,time,json,collections
from pathlib import Path
ROOT=Path('.');sys.path.insert(0,str(ROOT/'scripts'))
from sam2_contract import DINO,read_jsonl,file_hash,digest,write_json,select_detections,iou
import numpy as np
import torch
from PIL import Image
from transformers import AutoProcessor,AutoConfig,AutoModelForZeroShotObjectDetection


def main():
    torch.set_num_threads(4);started=time.perf_counter()
    jobs=read_jsonl(ROOT/'manifests/sam2_candidates.jsonl');accepted=[];excluded=[]
    settings={'box_threshold':.45,'text_threshold':.25,'min_box_area_fraction':.001,'max_objects':16,
              'frames':'first and last','device':'cpu','dtype':'float32','model_sha256':file_hash(DINO/'model.safetensors'),
              'screen_sha256':file_hash(__file__),'selector_sha256':file_hash(ROOT/'scripts/select_sam2_candidates.py')}
    config=AutoConfig.from_pretrained(str(DINO),local_files_only=True);config.disable_custom_kernels=True
    processor=AutoProcessor.from_pretrained(str(DINO),local_files_only=True)
    model=AutoModelForZeroShotObjectDetection.from_pretrained(str(DINO),config=config,local_files_only=True).eval()
    assert next(model.parameters()).device.type=='cpu'
    for i,j in enumerate(jobs,1):
        folder=ROOT/'artifacts/sam2_cpu_screen'/j['video_id']/j['segment_id'];report_path=folder/'screen.json'
        signature=digest({'settings':settings,'job':j})
        existing=json.loads(report_path.read_text()) if report_path.exists() else None
        if existing and existing.get('signature')==signature:result=existing
        else:
            t=time.perf_counter();reasons=[];endpoints=[]
            for frame_index in [0,len(j['frames'])-1]:
                if reasons:break
                with Image.open(j['frames'][frame_index]['path']) as im:image=im.convert('RGB')
                width,height=image.size;candidates=[]
                for obj in j['object_input']['objects']:
                    x=processor(images=image,text=obj['label']+'.',return_tensors='pt')
                    with torch.inference_mode():pred=model(**x)
                    out=processor.post_process_grounded_object_detection(pred,x.input_ids,threshold=.45,text_threshold=.25,target_sizes=[(height,width)])[0]
                    found=[]
                    for box,score in zip(out['boxes'].tolist(),out['scores'].tolist()):
                        area=max(0,box[2]-box[0])*max(0,box[3]-box[1])/(width*height)
                        if area<.001:continue
                        found.append(dict(label=obj['label'],group=obj['group'],score=score,bbox_xyxy=box,
                                          orientation_candidate=obj['orientation_candidate']))
                    if not found:
                        reasons.append(f'no_confident_endpoint_detection: frame={frame_index}, label={obj["label"]}');break
                    candidates.extend(found)
                kept,dropped=select_detections(candidates,width,height,16)
                if any(x['reason']=='track_limit' for x in dropped):reasons.append('more_than_16_endpoint_instances')
                if any(x['label']!=y['label'] and iou(np.asarray(x['bbox_xyxy']),[y['bbox_xyxy']])[0]>.8
                       for index,x in enumerate(candidates) for y in candidates[index+1:]):reasons.append('cross_label_box_conflict')
                endpoints.append({'frame_index':frame_index,'detections':kept,'dropped':dropped})
            result={'job_id':j['job_id'],'signature':signature,'settings':settings,'passed':not reasons,
                    'reasons':reasons,'endpoints':endpoints,'seconds':time.perf_counter()-t,
                    'gpu_executed':False,'visual_correctness_guaranteed':False}
            write_json(report_path,result)
        if result['passed']:
            accepted.append(dict(j,screening={'report':str(report_path),'sha256':file_hash(report_path),'signature':signature}))
        else:excluded.append({'job_id':j['job_id'],'video_id':j['video_id'],'source':j['source'],'reasons':result['reasons']})
        print(f'[{i}/{len(jobs)}] '+('PASS' if result['passed'] else 'EXCLUDE')+' '+j['video_id']+' '+str(result['reasons']),flush=True)
    for name,rows in [('sam2_selected.jsonl',accepted),('sam2_excluded_detection.jsonl',excluded)]:
        p=ROOT/'manifests'/name;p.write_text(''.join(json.dumps(x)+'\n' for x in rows))
    smoke=[]
    for source in ['Omni6DPose','ScanNet','Waymo']:
        smoke.extend(sorted([x for x in accepted if x['source']==source],key=lambda x:x['job_id'])[:2])
    p=ROOT/'manifests/sam2_selected_smoke.jsonl';p.write_text(''.join(json.dumps(x)+'\n' for x in smoke))
    metadata=read_jsonl(ROOT/'manifests/sam2_excluded_metadata.jsonl')
    p=ROOT/'manifests/sam2_excluded.jsonl';p.write_text(''.join(json.dumps(x)+'\n' for x in metadata+excluded))
    report={'original':363,'metadata_candidates':len(jobs),'selected':len(accepted),'smoke':len(smoke),
            'excluded':len(metadata)+len(excluded),'sources':dict(collections.Counter(j['source'] for j in accepted)),
            'seconds':time.perf_counter()-started,'settings':settings,'gpu_executed':False,
            'cuda_initialized':torch.cuda.is_initialized(),'visual_correctness_guaranteed':False}
    assert not torch.cuda.is_initialized()
    write_json(ROOT/'reports/sam2_selection.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
