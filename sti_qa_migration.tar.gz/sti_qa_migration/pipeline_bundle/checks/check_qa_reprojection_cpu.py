"""CPU-only image correspondence check for shortlisted Pi3 camera/depth geometry."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import sys,json,time,collections
from pathlib import Path
ROOT=Path('.');sys.path.insert(0,str(ROOT/'scripts'))
import numpy as np
import cv2
from orient_contract import read_jsonl,write_json,file_hash


def intrinsics(points,valid):
    h,w=valid.shape;yy,xx=np.indices((h,w));keep=valid&np.isfinite(points).all(-1)&(points[...,2]>0)
    indices=np.flatnonzero(keep)[::max(1,int(keep.sum())//3000)]
    if len(indices)<100:raise ValueError('insufficient_intrinsic_fit_points')
    rays=points.reshape(-1,3)[indices];rays=rays[:,:2]/rays[:,2:]
    u=xx.ravel()[indices];v=yy.ravel()[indices]
    ax=np.linalg.lstsq(np.column_stack([rays[:,0],np.ones(len(rays))]),u,rcond=None)[0]
    ay=np.linalg.lstsq(np.column_stack([rays[:,1],np.ones(len(rays))]),v,rcond=None)[0]
    error=np.hypot(rays[:,0]*ax[0]+ax[1]-u,rays[:,1]*ay[0]+ay[1]-v)
    if ax[0]<=0 or ay[0]<=0:raise ValueError('invalid_intrinsic_fit')
    return ax,ay,float(np.median(error))


def check(path):
    with np.load(path,allow_pickle=False) as z:
        rgb=z['images_uint8'];local=z['local_points'];pose=z['camera_to_world'];valid=z['valid_mask'];conf=z['confidence']
    pairs=[];h,w=valid.shape[1:]
    fits=[intrinsics(p,v&(c>=.5)) for p,v,c in zip(local,valid,conf)]
    for i in range(len(rgb)-1):
        first=cv2.cvtColor(rgb[i],cv2.COLOR_RGB2GRAY);second=cv2.cvtColor(rgb[i+1],cv2.COLOR_RGB2GRAY)
        p=cv2.goodFeaturesToTrack(first,maxCorners=300,qualityLevel=.01,minDistance=8,mask=((valid[i]&(conf[i]>=.5))*255).astype(np.uint8))
        reasons=[];record={'frame_index':i,'correspondences':0,'median_reprojection_error_px':None,'within_5px_fraction':0}
        if p is None or len(p)<20:reasons.append('too_few_image_features')
        else:
            q,status,_=cv2.calcOpticalFlowPyrLK(first,second,p,None,winSize=(21,21),maxLevel=3)
            back,back_status,_=cv2.calcOpticalFlowPyrLK(second,first,q,None,winSize=(21,21),maxLevel=3)
            keep=(status.ravel()==1)&(back_status.ravel()==1)&(np.linalg.norm(back[:,0]-p[:,0],axis=1)<1)
            source=p[:,0][keep];target=q[:,0][keep]
            inside=(target[:,0]>=0)&(target[:,0]<w)&(target[:,1]>=0)&(target[:,1]<h)
            source=source[inside];target=target[inside]
            u=np.rint(source[:,0]).astype(int).clip(0,w-1);v=np.rint(source[:,1]).astype(int).clip(0,h-1)
            pts=local[i,v,u];world=pts@pose[i,:3,:3].T+pose[i,:3,3]
            camera=(world-pose[i+1,:3,3])@pose[i+1,:3,:3]
            good=np.isfinite(camera).all(-1)&(camera[:,2]>0)
            camera=camera[good];target=target[good]
            ax,ay,_=fits[i+1]
            projected=np.column_stack([camera[:,0]/camera[:,2]*ax[0]+ax[1],camera[:,1]/camera[:,2]*ay[0]+ay[1]])
            error=np.linalg.norm(projected-target,axis=1)
            record['correspondences']=len(error)
            if len(error):record.update(median_reprojection_error_px=float(np.median(error)),within_5px_fraction=float(np.mean(error<=5)))
            if len(error)<20:reasons.append('too_few_consistent_correspondences')
            elif np.median(error)>5 or np.mean(error<=5)<.6:reasons.append('image_geometry_reprojection_disagreement')
        if max(fits[i][2],fits[i+1][2])>2:reasons.append('camera_ray_fit_error')
        record.update(passed=not reasons,reasons=reasons);pairs.append(record)
    return {'passed':all(x['passed'] for x in pairs),'pairs':pairs,'max_intrinsic_fit_median_error_px':max(f[2] for f in fits)}


def main():
    cv2.setNumThreads(4);start=time.perf_counter();qas=read_jsonl(ROOT/'outputs/qa_review/qa_passed.jsonl');paths={}
    for q in qas:
        g=json.loads(Path(q['geometry_artifact']).read_text());paths[g['job_id']]=Path(g['upstream']['pi3'])/'scene_geometry.npz'
    results={}
    for i,(job_id,path) in enumerate(paths.items(),1):
        try:result=check(path)
        except (ValueError,cv2.error) as e:result={'passed':False,'error':str(e),'pairs':[]}
        result['geometry_sha256']=file_hash(path);results[job_id]=result
        if i%20==0 or i==len(paths):print(f'Reprojection {i}/{len(paths)} pass={sum(x["passed"] for x in results.values())} elapsed={time.perf_counter()-start:.1f}s',flush=True)
    report={'jobs':results,'passed_jobs':sum(x['passed'] for x in results.values()),'checked_jobs':len(results),
            'criteria':'all adjacent pairs: >=20 forward/backward consistent LK correspondences; median reprojection error <=5 pixels and >=60% within 5px; intrinsic ray fit median <=2px',
            'interpretation':'static-scene consistency screen; disagreement is a hold, not proof of wrong pose',
            'seconds':time.perf_counter()-start,'gpu_executed':False,'viewer_created':False}
    write_json(ROOT/'reports/qa_reprojection_review.json',report);print(json.dumps({k:v for k,v in report.items() if k!='jobs'}))

if __name__=='__main__':main()
