"""Actual Orient Anything checkpoint load + one actual crop inference on CPU only."""
import os
os.environ['CUDA_VISIBLE_DEVICES']='';os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
import sys,time,json
from pathlib import Path
ROOT=Path('.');sys.path.insert(0,str(ROOT/'scripts'))
import numpy as np
from PIL import Image
import torch
from orient_contract import load_model,decode_logits,crop_object,read_jsonl,write_json,dsr_camera_to_agent

def main():
    torch.set_num_threads(4);start=time.perf_counter()
    job=read_jsonl(ROOT/'manifests/orient_smoke.jsonl')[0]
    item=next(x for x in job['orientation']['samples'] if x['status']=='ready');i=item['frame_index']
    maskfile=ROOT/'artifacts/grounded_sam2'/job['video_id']/job['segment_id']/'masks'/f'{i:03d}.npz'
    with np.load(maskfile,allow_pickle=False) as z:mask=z['masks'][z['track_ids'].tolist().index(item['track_id'])]
    with Image.open(job['frames'][i]['path']) as im:crop,box=crop_object(np.asarray(im.convert('RGB')),mask)
    model,processor=load_model('cpu');assert next(model.parameters()).device.type=='cpu'
    inputs=processor(images=crop,return_tensors='pt')
    with torch.inference_mode():pred=model(inputs)
    result=decode_logits(pred[0].numpy());r=dsr_camera_to_agent(result['azimuth_deg'],result['polar_deg'],result['rotation_deg'])
    assert np.allclose(r.T@r,np.eye(3),atol=1e-6) and not torch.cuda.is_initialized()
    report={'cpu_checkpoint_load_and_forward':True,'job_id':job['job_id'],'track_id':item['track_id'],
            'input_shape':list(inputs['pixel_values'].shape),'output_shape':list(pred.shape),'output':result,
            'parameter_count':sum(p.numel() for p in model.parameters()),'seconds':time.perf_counter()-start,
            'gpu_executed':False,'cuda_initialized':torch.cuda.is_initialized(),'crop_bbox':box}
    write_json(ROOT/'reports/orient_cpu_preflight.json',report);print(json.dumps(report),flush=True)
if __name__=='__main__':main()
