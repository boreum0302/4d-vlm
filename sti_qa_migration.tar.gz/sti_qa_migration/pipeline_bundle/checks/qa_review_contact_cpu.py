"""Static, in-memory contact image for audit only; not a viewer/site."""
import json,io,base64,sys
from pathlib import Path
from PIL import Image,ImageDraw
root=Path('.')
qs=json.loads((root/'reports/qa_reprojection_survivors.json').read_text())
qs=[q for q in qs if all(t['track_id']=='camera' for t in q['targets']+[q['viewpoint']])]
page=int(sys.argv[1]);rows=qs[page*7:(page+1)*7]
canvas=Image.new('RGB',(1080,280*len(rows)),'white');d=ImageDraw.Draw(canvas)
for row,q in enumerate(rows):
 y=row*280;g=json.loads(Path(q['geometry_artifact']).read_text())
 n=len(g['frame_paths']);ii=[0,n-3,n-1] if q['type'].endswith('_pred') else [0,n//2,n-1]
 d.text((5,y+3),f"{page*7+row}: {q['qa_id']} {q['video_id']} {q['type']}",fill='black')
 d.text((5,y+17),q['answer_states'],fill='black')
 for col,i in enumerate(ii):
  im=Image.open(g['frame_paths'][i]).convert('RGB');im.thumbnail((355,220));canvas.paste(im,(col*360,y+50))
  d.text((col*360,y+33),f"frame {i} / {g['timestamps_s'][i]}s",fill='black')
b=io.BytesIO();canvas.save(b,format='JPEG',quality=70);print(base64.b64encode(b.getvalue()).decode())
