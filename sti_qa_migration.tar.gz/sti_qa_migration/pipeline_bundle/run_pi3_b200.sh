#!/usr/bin/env bash
# USER LAUNCH ONLY. The assistant must not execute this script.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
subset=smoke
gpu=0
segments=1
seed=260920
min_frames=8
max_frames=32
workers=4
pixel_limit=255000
prepare_only=0
output_root=""
while (($#)); do
  case "$1" in
    --subset) subset="${2:?missing subset}"; shift 2 ;;
    --gpu) gpu="${2:?missing GPU ID or UUID}"; shift 2 ;;
    --segments-per-video) segments="${2:?missing count}"; shift 2 ;;
    --seed) seed="${2:?missing seed}"; shift 2 ;;
    --min-frames) min_frames="${2:?missing count}"; shift 2 ;;
    --max-frames) max_frames="${2:?missing count}"; shift 2 ;;
    --workers) workers="${2:?missing count}"; shift 2 ;;
    --pixel-limit) pixel_limit="${2:?missing limit}"; shift 2 ;;
    --output-root) output_root="${2:?missing path}"; shift 2 ;;
    --prepare-only) prepare_only=1; shift ;;
    -h|--help)
      echo 'Usage: bash run_pi3_b200.sh --subset smoke|all --gpu 0 [--segments-per-video 1] [--min-frames 8 --max-frames 32] [--prepare-only]'
      echo 'Overrides: PI3_PYTHON, CPU_PYTHON, PI3_MODEL, PI3_CODE_ROOT. Only the user launches this GPU script.'
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
[[ "$subset" == smoke || "$subset" == all ]] || { echo 'subset must be smoke or all' >&2; exit 2; }
[[ -n "$gpu" && "$gpu" != *,* ]] || { echo 'Choose exactly one GPU ID or UUID' >&2; exit 2; }
cpu_python="${CPU_PYTHON:-python3}"
pi3_python="${PI3_PYTHON:-python3}"
pi3_code="${PI3_CODE_ROOT:-$(python3 scripts/path_value.py pi3_code)}"
pi3_model="${PI3_MODEL:-$(python3 scripts/path_value.py pi3_model)}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
CUDA_VISIBLE_DEVICES='' "$cpu_python" scripts/prepare_pi3_segments.py \
  --subset "$subset" --seed "$seed" --segments-per-video "$segments" \
  --min-frames "$min_frames" --max-frames "$max_frames" --workers "$workers"
manifest="manifests/pi3_${subset}_s${seed}_k${segments}_f${min_frames}-${max_frames}.jsonl"
if ((prepare_only)); then
  echo "CPU preparation complete: $manifest (GPU not started)"
  exit 0
fi
[[ -x "$pi3_python" ]] || command -v "$pi3_python" >/dev/null || {
  echo 'Pi3 Python executable missing. Check PI3_PYTHON.' >&2; exit 1;
}
[[ -f "$pi3_model/model.safetensors" && -d "$pi3_code/pi3" ]] || {
  echo 'Pi3 Python/code/checkpoint missing. Check PI3_PYTHON, PI3_MODEL, PI3_CODE_ROOT.' >&2; exit 1;
}
export CUDA_VISIBLE_DEVICES="$gpu"
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONUNBUFFERED=1
mkdir -p logs
log="logs/pi3_b200_${subset}_$(date +%Y%m%d_%H%M%S)_$$.log"
extra=()
[[ -z "$output_root" ]] || extra+=(--output-root "$output_root")
"$pi3_python" gpu/extract_pi3.py --manifest "$manifest" --model "$pi3_model" \
  --code-root "$pi3_code" --pixel-limit "$pixel_limit" "${extra[@]}" 2>&1 | tee "$log"
