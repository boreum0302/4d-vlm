# STI QA 이사 폴더

## 폴더 1 — viewer_bundle

최종 검수 유지 **958 QA 전체 / 273개 영상**을 담았다. 제외된 17개의 QA 본문과 검수 전 QA 파일은 포함하지 않는다. 기존 뷰어 표본 100개는 별도로 보존한다.

이 폴더만 복사하고 `viewer_bundle/data/STI-Bench/video/`에 원본 STI MP4를 넣으면 된다. 표준 Python 뷰어, 전체 QA의 VLM 입력·별도 정답 파일, 로컬 Qwen3.5 inference 실행 코드와 CPU 평가 코드가 있다. 모델 실행 코드는 사용자가 새 서버에서 실행한다.

[폴더 1 사용설명서](viewer_bundle/README.md)

## 폴더 2 — pipeline_bundle

STI 원본에서 QA를 다시 만드는 전체 CPU/GPU 파이프라인 코드와 문서다. 외부 코드 사본·모델·체크포인트·중간결과는 포함하지 않는다. [링크 안내](pipeline_bundle/docs/DOWNLOADS.md)에서 외부 코드를 설치하고 체크포인트를 받은 뒤 `paths.json`을 채운다. STI 경로는 기본적으로 폴더 1에 받은 데이터를 참조하며 다른 상대경로로 바꿀 수 있다.

[폴더 2 사용설명서](pipeline_bundle/README.md)

내부 코드와 저장 데이터에 이전 서버 절대경로가 없다. 각 폴더별 압축본과 두 폴더를 함께 담은 압축본을 제공한다. CPU/브라우저 검증 결과는 VALIDATION.json, BROWSER_VALIDATION.json 및 각 폴더의 VALIDATION.md를 참고한다. 원본 영상 연결·해시·CPU 디코딩은 검증했다. GPU 추론과 브라우저 UI 검증은 완료하지 않았다.
