"""USER-ONLY GPU inference over every kept QA. Agents must not execute this file.

Consumes vlm/inputs.jsonl only; never loads GT during inference. Checkpoints
must already exist locally. Uses CPU ffmpeg for original-timestamp frames.
"""
import argparse,hashlib,json,os,time
from pathlib import Path
from vlm_utils import readrows,load_frames,parse_answer
ROOT=Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--model',required=True,type=Path);p.add_argument('--gpu',default='0');p.add_argument('--inputs',default='vlm/inputs.jsonl',type=Path);p.add_argument('--output',default='vlm/predictions.jsonl',type=Path);p.add_argument('--max-frames',type=int,default=32);p.add_argument('--max-pixels',type=int,default=262144);p.add_argument('--limit',type=int);a=p.parse_args()
 if ',' in a.gpu or not a.gpu:p.error('Expose exactly one GPU')
 if a.max_frames<4 or a.max_pixels<4096 or (a.limit is not None and a.limit<1):p.error('Invalid frame/pixel/limit setting')
 source=a.inputs if a.inputs.is_absolute() else ROOT/a.inputs
 output=a.output if a.output.is_absolute() else ROOT/a.output
 model=a.model if a.model.is_absolute() else ROOT/a.model
 if not model.is_dir():raise FileNotFoundError(model)
 rows=readrows(source)
 if len({r['qa_id'] for r in rows})!=len(rows):raise ValueError('Duplicate QA IDs')
 for row in rows:
  if not (ROOT/row['video_path']).is_file():raise FileNotFoundError(row['video_path'])
 settings={'model':str(a.model),'max_frames':a.max_frames,'max_pixels':a.max_pixels,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'enable_thinking':False,'dtype':'bfloat16','attention':'sdpa','max_new_tokens':16,'sampling':False}
 meta=output.with_suffix('.meta.json');output.parent.mkdir(parents=True,exist_ok=True)
 if output.exists() and not meta.exists():raise ValueError('Existing output has no metadata; use a new --output')
 if meta.exists() and json.loads(meta.read_text())!=settings:raise ValueError('Inference configuration changed; use a new --output')
 meta.write_text(json.dumps(settings,indent=2)+'\n')
 done={r['qa_id'] for r in readrows(output) if r.get('answer') in ['A','B','C','D']} if output.exists() else set()
 selected=rows[:a.limit] if a.limit else rows;pending=[r for r in selected if r['qa_id'] not in done]
 if not pending:print('All selected QA already have predictions.');return
 os.environ['CUDA_VISIBLE_DEVICES']=a.gpu;os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
 import torch
 from transformers import AutoProcessor,Qwen3_5ForConditionalGeneration
 if not torch.cuda.is_available() or torch.cuda.device_count()!=1:raise RuntimeError('Exactly one CUDA GPU required')
 if not torch.cuda.is_bf16_supported():raise RuntimeError('BF16-capable GPU required')
 processor=AutoProcessor.from_pretrained(str(model),local_files_only=True)
 net=Qwen3_5ForConditionalGeneration.from_pretrained(str(model),dtype=torch.bfloat16,device_map={'':0},attn_implementation='sdpa',local_files_only=True).eval()
 with output.open('a') as stream:
  for index,row in enumerate(pending,1):
   start=time.perf_counter();inputs=generated=None;result={'qa_id':row['qa_id']}
   try:
    images,times=load_frames(ROOT/row['video_path'],row,a.max_frames)
    content=[{'type':'text','text':row['prompt']}]
    for i,t in enumerate(times):content.extend([{'type':'text','text':f'Frame {i}, original video time {t:.6f} seconds:'},{'type':'image'}])
    text=processor.apply_chat_template([{'role':'user','content':content}],tokenize=False,add_generation_prompt=True,enable_thinking=False)
    inputs=processor(text=[text],images=images,return_tensors='pt',images_kwargs={'size':{'shortest_edge':4096,'longest_edge':a.max_pixels}}).to('cuda:0')
    torch.cuda.reset_peak_memory_stats()
    with torch.inference_mode():generated=net.generate(**inputs,max_new_tokens=16,do_sample=False)
    response=processor.batch_decode(generated[:,inputs['input_ids'].shape[1]:],skip_special_tokens=True)[0].strip()
    result.update(answer=parse_answer(response),response=response,source_frame_times_s=times,peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,seconds=time.perf_counter()-start)
   except Exception as exc:result.update(answer=None,error=str(exc),seconds=time.perf_counter()-start)
   finally:inputs=generated=None;torch.cuda.empty_cache()
   stream.write(json.dumps(result,ensure_ascii=False)+'\n');stream.flush();print(f'{index}/{len(pending)} {row["qa_id"]}: {result.get("answer") or "ERROR"}',flush=True)
if __name__=='__main__':main()
