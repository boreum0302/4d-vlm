"""CPU-only, allowlisted QA viewer with byte-range video streaming."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import json,secrets,re,argparse
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1]

def load(selection='all', video_dir=None):
    rows=json.loads((ROOT/'qa'/('viewer_'+selection+'.json')).read_text())
    directory=Path(video_dir) if video_dir else ROOT/'data/STI-Bench/video'
    if not directory.is_absolute(): directory=ROOT/directory
    videos={r['video_id']:directory/r['video_file'] for r in rows}
    missing=[p.name for p in videos.values() if not p.is_file()]
    if missing:raise FileNotFoundError(f'{len(missing)} videos missing from {directory}; examples: {missing[:3]}')
    return rows,videos

class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):self.respond(False)
    def do_GET(self):self.respond(True)
    def respond(self,body):
        path=self.path.split('?',1)[0]
        prefix='/'+TOKEN+'/'
        if not path.startswith(prefix):self.send_error(404);return
        route=path[len(prefix):]
        data=None;file=None
        if route in ('','index.html'):data=(ROOT/'viewer/index.html').read_bytes();mime='text/html; charset=utf-8'
        elif route=='data.json':data=json.dumps(ROWS).encode();mime='application/json'
        elif route.startswith('video/') and route[6:] in VIDEOS:file=VIDEOS[route[6:]];mime='video/mp4'
        else:self.send_error(404);return
        size=file.stat().st_size if file else len(data);start=0;end=size-1;status=200
        if file and self.headers.get('Range'):
            m=re.fullmatch(r'bytes=(\d*)-(\d*)',self.headers['Range'])
            if not m or not any(m.groups()):self.send_error(416);return
            a,b=m.groups()
            if a:start=int(a);end=min(int(b),size-1) if b else size-1
            else:start=max(0,size-int(b))
            if start>end or start>=size:
                self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.end_headers();return
            status=206
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(end-start+1));self.send_header('Accept-Ranges','bytes');self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer')
        if route.startswith('download/'):self.send_header('Content-Disposition',f'attachment; filename="{file.name}"')
        if status==206:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
        self.end_headers()
        if not body:return
        try:
            if file:
                with file.open('rb') as f:
                    f.seek(start);remaining=end-start+1
                    while remaining:
                        chunk=f.read(min(1024*1024,remaining))
                        if not chunk:break
                        self.wfile.write(chunk);remaining-=len(chunk)
            else:self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError):pass
    def log_message(self,*args):pass

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);p.add_argument('--host',default='127.0.0.1');p.add_argument('--selection',choices=['all','sample'],default='all');p.add_argument('--video-dir',default='data/STI-Bench/video');a=p.parse_args()
    tokenpath=ROOT/'viewer/access_token'
    if not tokenpath.exists():tokenpath.write_text(secrets.token_urlsafe(24));tokenpath.chmod(0o600)
    TOKEN=tokenpath.read_text().strip();ROWS,VIDEOS=load(a.selection,a.video_dir)
    print(f'http://127.0.0.1:{a.port}/{TOKEN}/',flush=True)
    ThreadingHTTPServer((a.host,a.port),Handler).serve_forever()
