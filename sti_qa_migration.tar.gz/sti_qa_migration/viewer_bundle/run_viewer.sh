#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
CUDA_VISIBLE_DEVICES="" python3 viewer/server.py "$@"
