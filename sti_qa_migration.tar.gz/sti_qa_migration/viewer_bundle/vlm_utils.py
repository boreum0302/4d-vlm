"""CPU helpers for preparing VLM video frames and parsing option letters."""
import json,math,re,subprocess,tempfile
from pathlib import Path

def readrows(path):return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]
def select_frames(times,start,end,anchors,max_frames=32):
 if max_frames<4:raise ValueError('max_frames must be at least 4')
 if not (math.isfinite(start) and math.isfinite(end) and 0<=start<=end):raise ValueError('Invalid video interval')
 candidates=[i for i,t in enumerate(times) if start-1e-7<=t<=end+1e-7]
 if not candidates:raise ValueError('No original frame falls inside allowed video interval')
 chosen=set()
 for t in [start,end,*anchors]:
  if t is not None and start<=t<=end:chosen.add(min(candidates,key=lambda i:abs(times[i]-t)))
 targets=[start+(end-start)*i/(max_frames-1) for i in range(max_frames)]
 for t in targets:
  if len(chosen)>=max_frames:break
  chosen.add(min(candidates,key=lambda i:abs(times[i]-t)))
 return sorted(chosen)
def load_frames(video,row,max_frames=32):
 from PIL import Image
 out=subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(video)])
 fs=json.loads(out)['frames'];pts=[float(f['best_effort_timestamp_time']) for f in fs]
 if not pts:raise ValueError('Video contains no frames')
 times=[t-pts[0] for t in pts]
 indices=select_frames(times,row['video_input_start_s'],row['video_input_end_s'],[row['question_start_s'],row['observer_time_s']],max_frames)
 with tempfile.TemporaryDirectory(prefix='sti-vlm-frames-') as tmp:
  expr='+'.join(f'eq(n\\,{i})' for i in indices)
  subprocess.run(['ffmpeg','-v','error','-nostdin','-threads','1','-i',str(video),'-vf','select='+expr,'-vsync','0','-threads','1','-start_number','0',str(Path(tmp)/'%03d.png')],check=True)
  paths=sorted(Path(tmp).glob('*.png'))
  if len(paths)!=len(indices):raise ValueError('Extracted frame count differs from selected native indices')
  images=[]
  for path in paths:
   with Image.open(path) as image:images.append(image.convert('RGB').copy())
 return images,[times[i] for i in indices]
def parse_answer(text):
 matches=re.fullmatch(r'\s*(?:answer\s*[:：]\s*)?\(?([ABCD])\)?[.。]?\s*',text,re.I)
 return matches[1].upper() if matches else None
