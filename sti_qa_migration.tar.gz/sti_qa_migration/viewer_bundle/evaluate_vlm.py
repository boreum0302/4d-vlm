"""CPU scoring of last valid prediction per QA; missing/error QA count as wrong."""
import argparse,json
from pathlib import Path
from vlm_utils import readrows
ROOT=Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser();p.add_argument('--predictions',type=Path,default=Path('vlm/predictions.jsonl'));p.add_argument('--labels',type=Path,default=Path('vlm/labels.jsonl'));a=p.parse_args()
 labels=readrows(ROOT/a.labels);predictions={}
 for r in readrows(ROOT/a.predictions):
  if r.get('answer') in ['A','B','C','D']:predictions[r['qa_id']]=r
 ids={q['qa_id'] for q in labels};unknown=set(predictions)-ids
 if unknown:raise ValueError(f'Unknown QA IDs: {sorted(unknown)[:3]}')
 correct=sum(predictions.get(q['qa_id'],{}).get('answer')==q['answer'] for q in labels)
 print(json.dumps({'total':len(labels),'valid_predictions':len(predictions),'missing_or_invalid':len(labels)-len(predictions),'correct':correct,'accuracy_all_qa':correct/len(labels) if labels else 0},indent=2))
if __name__=='__main__':main()
