# 폴더 1: STI QA 뷰어 + VLM inference

이 폴더만 새 서버의 원하는 위치에 복사한다. 아래 명령은 이 폴더 안에서 실행한다.

## 포함 데이터

- `qa/qa_kept.jsonl`: **최종 QA 958개 전부**, 영상 경로·질문·A–D·정답·시간·bbox 근거 포함.
- `qa/qa_pairs_kept.json`: 공식 형식, 273개 영상/구간별 QA 목록.
- `qa/viewer_all.json`: 전체 958 QA의 뷰어 표시 데이터. 중간 mask·geometry가 필요 없다.
- `qa/qa_sample.jsonl`, `qa/viewer_sample.json`: 기존 100 QA 표본.
- `vlm/inputs.jsonl`: 전체 958개용 영상 경로·질문·선택지·프롬프트·사용 시간 구간.
- `vlm/labels.jsonl`: 평가용 정답. inference 입력과 분리했다.

**제외된 17개는 포함하지 않는다.** 질문·선택지·정답은 기존 최종 결과와 동일하다. 파일 내부 영상 상대경로는 이 폴더 기준이다.

## 1. 원본 STI 영상 준비

[STI GitHub](https://github.com/MINT-SJTU/STI-Bench), [STI HF dataset](https://huggingface.co/datasets/MINT-SJTU/STI-Bench)에서 영상 데이터를 받고 아카이브를 풀어 `data/STI-Bench/video/*.mp4`로 둔다. 기존 JSON에 기록된 MP4 이름을 유지한다. 뷰어와 기존 QA inference에는 parquet가 필요 없다.

```bash
python3 prepare_vlm_inputs.py --check-videos
```

273개 영상이 모두 존재하는지 확인한다. 모델 실행은 하지 않는다.

## 2. 뷰어

Python 3 표준 라이브러리만 사용한다. GPU나 외부 Python 패키지가 필요 없다.

```bash
bash run_viewer.sh
# 기존 표본 100개만 확인
bash run_viewer.sh --selection sample --port 8766
# 데이터 위치를 달리할 때, 상대경로 기준은 이 폴더다.
bash run_viewer.sh --video-dir data/STI-Bench/video
```

콘솔에 출력되는 토큰 포함 URL을 연다. 원격 서버라면 PC에서 `ssh -L 8765:127.0.0.1:8765 USER@SERVER` 후 같은 URL을 연다. QA 유형 선택, 원본/bbox 동기 재생, GT 표시, anchor 탐색, 재생 속도와 bbox 보간을 지원한다. 토큰은 새 서버에서 생성된다.

## 3. 기존 VLM 실행 코드에 연결

`vlm/inputs.jsonl`의 각 행에서 `video_path`를 열고 `video_input_start_s`부터 `video_input_end_s`까지의 프레임과 `prompt`를 모델에 넣는다. `qa_id`로 예측을 저장한다. 정답 파일은 inference 입력에 넣지 않는다.

질문과 bbox 시각은 원본 영상의 초 단위다. 참조 시각이 질문 구간 밖인 경우 필요한 관찰자 시각도 입력 범위에 포함했다. 예측형은 관측 끝까지만 입력하며 미래 목표 프레임은 제외한다. 영상이나 프레임을 잘라 입력할 때 원본 시간 매핑을 유지한다.

## 4. 제공 Qwen3.5 실행 코드 사용

기존 VLM 실행 코드가 없으면 `infer_qwen35.py`를 사용할 수 있다. [Qwen3.5-9B](https://huggingface.co/Qwen/Qwen3.5-9B)의 전체 모델 파일을 새 서버에 직접 받는다. 체크포인트는 이 폴더에 포함하지 않았다.

새 서버의 CUDA에 맞는 PyTorch를 설치하고 `python3 -m pip install -r requirements-vlm.txt`를 실행한다. `ffmpeg`와 `ffprobe`가 필요하다.

**사용자 전용 GPU 명령.** Qwen3.5-9B BF16, batch 1, 최대 32프레임/프레임당 262144 pixels 조건이다. 이 QA inference의 peak VRAM·ETA는 미측정이다. 참고로 기존 객체 분류 작업은 B200에서 peak allocated 19.69 / reserved 19.95 GiB였으나 이 inference의 측정값은 아니다. 새 서버에서 먼저 제한된 QA로 시간·메모리를 확인한다.

```bash
# 새 서버에서 사용자만 실행. VRAM·ETA 조건은 위 설명 참고.
python3 infer_qwen35.py --model checkpoints/Qwen3.5-9B --gpu 0 --limit 5
# 전체 958개. 동일 설정이면 완료한 QA는 건너뛰고 이어서 실행한다.
python3 infer_qwen35.py --model checkpoints/Qwen3.5-9B --gpu 0
```

외부 모델 폴더는 `--model`로 지정한다. GPU는 한 장만 노출하며 BF16을 지원해야 한다. 모든 모델 파일은 미리 다운로드해야 한다. 출력은 `vlm/predictions.jsonl`, 실행 설정은 `vlm/predictions.meta.json`이다. 실패/선택지 파싱 실패는 정답으로 간주하지 않고 다음 실행에서 재시도한다. 설정이 달라지면 다른 `--output`을 지정한다.

제공 코드는 원본 프레임의 실제 타임스탬프를 확인하고, 허용 구간 안의 프레임만 CPU ffmpeg로 추출한다. 질문·관찰자 anchor를 우선 포함하고 최대 32프레임으로 제한한다. 이것은 원래 QA 생성 시 1 FPS 추론 입력과 별개의 VLM 평가 입력 샘플링이다.

```bash
# CPU 평가. 미응답·오류도 전체 958개 분모에서 오답으로 센다.
CUDA_VISIBLE_DEVICES='' python3 evaluate_vlm.py
```

실제 원본 STI 영상의 CPU 디코딩과 입력 프레임 추출은 검증했다. Qwen GPU inference와 브라우저 UI 검증은 완료하지 않았다. 자세한 검증 결과는 [VALIDATION.md](VALIDATION.md)를 참고한다.
