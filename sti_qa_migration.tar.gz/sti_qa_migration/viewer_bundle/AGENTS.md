# Execution constraints

Agents may run CPU preparation, tests and the HTTP viewer with CUDA_VISIBLE_DEVICES empty.
Agents must not execute infer_qwen35.py or other GPU inference. The user runs GPU workloads.
